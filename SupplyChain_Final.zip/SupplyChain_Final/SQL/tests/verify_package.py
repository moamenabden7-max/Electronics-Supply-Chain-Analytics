"""Offline verification of this exact CSV package. Does NOT execute SQL Server.
Run: python tests/verify_package.py
Uses SQLite for relational checks and Decimal for numeric fidelity.
"""
import csv,json,re,sqlite3,collections
from decimal import Decimal,ROUND_HALF_UP
from datetime import date,datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
meta=json.loads((ROOT/'tests/schema.json').read_text())
db=sqlite3.connect(':memory:')
data={};results=[]
def record(name,ok,detail=''):
    results.append({'check':name,'passed':bool(ok),'detail':detail})
def sql(s):
    s=re.sub(r'\b(silver|bronze|gold)\.\[?(\w+)\]?',r'\1_\2',s)
    return re.sub(r'\bCOUNT_BIG\b','COUNT',s,flags=re.I)
for t,cols in meta['schema'].items():
    rows=list(csv.DictReader((ROOT/'raw_data'/f'{t}.csv').open(encoding='utf-8-sig',newline='')))
    data[t]=rows
    record(t+' header order',list(rows[0])==[c for c,_,_ in cols])
    parsed=[]
    for r in rows:
        row=[]
        for c,ty,nn in cols:
            v=r[c]
            if not v:
                assert nn!='NOT NULL',(t,c,'NULL in required column')
                row.append(None);continue
            if 'CHAR' in ty:
                limit=int(re.search(r'\d+',ty).group())
                assert len(v)<=limit,(t,c,len(v),limit)
                row.append(v)
            elif ty.startswith('DECIMAL'):
                d=Decimal(v);precision,scale=map(int,re.findall(r'\d+',ty))
                assert d==d.quantize(Decimal(1).scaleb(-scale)),(t,c,v,ty)
                assert abs(d)<10**(precision-scale),(t,c,v,ty)
                row.append(float(d))
            elif ty in ('INT','BIT'):
                d=Decimal(v);assert d==int(d),(t,c,v)
                if ty=='BIT':assert d in (0,1)
                row.append(int(d))
            elif ty=='DATE':row.append(datetime.fromisoformat(v).date().isoformat())
            else:datetime.fromisoformat(v);row.append(v)
        parsed.append(row)
    for layer in ['bronze','silver']:
        db.execute('CREATE TABLE '+layer+'_'+t+' ('+','.join('['+c+'] '+('TEXT' if ('CHAR' in ty or ty.startswith('DATE')) else 'NUMERIC') for c,ty,_ in cols)+')')
        db.executemany('INSERT INTO '+layer+'_'+t+' VALUES ('+','.join('?' for _ in cols)+')',parsed)
    record(t+' typed source validation',True,len(rows))
    key=meta['pk'][t];record(t+' primary key',len({r[key] for r in rows})==len(rows))
for t,rels in meta['fks'].items():
    for c,parent,pc in rels:
        parentkeys={r[pc] for r in data[parent]}
        record(t+'.'+c+' FK',all(not r[c] or r[c] in parentkeys for r in data[t]))

# Compile the SELECT portions under SQLite, adapting only SQL Server-specific APPLY.
gold=(ROOT/'scripts/05_Create_Gold.sql').read_text(encoding='utf-8-sig')
views=re.findall(r'CREATE OR ALTER VIEW gold\.(\w+)\s*\nAS\n(.*?)\nGO',gold,re.S)
for name,body in views:
    if name=='vw_FactPurchaseOrderDetail':
        paircounts=collections.Counter((r['supplier_id'],r['material_id']) for r in data['SupplierMaterials'])
        assert max(paircounts.values())==1,'APPLY emulation requires unique supplied supplier/material pairs'
        body=re.sub(r'OUTER APPLY\s*\(.*?\) sm;', 'LEFT JOIN silver.SupplierMaterials sm ON sm.supplier_id=po.supplier_id AND sm.material_id=pod.material_id;',body,flags=re.S)
    db.execute('CREATE VIEW gold_'+name+' AS '+sql(body))
    count=db.execute('SELECT COUNT(*) FROM gold_'+name).fetchone()[0]
    record(name+' relational evaluation',True,count)

qa=(ROOT/'scripts/06_Validate_Data.sql').read_text(encoding='utf-8-sig')
for label,q in re.findall(r"INSERT #Checks SELECT N'((?:''|[^'])*)', \((.*?)\);",qa,re.S):
    if label=='Production material cost rounding':
        failures=sum(abs(Decimal(r['total_material_cost'])-(Decimal(r['actual_consumed_quantity'])*Decimal(r['unit_cost'])).quantize(Decimal('.01'),rounding=ROUND_HALF_UP))>Decimal('.01') for r in data['ProductionDetails'])
        record(label,failures==0,failures)
        continue
    failures=db.execute(sql(q)).fetchone()[0]
    record(label.replace("''","'"),failures==0,failures)
ordered=sum(Decimal(r['ordered_quantity']) for r in data['SalesOrderDetails'])
shipped=sum(Decimal(r['shipped_quantity']) for r in data['CustomerShipmentDetails'])
scrap=sum(Decimal(r['scrap_quantity']) for r in data['ProductionDetails'])
record('200000 business rows',sum(map(len,data.values()))==200000)
record('Fulfillment quantities',ordered==1103908 and shipped==1047057)
record('Exact scrap precision retained',scrap==Decimal('428196.242'),str(scrap))
record('104 open production orders',sum(r['production_status']=='In Progress' for r in data['Production'])==104)
record('822 unshipped lines',db.execute('SELECT COUNT(*) FROM gold_vw_FactSalesFulfillment WHERE shipment_line_count=0').fetchone()[0]==822)
record('Missing emails remain null',sum(not r['email'] for r in data['Customers'])==8)

# Ensure all text maps normalize the injected case variants to a single value.
mapping={(d,k):v for d,k,v in meta['mapping']}
for t,cols in meta['schema'].items():
    for c,ty,nn in cols:
        if 'CHAR' not in ty:continue
        for r in data[t]:
            v=' '.join(r[c].split())
            v=mapping.get((c,v.lower()),v)
            assert v or nn!='NOT NULL',(t,c,'empty after cleaning')
            assert len(v)<=int(re.search(r'\d+',ty).group()),(t,c,'canonical value too long')
record('Cleaned text nullability and lengths',True)
for domain,values in [('city',['Cairo','cairo']),('customer_type',['Reseller','RESELLER']),('material_category',['Display','display'])]:
    record('Canonical '+domain,len({mapping[(domain,v.lower())] for v in values})==1)

# Static checks of deliverables: table shape, order, all numeric fields mapped directly.
for layer,file in [('bronze','01_Create_Bronze.sql'),('silver','03_Create_Silver.sql')]:
    source=(ROOT/'scripts'/file).read_text(encoding='utf-8-sig')
    record(layer+' 31 create statements',len(re.findall('CREATE TABLE '+layer,source))==31)
    record(layer+' no trailing column comma',not re.search(r',\s*\);',source))
loader=(ROOT/'scripts/04_Load_Silver.sql').read_text(encoding='utf-8-sig').split('CREATE OR ALTER PROCEDURE etl.LoadSilver')[1]
record('No silent numeric coercion',all(x not in loader for x in ['TRY_CONVERT','COALESCE','ROUND(']))
report={'engine':'Python Decimal + SQLite relational emulation; NOT SQL Server execution',
        'passed':sum(r['passed'] for r in results),'failed':sum(not r['passed'] for r in results),
        'quantity_fill_rate_pct':str(shipped/ordered*100),'checks':results}
(ROOT/'tests/verification_results.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='checks'},indent=2))
for r in results:
    if not r['passed']:print('FAIL',r)
assert report['failed']==0

# Power BI relationship plan: shared dimensions -> facts, single direction.
main_dates={
 'PurchaseRequisition':'request_date','PurchaseOrderDetail':'order_date',
 'SupplierShipment':'expected_arrival_date','SupplierShipmentDetail':'expected_arrival_date',
 'GoodsReceiptDetail':'receipt_date','QualityInspection':'inspection_date',
 'RawInventoryTransaction':'transaction_day','ProductionOrder':'start_date',
 'ProductionMaterial':'start_date','FinishedGoodsTransaction':'transaction_day',
 'SalesOrderDetail':'order_date','CustomerShipment':'expected_delivery_date',
 'CustomerShipmentDetail':'shipment_date','Return':'return_request_date',
 'SalesFulfillment':'order_date','SupplierInvoice':'invoice_date',
 'SupplierInvoiceDetail':'invoice_date','SupplierPayment':'payment_date'}
dims={'department_id':'Department','supplier_id':'Supplier','material_id':'Material','product_id':'Product','customer_id':'Customer','warehouse_id':'Warehouse'}
with (ROOT/'PowerBI_Relationships.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['OneTable','OneColumn','ManyTable','ManyColumn','Cardinality','CrossFilter','Active','Note'])
    for name,body in views:
        if not name.startswith('vw_Fact'):continue
        columns=[x[1] for x in db.execute('PRAGMA table_info(gold_'+name+')')]
        for c,dim in dims.items():
            if c in columns:w.writerow(['gold.vw_Dim'+dim,c,'gold.'+name,c,'1:*','Single','Yes','Shared dimension; no fact-to-fact relationship'])
        main=main_dates.get(name.removeprefix('vw_Fact'))
        if main:w.writerow(['gold.DimDate','full_date','gold.'+name,main,'1:*','Single','Yes','Default date role; review with report question'])
        for c in columns:
            if (c.endswith('_date') or c=='transaction_day') and c!=main and c not in ('created_date','transaction_date'):
                w.writerow(['gold.DimDate','full_date','gold.'+name,c,'1:*','Single','No','Alternative date role; explicit DAX required'])
with (ROOT/'Data_Dictionary.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['Layer','Table','Column','SQLType','Nullable','PrimaryKey'])
    for layer in ['bronze','silver']:
        for t,cols in meta['schema'].items():
            for c,ty,nn in cols:w.writerow([layer,t,c,ty,nn=='NULL',layer=='silver' and c==meta['pk'][t]])
