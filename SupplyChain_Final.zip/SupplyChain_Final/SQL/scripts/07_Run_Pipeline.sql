﻿USE [ElectronicsSupplyChainDB_v2];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO
CREATE OR ALTER PROCEDURE etl.RefreshAll
 @DataFolder NVARCHAR(3000),
 @CheckSampleBaseline BIT=1
AS
BEGIN
 SET NOCOUNT ON;
 SET XACT_ABORT ON;
 IF @@TRANCOUNT<>0 THROW 51006, 'RefreshAll must not run inside an existing transaction.', 1;
 INSERT etl.RunLog(run_status) VALUES('RUNNING');
 DECLARE @RunID BIGINT=SCOPE_IDENTITY(),@LockResult INT;
 BEGIN TRY
  BEGIN TRANSACTION;
  EXEC @LockResult=sys.sp_getapplock @Resource=N'ElectronicsSupplyChain.Refresh',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=0;
  IF @LockResult<0 THROW 51007, 'Another refresh is running. Try again after it completes.', 1;
  EXEC etl.LoadBronze @DataFolder=@DataFolder;
  EXEC etl.LoadSilver;
  EXEC etl.RefreshDimDate;
  EXEC etl.ValidateData @CheckSampleBaseline=@CheckSampleBaseline;
  UPDATE etl.RunLog SET run_status='SUCCESS',completed_at=SYSDATETIME() WHERE run_id=@RunID;
  COMMIT;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK;
  UPDATE etl.RunLog SET run_status='FAILED',completed_at=SYSDATETIME(),error_message=ERROR_MESSAGE() WHERE run_id=@RunID;
  THROW;
 END CATCH;
 SELECT * FROM etl.RunLog WHERE run_id=@RunID;
END;
GO
-- Change only this path to the extracted raw_data directory, as seen by SQL Server.
-- SQL Server service account needs read access. Run after scripts 00 through 06.
EXEC etl.RefreshAll @DataFolder=N'C:\ElectronicsSupplyChain_SQL_v2\raw_data', @CheckSampleBaseline=1;
GO
