﻿USE [ElectronicsSupplyChainDB_v2];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO
CREATE OR ALTER FUNCTION etl.CleanText(@value VARCHAR(4000))
RETURNS VARCHAR(4000)
AS
BEGIN
 SET @value=TRIM(REPLACE(REPLACE(REPLACE(@value,CHAR(13),' '),CHAR(10),' '),CHAR(9),' '));
 WHILE CHARINDEX('  ',@value)>0 SET @value=REPLACE(@value,'  ',' ');
 RETURN NULLIF(@value,'');
END;
GO
IF OBJECT_ID(N'etl.TextMap',N'U') IS NULL
CREATE TABLE etl.TextMap
(
 domain VARCHAR(80) NOT NULL,
 normalized_value VARCHAR(250) NOT NULL,
 canonical_value VARCHAR(250) NOT NULL,
 CONSTRAINT PK_TextMap PRIMARY KEY(domain,normalized_value)
);
GO
-- Existing user-edited dictionary values are preserved on reinstall.
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'approval_status' AND normalized_value=N'approved')
 INSERT etl.TextMap VALUES (N'approval_status',N'approved',N'Approved');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'approval_status' AND normalized_value=N'rejected')
 INSERT etl.TextMap VALUES (N'approval_status',N'rejected',N'Rejected');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'al sharqia')
 INSERT etl.TextMap VALUES (N'city',N'al sharqia',N'Al Sharqia');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'alexandria')
 INSERT etl.TextMap VALUES (N'city',N'alexandria',N'Alexandria');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'assiut')
 INSERT etl.TextMap VALUES (N'city',N'assiut',N'Assiut');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'aswan')
 INSERT etl.TextMap VALUES (N'city',N'aswan',N'Aswan');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'beheira')
 INSERT etl.TextMap VALUES (N'city',N'beheira',N'Beheira');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'beni suef')
 INSERT etl.TextMap VALUES (N'city',N'beni suef',N'Beni Suef');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'cairo')
 INSERT etl.TextMap VALUES (N'city',N'cairo',N'Cairo');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'dakahlia')
 INSERT etl.TextMap VALUES (N'city',N'dakahlia',N'Dakahlia');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'damietta')
 INSERT etl.TextMap VALUES (N'city',N'damietta',N'Damietta');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'fayoum')
 INSERT etl.TextMap VALUES (N'city',N'fayoum',N'Fayoum');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'gharbia')
 INSERT etl.TextMap VALUES (N'city',N'gharbia',N'Gharbia');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'giza')
 INSERT etl.TextMap VALUES (N'city',N'giza',N'Giza');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'ismailia')
 INSERT etl.TextMap VALUES (N'city',N'ismailia',N'Ismailia');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'kafr el sheikh')
 INSERT etl.TextMap VALUES (N'city',N'kafr el sheikh',N'Kafr El Sheikh');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'luxor')
 INSERT etl.TextMap VALUES (N'city',N'luxor',N'Luxor');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'minya')
 INSERT etl.TextMap VALUES (N'city',N'minya',N'Minya');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'monufia')
 INSERT etl.TextMap VALUES (N'city',N'monufia',N'Monufia');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'north sinai')
 INSERT etl.TextMap VALUES (N'city',N'north sinai',N'North Sinai');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'port said')
 INSERT etl.TextMap VALUES (N'city',N'port said',N'Port Said');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'qalyubia')
 INSERT etl.TextMap VALUES (N'city',N'qalyubia',N'Qalyubia');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'qena')
 INSERT etl.TextMap VALUES (N'city',N'qena',N'Qena');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'red sea')
 INSERT etl.TextMap VALUES (N'city',N'red sea',N'Red Sea');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'sohag')
 INSERT etl.TextMap VALUES (N'city',N'sohag',N'Sohag');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'suez')
 INSERT etl.TextMap VALUES (N'city',N'suez',N'Suez');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'country' AND normalized_value=N'egypt')
 INSERT etl.TextMap VALUES (N'country',N'egypt',N'Egypt');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'customer_type' AND normalized_value=N'corporate customer')
 INSERT etl.TextMap VALUES (N'customer_type',N'corporate customer',N'Corporate Customer');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'customer_type' AND normalized_value=N'distributor')
 INSERT etl.TextMap VALUES (N'customer_type',N'distributor',N'Distributor');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'customer_type' AND normalized_value=N'e-commerce retailer')
 INSERT etl.TextMap VALUES (N'customer_type',N'e-commerce retailer',N'E-commerce Retailer');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'customer_type' AND normalized_value=N'regional distributor')
 INSERT etl.TextMap VALUES (N'customer_type',N'regional distributor',N'Regional Distributor');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'customer_type' AND normalized_value=N'reseller')
 INSERT etl.TextMap VALUES (N'customer_type',N'reseller',N'Reseller');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'customer_type' AND normalized_value=N'retail chain')
 INSERT etl.TextMap VALUES (N'customer_type',N'retail chain',N'Retail Chain');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'defect_reason' AND normalized_value=N'damaged connector')
 INSERT etl.TextMap VALUES (N'defect_reason',N'damaged connector',N'Damaged connector');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'defect_reason' AND normalized_value=N'electrical test failure')
 INSERT etl.TextMap VALUES (N'defect_reason',N'electrical test failure',N'Electrical test failure');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'defect_reason' AND normalized_value=N'no defect')
 INSERT etl.TextMap VALUES (N'defect_reason',N'no defect',N'No Defect');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'defect_reason' AND normalized_value=N'packaging damage')
 INSERT etl.TextMap VALUES (N'defect_reason',N'packaging damage',N'Packaging damage');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'defect_reason' AND normalized_value=N'specification deviation')
 INSERT etl.TextMap VALUES (N'defect_reason',N'specification deviation',N'Specification deviation');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'defect_reason' AND normalized_value=N'surface defect')
 INSERT etl.TextMap VALUES (N'defect_reason',N'surface defect',N'Surface defect');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'inspection_result' AND normalized_value=N'partial acceptance')
 INSERT etl.TextMap VALUES (N'inspection_result',N'partial acceptance',N'Partial Acceptance');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'inspection_result' AND normalized_value=N'passed')
 INSERT etl.TextMap VALUES (N'inspection_result',N'passed',N'Passed');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'inspection_status' AND normalized_value=N'accepted')
 INSERT etl.TextMap VALUES (N'inspection_status',N'accepted',N'Accepted');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'inspection_status' AND normalized_value=N'partially accepted')
 INSERT etl.TextMap VALUES (N'inspection_status',N'partially accepted',N'Partially Accepted');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'inspection_type' AND normalized_value=N'incoming material inspection')
 INSERT etl.TextMap VALUES (N'inspection_type',N'incoming material inspection',N'Incoming Material Inspection');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'line_status' AND normalized_value=N'closed')
 INSERT etl.TextMap VALUES (N'line_status',N'closed',N'Closed');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'line_status' AND normalized_value=N'fulfilled')
 INSERT etl.TextMap VALUES (N'line_status',N'fulfilled',N'Fulfilled');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'line_status' AND normalized_value=N'partially fulfilled')
 INSERT etl.TextMap VALUES (N'line_status',N'partially fulfilled',N'Partially Fulfilled');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_category' AND normalized_value=N'battery and power')
 INSERT etl.TextMap VALUES (N'material_category',N'battery and power',N'Battery and Power');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_category' AND normalized_value=N'camera audio and sensors')
 INSERT etl.TextMap VALUES (N'material_category',N'camera audio and sensors',N'Camera Audio and Sensors');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_category' AND normalized_value=N'display')
 INSERT etl.TextMap VALUES (N'material_category',N'display',N'Display');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_category' AND normalized_value=N'enclosure and mechanical')
 INSERT etl.TextMap VALUES (N'material_category',N'enclosure and mechanical',N'Enclosure and Mechanical');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_category' AND normalized_value=N'memory and storage')
 INSERT etl.TextMap VALUES (N'material_category',N'memory and storage',N'Memory and Storage');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_category' AND normalized_value=N'packaging and accessories')
 INSERT etl.TextMap VALUES (N'material_category',N'packaging and accessories',N'Packaging and Accessories');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_category' AND normalized_value=N'pcb and connectivity')
 INSERT etl.TextMap VALUES (N'material_category',N'pcb and connectivity',N'PCB and Connectivity');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_category' AND normalized_value=N'processing')
 INSERT etl.TextMap VALUES (N'material_category',N'processing',N'Processing');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_type' AND normalized_value=N'assembly component')
 INSERT etl.TextMap VALUES (N'material_type',N'assembly component',N'Assembly Component');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_type' AND normalized_value=N'display module')
 INSERT etl.TextMap VALUES (N'material_type',N'display module',N'Display Module');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_type' AND normalized_value=N'electronic component')
 INSERT etl.TextMap VALUES (N'material_type',N'electronic component',N'Electronic Component');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_type' AND normalized_value=N'functional module')
 INSERT etl.TextMap VALUES (N'material_type',N'functional module',N'Functional Module');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_type' AND normalized_value=N'mechanical component')
 INSERT etl.TextMap VALUES (N'material_type',N'mechanical component',N'Mechanical Component');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_type' AND normalized_value=N'packaging material')
 INSERT etl.TextMap VALUES (N'material_type',N'packaging material',N'Packaging Material');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_type' AND normalized_value=N'power component')
 INSERT etl.TextMap VALUES (N'material_type',N'power component',N'Power Component');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'payment_method' AND normalized_value=N'bank transfer')
 INSERT etl.TextMap VALUES (N'payment_method',N'bank transfer',N'Bank Transfer');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'payment_method' AND normalized_value=N'cheque')
 INSERT etl.TextMap VALUES (N'payment_method',N'cheque',N'Cheque');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'payment_method' AND normalized_value=N'credit terms')
 INSERT etl.TextMap VALUES (N'payment_method',N'credit terms',N'Credit Terms');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'payment_method' AND normalized_value=N'electronic payment')
 INSERT etl.TextMap VALUES (N'payment_method',N'electronic payment',N'Electronic Payment');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'payment_method' AND normalized_value=N'electronic transfer')
 INSERT etl.TextMap VALUES (N'payment_method',N'electronic transfer',N'Electronic Transfer');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'payment_status' AND normalized_value=N'completed')
 INSERT etl.TextMap VALUES (N'payment_status',N'completed',N'Completed');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'payment_status' AND normalized_value=N'paid')
 INSERT etl.TextMap VALUES (N'payment_status',N'paid',N'Paid');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'payment_terms' AND normalized_value=N'30% advance - 70% net 30')
 INSERT etl.TextMap VALUES (N'payment_terms',N'30% advance - 70% net 30',N'30% Advance - 70% Net 30');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'payment_terms' AND normalized_value=N'net 30')
 INSERT etl.TextMap VALUES (N'payment_terms',N'net 30',N'Net 30');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'payment_terms' AND normalized_value=N'net 45')
 INSERT etl.TextMap VALUES (N'payment_terms',N'net 45',N'Net 45');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'priority' AND normalized_value=N'high')
 INSERT etl.TextMap VALUES (N'priority',N'high',N'High');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'priority' AND normalized_value=N'normal')
 INSERT etl.TextMap VALUES (N'priority',N'normal',N'Normal');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'priority' AND normalized_value=N'urgent')
 INSERT etl.TextMap VALUES (N'priority',N'urgent',N'Urgent');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'product_category' AND normalized_value=N'earbuds')
 INSERT etl.TextMap VALUES (N'product_category',N'earbuds',N'Earbuds');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'product_category' AND normalized_value=N'laptop')
 INSERT etl.TextMap VALUES (N'product_category',N'laptop',N'Laptop');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'product_category' AND normalized_value=N'smartphone')
 INSERT etl.TextMap VALUES (N'product_category',N'smartphone',N'Smartphone');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'product_category' AND normalized_value=N'smartwatch')
 INSERT etl.TextMap VALUES (N'product_category',N'smartwatch',N'Smartwatch');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'product_condition' AND normalized_value=N'damaged')
 INSERT etl.TextMap VALUES (N'product_condition',N'damaged',N'Damaged');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'product_condition' AND normalized_value=N'defective')
 INSERT etl.TextMap VALUES (N'product_condition',N'defective',N'Defective');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'product_condition' AND normalized_value=N'good')
 INSERT etl.TextMap VALUES (N'product_condition',N'good',N'Good');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'product_condition' AND normalized_value=N'not working')
 INSERT etl.TextMap VALUES (N'product_condition',N'not working',N'Not Working');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'product_condition' AND normalized_value=N'unopened')
 INSERT etl.TextMap VALUES (N'product_condition',N'unopened',N'Unopened');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'production_status' AND normalized_value=N'completed')
 INSERT etl.TextMap VALUES (N'production_status',N'completed',N'Completed');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'production_status' AND normalized_value=N'in progress')
 INSERT etl.TextMap VALUES (N'production_status',N'in progress',N'In Progress');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'quality_check_status' AND normalized_value=N'completed')
 INSERT etl.TextMap VALUES (N'quality_check_status',N'completed',N'Completed');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'return_reason' AND normalized_value=N'customer changed purchase plan')
 INSERT etl.TextMap VALUES (N'return_reason',N'customer changed purchase plan',N'Customer changed purchase plan');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'return_reason' AND normalized_value=N'customer ordered excess quantity')
 INSERT etl.TextMap VALUES (N'return_reason',N'customer ordered excess quantity',N'Customer ordered excess quantity');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'return_reason' AND normalized_value=N'device did not power on')
 INSERT etl.TextMap VALUES (N'return_reason',N'device did not power on',N'Device did not power on');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'return_reason' AND normalized_value=N'product performance defect')
 INSERT etl.TextMap VALUES (N'return_reason',N'product performance defect',N'Product performance defect');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'return_reason' AND normalized_value=N'transit or packaging damage')
 INSERT etl.TextMap VALUES (N'return_reason',N'transit or packaging damage',N'Transit or packaging damage');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'return_status' AND normalized_value=N'completed')
 INSERT etl.TextMap VALUES (N'return_status',N'completed',N'Completed');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'sales_order_status' AND normalized_value=N'completed')
 INSERT etl.TextMap VALUES (N'sales_order_status',N'completed',N'Completed');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'sales_order_status' AND normalized_value=N'partially fulfilled')
 INSERT etl.TextMap VALUES (N'sales_order_status',N'partially fulfilled',N'Partially Fulfilled');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'sales_order_status' AND normalized_value=N'shipped')
 INSERT etl.TextMap VALUES (N'sales_order_status',N'shipped',N'Shipped');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'shipment_status' AND normalized_value=N'delayed')
 INSERT etl.TextMap VALUES (N'shipment_status',N'delayed',N'Delayed');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'shipment_status' AND normalized_value=N'delivered')
 INSERT etl.TextMap VALUES (N'shipment_status',N'delivered',N'Delivered');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'shipment_status' AND normalized_value=N'delivered late')
 INSERT etl.TextMap VALUES (N'shipment_status',N'delivered late',N'Delivered Late');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'shipment_status' AND normalized_value=N'delivery exception')
 INSERT etl.TextMap VALUES (N'shipment_status',N'delivery exception',N'Delivery Exception');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'shipment_status' AND normalized_value=N'in transit')
 INSERT etl.TextMap VALUES (N'shipment_status',N'in transit',N'In Transit');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'shipping_method' AND normalized_value=N'dedicated truck')
 INSERT etl.TextMap VALUES (N'shipping_method',N'dedicated truck',N'Dedicated Truck');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'shipping_method' AND normalized_value=N'domestic courier')
 INSERT etl.TextMap VALUES (N'shipping_method',N'domestic courier',N'Domestic Courier');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'status' AND normalized_value=N'active')
 INSERT etl.TextMap VALUES (N'status',N'active',N'Active');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'status' AND normalized_value=N'closed')
 INSERT etl.TextMap VALUES (N'status',N'closed',N'Closed');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'status' AND normalized_value=N'completed')
 INSERT etl.TextMap VALUES (N'status',N'completed',N'Completed');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'status' AND normalized_value=N'inactive')
 INSERT etl.TextMap VALUES (N'status',N'inactive',N'Inactive');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'supplier_category' AND normalized_value=N'industrial wholesaler')
 INSERT etl.TextMap VALUES (N'supplier_category',N'industrial wholesaler',N'Industrial Wholesaler');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'supplier_category' AND normalized_value=N'local distributor')
 INSERT etl.TextMap VALUES (N'supplier_category',N'local distributor',N'Local Distributor');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'supplier_category' AND normalized_value=N'local manufacturer')
 INSERT etl.TextMap VALUES (N'supplier_category',N'local manufacturer',N'Local Manufacturer');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'supplier_type' AND normalized_value=N'component supplier')
 INSERT etl.TextMap VALUES (N'supplier_type',N'component supplier',N'Component Supplier');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'supplier_type' AND normalized_value=N'materials supplier')
 INSERT etl.TextMap VALUES (N'supplier_type',N'materials supplier',N'Materials Supplier');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'supplier_type' AND normalized_value=N'packaging supplier')
 INSERT etl.TextMap VALUES (N'supplier_type',N'packaging supplier',N'Packaging Supplier');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'transaction_type' AND normalized_value=N'customer return')
 INSERT etl.TextMap VALUES (N'transaction_type',N'customer return',N'Customer Return');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'transaction_type' AND normalized_value=N'customer shipment')
 INSERT etl.TextMap VALUES (N'transaction_type',N'customer shipment',N'Customer Shipment');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'transaction_type' AND normalized_value=N'cycle count adjustment in')
 INSERT etl.TextMap VALUES (N'transaction_type',N'cycle count adjustment in',N'Cycle Count Adjustment In');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'transaction_type' AND normalized_value=N'opening balance')
 INSERT etl.TextMap VALUES (N'transaction_type',N'opening balance',N'Opening Balance');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'transaction_type' AND normalized_value=N'production issue')
 INSERT etl.TextMap VALUES (N'transaction_type',N'production issue',N'Production Issue');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'transaction_type' AND normalized_value=N'production receipt')
 INSERT etl.TextMap VALUES (N'transaction_type',N'production receipt',N'Production Receipt');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'transaction_type' AND normalized_value=N'quality receipt')
 INSERT etl.TextMap VALUES (N'transaction_type',N'quality receipt',N'Quality Receipt');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'transaction_type' AND normalized_value=N'warehouse transfer in')
 INSERT etl.TextMap VALUES (N'transaction_type',N'warehouse transfer in',N'Warehouse Transfer In');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'transaction_type' AND normalized_value=N'warehouse transfer out')
 INSERT etl.TextMap VALUES (N'transaction_type',N'warehouse transfer out',N'Warehouse Transfer Out');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'uom' AND normalized_value=N'piece')
 INSERT etl.TextMap VALUES (N'uom',N'piece',N'Piece');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'warehouse_type' AND normalized_value=N'finished goods')
 INSERT etl.TextMap VALUES (N'warehouse_type',N'finished goods',N'Finished Goods');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'warehouse_type' AND normalized_value=N'raw material')
 INSERT etl.TextMap VALUES (N'warehouse_type',N'raw material',N'Raw Material');
GO
CREATE OR ALTER FUNCTION etl.CanonicalText(@domain VARCHAR(80),@value VARCHAR(4000))
RETURNS VARCHAR(4000)
AS
BEGIN
 DECLARE @clean VARCHAR(4000)=etl.CleanText(@value), @result VARCHAR(250);
 SELECT @result=canonical_value FROM etl.TextMap WHERE domain=@domain AND normalized_value=LOWER(@clean);
 RETURN COALESCE(@result,@clean);
END;
GO
CREATE OR ALTER PROCEDURE etl.LoadSilver
AS
BEGIN
 SET NOCOUNT ON;
 SET XACT_ABORT ON;
 IF @@TRANCOUNT=0 THROW 51002, 'Run etl.RefreshAll; this loader requires its transaction.', 1;
 DELETE FROM silver.[Returns];
 DELETE FROM silver.[FinishedGoodsInventoryTransactions];
 DELETE FROM silver.[CustomerShipmentDetails];
 DELETE FROM silver.[CustomerShipments];
 DELETE FROM silver.[SalesOrderDetails];
 DELETE FROM silver.[SalesOrders];
 DELETE FROM silver.[Customers];
 DELETE FROM silver.[FinishedGoodsInventory];
 DELETE FROM silver.[RawMaterialInventoryTransactions];
 DELETE FROM silver.[ProductionDetails];
 DELETE FROM silver.[Production];
 DELETE FROM silver.[ProductBOM];
 DELETE FROM silver.[Products];
 DELETE FROM silver.[RawMaterialInventory];
 DELETE FROM silver.[Warehouses];
 DELETE FROM silver.[SupplierPayments];
 DELETE FROM silver.[SupplierInvoiceDetails];
 DELETE FROM silver.[SupplierInvoices];
 DELETE FROM silver.[QualityInspections];
 DELETE FROM silver.[GoodsReceiptDetails];
 DELETE FROM silver.[GoodsReceipts];
 DELETE FROM silver.[SupplierShipmentDetails];
 DELETE FROM silver.[SupplierShipments];
 DELETE FROM silver.[PurchaseOrderDetails];
 DELETE FROM silver.[PurchaseOrders];
 DELETE FROM silver.[PurchaseRequisitionDetails];
 DELETE FROM silver.[PurchaseRequisitions];
 DELETE FROM silver.[SupplierMaterials];
 DELETE FROM silver.[Suppliers];
 DELETE FROM silver.[Materials];
 DELETE FROM silver.[Departments];
 INSERT silver.[Departments] ([department_id], [department_code], [department_name], [department_description], [status])
 SELECT [department_id],
        UPPER(etl.CleanText([department_code])),
        etl.CleanText([department_name]),
        etl.CleanText([department_description]),
        etl.CanonicalText('status',[status])
 FROM bronze.[Departments];
 INSERT silver.[Materials] ([material_id], [material_code], [material_name], [material_category], [material_type], [uom], [unit_weight], [status])
 SELECT [material_id],
        UPPER(etl.CleanText([material_code])),
        etl.CleanText([material_name]),
        etl.CanonicalText('material_category',[material_category]),
        etl.CanonicalText('material_type',[material_type]),
        etl.CanonicalText('uom',[uom]),
        [unit_weight],
        etl.CanonicalText('status',[status])
 FROM bronze.[Materials];
 INSERT silver.[Suppliers] ([supplier_id], [supplier_code], [supplier_name], [supplier_type], [supplier_category], [country], [city], [address], [contact_person], [phone], [email], [payment_terms], [status])
 SELECT [supplier_id],
        UPPER(etl.CleanText([supplier_code])),
        etl.CleanText([supplier_name]),
        etl.CanonicalText('supplier_type',[supplier_type]),
        etl.CanonicalText('supplier_category',[supplier_category]),
        etl.CanonicalText('country',[country]),
        etl.CanonicalText('city',[city]),
        etl.CleanText([address]),
        etl.CleanText([contact_person]),
        etl.CleanText([phone]),
        LOWER(etl.CleanText([email])),
        etl.CanonicalText('payment_terms',[payment_terms]),
        etl.CanonicalText('status',[status])
 FROM bronze.[Suppliers];
 INSERT silver.[SupplierMaterials] ([supplier_material_id], [supplier_id], [material_id], [supplier_material_code], [standard_price], [lead_time_days], [minimum_order_quantity], [preferred_supplier], [status])
 SELECT [supplier_material_id],
        [supplier_id],
        [material_id],
        UPPER(etl.CleanText([supplier_material_code])),
        [standard_price],
        [lead_time_days],
        [minimum_order_quantity],
        [preferred_supplier],
        etl.CanonicalText('status',[status])
 FROM bronze.[SupplierMaterials];
 INSERT silver.[PurchaseRequisitions] ([pr_id], [pr_code], [department_id], [requested_by], [request_date], [order_date], [required_date], [priority], [approval_status], [approved_by], [approval_date], [rejection_reason], [created_date])
 SELECT [pr_id],
        UPPER(etl.CleanText([pr_code])),
        [department_id],
        etl.CleanText([requested_by]),
        [request_date],
        [order_date],
        [required_date],
        etl.CanonicalText('priority',[priority]),
        etl.CanonicalText('approval_status',[approval_status]),
        etl.CleanText([approved_by]),
        [approval_date],
        etl.CleanText([rejection_reason]),
        [created_date]
 FROM bronze.[PurchaseRequisitions];
 INSERT silver.[PurchaseRequisitionDetails] ([pr_detail_id], [pr_id], [material_id], [requested_quantity], [estimated_unit_cost])
 SELECT [pr_detail_id],
        [pr_id],
        [material_id],
        [requested_quantity],
        [estimated_unit_cost]
 FROM bronze.[PurchaseRequisitionDetails];
 INSERT silver.[PurchaseOrders] ([po_id], [po_code], [supplier_id], [pr_id], [order_date], [expected_delivery_date], [payment_terms], [status])
 SELECT [po_id],
        UPPER(etl.CleanText([po_code])),
        [supplier_id],
        [pr_id],
        [order_date],
        [expected_delivery_date],
        etl.CanonicalText('payment_terms',[payment_terms]),
        etl.CanonicalText('status',[status])
 FROM bronze.[PurchaseOrders];
 INSERT silver.[PurchaseOrderDetails] ([po_detail_id], [po_id], [pr_detail_id], [material_id], [ordered_quantity], [unit_price], [discount_percentage], [expected_delivery_date], [total_amount], [line_status])
 SELECT [po_detail_id],
        [po_id],
        [pr_detail_id],
        [material_id],
        [ordered_quantity],
        [unit_price],
        [discount_percentage],
        [expected_delivery_date],
        [total_amount],
        etl.CanonicalText('line_status',[line_status])
 FROM bronze.[PurchaseOrderDetails];
 INSERT silver.[SupplierShipments] ([shipment_id], [shipment_code], [po_id], [supplier_id], [supplier_reference], [ship_date], [expected_arrival_date], [actual_arrival_date], [total_shipment_value], [shipping_cost])
 SELECT [shipment_id],
        UPPER(etl.CleanText([shipment_code])),
        [po_id],
        [supplier_id],
        etl.CleanText([supplier_reference]),
        [ship_date],
        [expected_arrival_date],
        [actual_arrival_date],
        [total_shipment_value],
        [shipping_cost]
 FROM bronze.[SupplierShipments];
 INSERT silver.[SupplierShipmentDetails] ([shipment_detail_id], [shipment_id], [po_detail_id], [material_id], [received_quantity], [accepted_quantity], [rejected_quantity])
 SELECT [shipment_detail_id],
        [shipment_id],
        [po_detail_id],
        [material_id],
        [received_quantity],
        [accepted_quantity],
        [rejected_quantity]
 FROM bronze.[SupplierShipmentDetails];
 INSERT silver.[GoodsReceipts] ([gr_id], [gr_code], [shipment_id], [receipt_date], [received_by], [quality_check_status], [total_received_value])
 SELECT [gr_id],
        UPPER(etl.CleanText([gr_code])),
        [shipment_id],
        [receipt_date],
        etl.CleanText([received_by]),
        etl.CanonicalText('quality_check_status',[quality_check_status]),
        [total_received_value]
 FROM bronze.[GoodsReceipts];
 INSERT silver.[GoodsReceiptDetails] ([gr_detail_id], [gr_id], [shipment_detail_id], [material_id], [received_quantity], [accepted_quantity], [rejected_quantity], [inspection_status], [batch_number])
 SELECT [gr_detail_id],
        [gr_id],
        [shipment_detail_id],
        [material_id],
        [received_quantity],
        [accepted_quantity],
        [rejected_quantity],
        etl.CanonicalText('inspection_status',[inspection_status]),
        etl.CleanText([batch_number])
 FROM bronze.[GoodsReceiptDetails];
 INSERT silver.[QualityInspections] ([inspection_id], [gr_detail_id], [inspection_date], [inspection_type], [inspected_quantity], [passed_quantity], [inspection_result], [defect_quantity], [defect_reason], [corrective_action], [reinspection_required], [status])
 SELECT [inspection_id],
        [gr_detail_id],
        [inspection_date],
        etl.CanonicalText('inspection_type',[inspection_type]),
        [inspected_quantity],
        [passed_quantity],
        etl.CanonicalText('inspection_result',[inspection_result]),
        [defect_quantity],
        etl.CanonicalText('defect_reason',[defect_reason]),
        etl.CleanText([corrective_action]),
        [reinspection_required],
        etl.CanonicalText('status',[status])
 FROM bronze.[QualityInspections];
 INSERT silver.[SupplierInvoices] ([invoice_id], [invoice_number], [shipment_id], [supplier_id], [invoice_date], [invoice_amount], [tax_amount], [total_amount], [due_date], [payment_terms], [payment_status])
 SELECT [invoice_id],
        etl.CleanText([invoice_number]),
        [shipment_id],
        [supplier_id],
        [invoice_date],
        [invoice_amount],
        [tax_amount],
        [total_amount],
        [due_date],
        etl.CanonicalText('payment_terms',[payment_terms]),
        etl.CanonicalText('payment_status',[payment_status])
 FROM bronze.[SupplierInvoices];
 INSERT silver.[SupplierInvoiceDetails] ([invoice_detail_id], [invoice_id], [gr_detail_id], [billed_quantity], [unit_price], [tax_amount], [line_amount])
 SELECT [invoice_detail_id],
        [invoice_id],
        [gr_detail_id],
        [billed_quantity],
        [unit_price],
        [tax_amount],
        [line_amount]
 FROM bronze.[SupplierInvoiceDetails];
 INSERT silver.[SupplierPayments] ([payment_id], [invoice_id], [payment_date], [payment_amount], [payment_method], [currency], [transaction_reference], [payment_status])
 SELECT [payment_id],
        [invoice_id],
        [payment_date],
        [payment_amount],
        etl.CanonicalText('payment_method',[payment_method]),
        UPPER(etl.CleanText([currency])),
        etl.CleanText([transaction_reference]),
        etl.CanonicalText('payment_status',[payment_status])
 FROM bronze.[SupplierPayments];
 INSERT silver.[Warehouses] ([warehouse_id], [warehouse_code], [warehouse_name], [warehouse_type], [country], [city], [location_description], [status])
 SELECT [warehouse_id],
        UPPER(etl.CleanText([warehouse_code])),
        etl.CleanText([warehouse_name]),
        etl.CanonicalText('warehouse_type',[warehouse_type]),
        etl.CanonicalText('country',[country]),
        etl.CanonicalText('city',[city]),
        etl.CleanText([location_description]),
        etl.CanonicalText('status',[status])
 FROM bronze.[Warehouses];
 INSERT silver.[RawMaterialInventory] ([raw_inventory_id], [warehouse_id], [material_id], [quantity_on_hand], [quantity_reserved], [reorder_point], [safety_stock_level], [max_inventory_level], [unit_cost], [last_updated_at])
 SELECT [raw_inventory_id],
        [warehouse_id],
        [material_id],
        [quantity_on_hand],
        [quantity_reserved],
        [reorder_point],
        [safety_stock_level],
        [max_inventory_level],
        [unit_cost],
        [last_updated_at]
 FROM bronze.[RawMaterialInventory];
 INSERT silver.[Products] ([product_id], [product_code], [product_name], [product_category], [uom], [standard_cost], [selling_price], [status])
 SELECT [product_id],
        UPPER(etl.CleanText([product_code])),
        etl.CleanText([product_name]),
        etl.CanonicalText('product_category',[product_category]),
        etl.CanonicalText('uom',[uom]),
        [standard_cost],
        [selling_price],
        etl.CanonicalText('status',[status])
 FROM bronze.[Products];
 INSERT silver.[ProductBOM] ([bom_id], [product_id], [material_id], [quantity_required], [uom], [status])
 SELECT [bom_id],
        [product_id],
        [material_id],
        [quantity_required],
        etl.CanonicalText('uom',[uom]),
        etl.CanonicalText('status',[status])
 FROM bronze.[ProductBOM];
 INSERT silver.[Production] ([production_id], [production_order_code], [product_id], [planned_quantity], [start_date], [expected_end_date], [actual_end_date], [production_quantity], [rejected_quantity], [production_status])
 SELECT [production_id],
        UPPER(etl.CleanText([production_order_code])),
        [product_id],
        [planned_quantity],
        [start_date],
        [expected_end_date],
        [actual_end_date],
        [production_quantity],
        [rejected_quantity],
        etl.CanonicalText('production_status',[production_status])
 FROM bronze.[Production];
 INSERT silver.[ProductionDetails] ([production_detail_id], [production_id], [bom_id], [raw_inventory_id], [actual_consumed_quantity], [return_quantity], [scrap_quantity], [unit_cost], [total_material_cost])
 SELECT [production_detail_id],
        [production_id],
        [bom_id],
        [raw_inventory_id],
        [actual_consumed_quantity],
        [return_quantity],
        [scrap_quantity],
        [unit_cost],
        [total_material_cost]
 FROM bronze.[ProductionDetails];
 INSERT silver.[RawMaterialInventoryTransactions] ([raw_transaction_id], [raw_inventory_id], [production_id], [inspection_id], [transaction_type], [quantity], [unit_cost], [transaction_date], [reference_code])
 SELECT [raw_transaction_id],
        [raw_inventory_id],
        [production_id],
        [inspection_id],
        etl.CanonicalText('transaction_type',[transaction_type]),
        [quantity],
        [unit_cost],
        [transaction_date],
        UPPER(etl.CleanText([reference_code]))
 FROM bronze.[RawMaterialInventoryTransactions];
 INSERT silver.[FinishedGoodsInventory] ([finished_goods_inventory_id], [warehouse_id], [product_id], [quantity_on_hand], [quantity_reserved], [reorder_point], [safety_stock_level], [last_updated_at])
 SELECT [finished_goods_inventory_id],
        [warehouse_id],
        [product_id],
        [quantity_on_hand],
        [quantity_reserved],
        [reorder_point],
        [safety_stock_level],
        [last_updated_at]
 FROM bronze.[FinishedGoodsInventory];
 INSERT silver.[Customers] ([customer_id], [customer_code], [customer_name], [customer_type], [email], [phone], [country], [city], [address], [registration_date], [default_discount_percentage], [status])
 SELECT [customer_id],
        UPPER(etl.CleanText([customer_code])),
        etl.CleanText([customer_name]),
        etl.CanonicalText('customer_type',[customer_type]),
        LOWER(etl.CleanText([email])),
        etl.CleanText([phone]),
        etl.CanonicalText('country',[country]),
        etl.CanonicalText('city',[city]),
        etl.CleanText([address]),
        [registration_date],
        [default_discount_percentage],
        etl.CanonicalText('status',[status])
 FROM bronze.[Customers];
 INSERT silver.[SalesOrders] ([sales_order_id], [sales_order_code], [customer_id], [order_date], [required_delivery_date], [payment_method], [tax_percentage], [sales_order_status])
 SELECT [sales_order_id],
        UPPER(etl.CleanText([sales_order_code])),
        [customer_id],
        [order_date],
        [required_delivery_date],
        etl.CanonicalText('payment_method',[payment_method]),
        [tax_percentage],
        etl.CanonicalText('sales_order_status',[sales_order_status])
 FROM bronze.[SalesOrders];
 INSERT silver.[SalesOrderDetails] ([sales_order_detail_id], [sales_order_id], [product_id], [ordered_quantity], [line_status])
 SELECT [sales_order_detail_id],
        [sales_order_id],
        [product_id],
        [ordered_quantity],
        etl.CanonicalText('line_status',[line_status])
 FROM bronze.[SalesOrderDetails];
 INSERT silver.[CustomerShipments] ([customer_shipment_id], [shipment_code], [sales_order_id], [warehouse_id], [shipment_date], [expected_delivery_date], [actual_delivery_date], [tracking_number], [shipping_method], [shipping_cost], [delivery_address], [shipment_status], [delivery_confirmation], [customer_feedback])
 SELECT [customer_shipment_id],
        UPPER(etl.CleanText([shipment_code])),
        [sales_order_id],
        [warehouse_id],
        [shipment_date],
        [expected_delivery_date],
        [actual_delivery_date],
        etl.CleanText([tracking_number]),
        etl.CanonicalText('shipping_method',[shipping_method]),
        [shipping_cost],
        etl.CleanText([delivery_address]),
        etl.CanonicalText('shipment_status',[shipment_status]),
        [delivery_confirmation],
        etl.CleanText([customer_feedback])
 FROM bronze.[CustomerShipments];
 INSERT silver.[CustomerShipmentDetails] ([customer_shipment_detail_id], [customer_shipment_id], [sales_order_detail_id], [shipped_quantity])
 SELECT [customer_shipment_detail_id],
        [customer_shipment_id],
        [sales_order_detail_id],
        [shipped_quantity]
 FROM bronze.[CustomerShipmentDetails];
 INSERT silver.[FinishedGoodsInventoryTransactions] ([finished_inventory_transaction_id], [finished_goods_inventory_id], [production_id], [customer_shipment_detail_id], [transaction_type], [quantity], [unit_cost], [transaction_date], [reference_code])
 SELECT [finished_inventory_transaction_id],
        [finished_goods_inventory_id],
        [production_id],
        [customer_shipment_detail_id],
        etl.CanonicalText('transaction_type',[transaction_type]),
        [quantity],
        [unit_cost],
        [transaction_date],
        UPPER(etl.CleanText([reference_code]))
 FROM bronze.[FinishedGoodsInventoryTransactions];
 INSERT silver.[Returns] ([return_id], [return_code], [customer_shipment_detail_id], [return_request_date], [return_received_date], [returned_quantity], [return_reason], [product_condition], [return_status])
 SELECT [return_id],
        UPPER(etl.CleanText([return_code])),
        [customer_shipment_detail_id],
        [return_request_date],
        [return_received_date],
        [returned_quantity],
        etl.CanonicalText('return_reason',[return_reason]),
        etl.CanonicalText('product_condition',[product_condition]),
        etl.CanonicalText('return_status',[return_status])
 FROM bronze.[Returns];
END;
GO
