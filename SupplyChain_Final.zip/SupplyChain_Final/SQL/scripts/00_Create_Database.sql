﻿-- SQL Server 2017+ on Windows. New database; original database is untouched.
USE master;
GO
IF DB_ID(N'ElectronicsSupplyChainDB_v2') IS NULL
    EXEC(N'CREATE DATABASE [ElectronicsSupplyChainDB_v2]');
GO
USE [ElectronicsSupplyChainDB_v2];
GO
IF SCHEMA_ID(N'bronze') IS NULL EXEC(N'CREATE SCHEMA bronze AUTHORIZATION dbo');
IF SCHEMA_ID(N'silver') IS NULL EXEC(N'CREATE SCHEMA silver AUTHORIZATION dbo');
IF SCHEMA_ID(N'gold') IS NULL EXEC(N'CREATE SCHEMA gold AUTHORIZATION dbo');
IF SCHEMA_ID(N'etl') IS NULL EXEC(N'CREATE SCHEMA etl AUTHORIZATION dbo');
GO
IF OBJECT_ID(N'etl.RunLog',N'U') IS NULL
CREATE TABLE etl.RunLog
(
 run_id BIGINT IDENTITY PRIMARY KEY,
 started_at DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
 completed_at DATETIME2(0) NULL,
 run_status VARCHAR(20) NOT NULL,
 error_message NVARCHAR(2048) NULL
);
GO
