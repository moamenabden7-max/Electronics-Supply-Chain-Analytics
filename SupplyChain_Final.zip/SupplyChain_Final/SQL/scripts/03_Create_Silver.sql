﻿USE [ElectronicsSupplyChainDB_v2];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO
-- Non-destructive setup. Re-running does not drop existing tables.
IF OBJECT_ID(N'silver.Departments',N'U') IS NULL
CREATE TABLE silver.[Departments]
(
    [department_id] INT NOT NULL,
    [department_code] VARCHAR(20) NOT NULL,
    [department_name] VARCHAR(100) NOT NULL,
    [department_description] VARCHAR(250) NOT NULL,
    [status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_Departments] PRIMARY KEY ([department_id])
);
GO
IF OBJECT_ID(N'silver.Materials',N'U') IS NULL
CREATE TABLE silver.[Materials]
(
    [material_id] INT NOT NULL,
    [material_code] VARCHAR(30) NOT NULL,
    [material_name] VARCHAR(100) NOT NULL,
    [material_category] VARCHAR(60) NOT NULL,
    [material_type] VARCHAR(50) NOT NULL,
    [uom] VARCHAR(20) NOT NULL,
    [unit_weight] DECIMAL(18,3) NOT NULL,
    [status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_Materials] PRIMARY KEY ([material_id])
);
GO
IF OBJECT_ID(N'silver.Suppliers',N'U') IS NULL
CREATE TABLE silver.[Suppliers]
(
    [supplier_id] INT NOT NULL,
    [supplier_code] VARCHAR(30) NOT NULL,
    [supplier_name] VARCHAR(120) NOT NULL,
    [supplier_type] VARCHAR(50) NOT NULL,
    [supplier_category] VARCHAR(50) NOT NULL,
    [country] VARCHAR(50) NOT NULL,
    [city] VARCHAR(50) NOT NULL,
    [address] VARCHAR(250) NOT NULL,
    [contact_person] VARCHAR(100) NOT NULL,
    [phone] VARCHAR(20) NOT NULL,
    [email] VARCHAR(120) NOT NULL,
    [payment_terms] VARCHAR(50) NOT NULL,
    [status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_Suppliers] PRIMARY KEY ([supplier_id])
);
GO
IF OBJECT_ID(N'silver.SupplierMaterials',N'U') IS NULL
CREATE TABLE silver.[SupplierMaterials]
(
    [supplier_material_id] INT NOT NULL,
    [supplier_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [supplier_material_code] VARCHAR(50) NOT NULL,
    [standard_price] DECIMAL(18,2) NOT NULL,
    [lead_time_days] INT NOT NULL,
    [minimum_order_quantity] DECIMAL(18,2) NOT NULL,
    [preferred_supplier] BIT NOT NULL,
    [status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_SupplierMaterials] PRIMARY KEY ([supplier_material_id]),
    CONSTRAINT [FK_SupplierMaterials_supplier_id] FOREIGN KEY ([supplier_id]) REFERENCES silver.[Suppliers] ([supplier_id]),
    CONSTRAINT [FK_SupplierMaterials_material_id] FOREIGN KEY ([material_id]) REFERENCES silver.[Materials] ([material_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SupplierMaterials') AND name=N'IX_SupplierMaterials_supplier_id')
CREATE INDEX [IX_SupplierMaterials_supplier_id] ON silver.[SupplierMaterials] ([supplier_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SupplierMaterials') AND name=N'IX_SupplierMaterials_material_id')
CREATE INDEX [IX_SupplierMaterials_material_id] ON silver.[SupplierMaterials] ([material_id]);
GO
IF OBJECT_ID(N'silver.PurchaseRequisitions',N'U') IS NULL
CREATE TABLE silver.[PurchaseRequisitions]
(
    [pr_id] INT NOT NULL,
    [pr_code] VARCHAR(20) NOT NULL,
    [department_id] INT NOT NULL,
    [requested_by] VARCHAR(100) NOT NULL,
    [request_date] DATE NOT NULL,
    [order_date] DATE NULL,
    [required_date] DATE NOT NULL,
    [priority] VARCHAR(20) NOT NULL,
    [approval_status] VARCHAR(20) NOT NULL,
    [approved_by] VARCHAR(100) NOT NULL,
    [approval_date] DATE NOT NULL,
    [rejection_reason] VARCHAR(250) NULL,
    [created_date] DATE NULL,
    CONSTRAINT [PK_PurchaseRequisitions] PRIMARY KEY ([pr_id]),
    CONSTRAINT [FK_PurchaseRequisitions_department_id] FOREIGN KEY ([department_id]) REFERENCES silver.[Departments] ([department_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.PurchaseRequisitions') AND name=N'IX_PurchaseRequisitions_department_id')
CREATE INDEX [IX_PurchaseRequisitions_department_id] ON silver.[PurchaseRequisitions] ([department_id]);
GO
IF OBJECT_ID(N'silver.PurchaseRequisitionDetails',N'U') IS NULL
CREATE TABLE silver.[PurchaseRequisitionDetails]
(
    [pr_detail_id] INT NOT NULL,
    [pr_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [requested_quantity] DECIMAL(18,2) NOT NULL,
    [estimated_unit_cost] DECIMAL(18,2) NOT NULL,
    CONSTRAINT [PK_PurchaseRequisitionDetails] PRIMARY KEY ([pr_detail_id]),
    CONSTRAINT [FK_PurchaseRequisitionDetails_pr_id] FOREIGN KEY ([pr_id]) REFERENCES silver.[PurchaseRequisitions] ([pr_id]),
    CONSTRAINT [FK_PurchaseRequisitionDetails_material_id] FOREIGN KEY ([material_id]) REFERENCES silver.[Materials] ([material_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.PurchaseRequisitionDetails') AND name=N'IX_PurchaseRequisitionDetails_pr_id')
CREATE INDEX [IX_PurchaseRequisitionDetails_pr_id] ON silver.[PurchaseRequisitionDetails] ([pr_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.PurchaseRequisitionDetails') AND name=N'IX_PurchaseRequisitionDetails_material_id')
CREATE INDEX [IX_PurchaseRequisitionDetails_material_id] ON silver.[PurchaseRequisitionDetails] ([material_id]);
GO
IF OBJECT_ID(N'silver.PurchaseOrders',N'U') IS NULL
CREATE TABLE silver.[PurchaseOrders]
(
    [po_id] INT NOT NULL,
    [po_code] VARCHAR(20) NOT NULL,
    [supplier_id] INT NOT NULL,
    [pr_id] INT NOT NULL,
    [order_date] DATE NOT NULL,
    [expected_delivery_date] DATE NOT NULL,
    [payment_terms] VARCHAR(50) NOT NULL,
    [status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_PurchaseOrders] PRIMARY KEY ([po_id]),
    CONSTRAINT [FK_PurchaseOrders_supplier_id] FOREIGN KEY ([supplier_id]) REFERENCES silver.[Suppliers] ([supplier_id]),
    CONSTRAINT [FK_PurchaseOrders_pr_id] FOREIGN KEY ([pr_id]) REFERENCES silver.[PurchaseRequisitions] ([pr_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.PurchaseOrders') AND name=N'IX_PurchaseOrders_supplier_id')
CREATE INDEX [IX_PurchaseOrders_supplier_id] ON silver.[PurchaseOrders] ([supplier_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.PurchaseOrders') AND name=N'IX_PurchaseOrders_pr_id')
CREATE INDEX [IX_PurchaseOrders_pr_id] ON silver.[PurchaseOrders] ([pr_id]);
GO
IF OBJECT_ID(N'silver.PurchaseOrderDetails',N'U') IS NULL
CREATE TABLE silver.[PurchaseOrderDetails]
(
    [po_detail_id] INT NOT NULL,
    [po_id] INT NOT NULL,
    [pr_detail_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [ordered_quantity] DECIMAL(18,2) NOT NULL,
    [unit_price] DECIMAL(18,2) NOT NULL,
    [discount_percentage] DECIMAL(5,2) NOT NULL,
    [expected_delivery_date] DATE NOT NULL,
    [total_amount] DECIMAL(18,2) NOT NULL,
    [line_status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_PurchaseOrderDetails] PRIMARY KEY ([po_detail_id]),
    CONSTRAINT [FK_PurchaseOrderDetails_po_id] FOREIGN KEY ([po_id]) REFERENCES silver.[PurchaseOrders] ([po_id]),
    CONSTRAINT [FK_PurchaseOrderDetails_pr_detail_id] FOREIGN KEY ([pr_detail_id]) REFERENCES silver.[PurchaseRequisitionDetails] ([pr_detail_id]),
    CONSTRAINT [FK_PurchaseOrderDetails_material_id] FOREIGN KEY ([material_id]) REFERENCES silver.[Materials] ([material_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.PurchaseOrderDetails') AND name=N'IX_PurchaseOrderDetails_po_id')
CREATE INDEX [IX_PurchaseOrderDetails_po_id] ON silver.[PurchaseOrderDetails] ([po_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.PurchaseOrderDetails') AND name=N'IX_PurchaseOrderDetails_pr_detail_id')
CREATE INDEX [IX_PurchaseOrderDetails_pr_detail_id] ON silver.[PurchaseOrderDetails] ([pr_detail_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.PurchaseOrderDetails') AND name=N'IX_PurchaseOrderDetails_material_id')
CREATE INDEX [IX_PurchaseOrderDetails_material_id] ON silver.[PurchaseOrderDetails] ([material_id]);
GO
IF OBJECT_ID(N'silver.SupplierShipments',N'U') IS NULL
CREATE TABLE silver.[SupplierShipments]
(
    [shipment_id] INT NOT NULL,
    [shipment_code] VARCHAR(20) NOT NULL,
    [po_id] INT NOT NULL,
    [supplier_id] INT NOT NULL,
    [supplier_reference] VARCHAR(50) NOT NULL,
    [ship_date] DATE NOT NULL,
    [expected_arrival_date] DATE NOT NULL,
    [actual_arrival_date] DATE NOT NULL,
    [total_shipment_value] DECIMAL(18,2) NOT NULL,
    [shipping_cost] DECIMAL(18,2) NOT NULL,
    CONSTRAINT [PK_SupplierShipments] PRIMARY KEY ([shipment_id]),
    CONSTRAINT [FK_SupplierShipments_po_id] FOREIGN KEY ([po_id]) REFERENCES silver.[PurchaseOrders] ([po_id]),
    CONSTRAINT [FK_SupplierShipments_supplier_id] FOREIGN KEY ([supplier_id]) REFERENCES silver.[Suppliers] ([supplier_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SupplierShipments') AND name=N'IX_SupplierShipments_po_id')
CREATE INDEX [IX_SupplierShipments_po_id] ON silver.[SupplierShipments] ([po_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SupplierShipments') AND name=N'IX_SupplierShipments_supplier_id')
CREATE INDEX [IX_SupplierShipments_supplier_id] ON silver.[SupplierShipments] ([supplier_id]);
GO
IF OBJECT_ID(N'silver.SupplierShipmentDetails',N'U') IS NULL
CREATE TABLE silver.[SupplierShipmentDetails]
(
    [shipment_detail_id] INT NOT NULL,
    [shipment_id] INT NOT NULL,
    [po_detail_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [received_quantity] DECIMAL(18,2) NOT NULL,
    [accepted_quantity] DECIMAL(18,2) NOT NULL,
    [rejected_quantity] DECIMAL(18,2) NOT NULL,
    CONSTRAINT [PK_SupplierShipmentDetails] PRIMARY KEY ([shipment_detail_id]),
    CONSTRAINT [FK_SupplierShipmentDetails_shipment_id] FOREIGN KEY ([shipment_id]) REFERENCES silver.[SupplierShipments] ([shipment_id]),
    CONSTRAINT [FK_SupplierShipmentDetails_po_detail_id] FOREIGN KEY ([po_detail_id]) REFERENCES silver.[PurchaseOrderDetails] ([po_detail_id]),
    CONSTRAINT [FK_SupplierShipmentDetails_material_id] FOREIGN KEY ([material_id]) REFERENCES silver.[Materials] ([material_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SupplierShipmentDetails') AND name=N'IX_SupplierShipmentDetails_shipment_id')
CREATE INDEX [IX_SupplierShipmentDetails_shipment_id] ON silver.[SupplierShipmentDetails] ([shipment_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SupplierShipmentDetails') AND name=N'IX_SupplierShipmentDetails_po_detail_id')
CREATE INDEX [IX_SupplierShipmentDetails_po_detail_id] ON silver.[SupplierShipmentDetails] ([po_detail_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SupplierShipmentDetails') AND name=N'IX_SupplierShipmentDetails_material_id')
CREATE INDEX [IX_SupplierShipmentDetails_material_id] ON silver.[SupplierShipmentDetails] ([material_id]);
GO
IF OBJECT_ID(N'silver.GoodsReceipts',N'U') IS NULL
CREATE TABLE silver.[GoodsReceipts]
(
    [gr_id] INT NOT NULL,
    [gr_code] VARCHAR(20) NOT NULL,
    [shipment_id] INT NOT NULL,
    [receipt_date] DATE NOT NULL,
    [received_by] VARCHAR(100) NOT NULL,
    [quality_check_status] VARCHAR(20) NOT NULL,
    [total_received_value] DECIMAL(18,2) NOT NULL,
    CONSTRAINT [PK_GoodsReceipts] PRIMARY KEY ([gr_id]),
    CONSTRAINT [FK_GoodsReceipts_shipment_id] FOREIGN KEY ([shipment_id]) REFERENCES silver.[SupplierShipments] ([shipment_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.GoodsReceipts') AND name=N'IX_GoodsReceipts_shipment_id')
CREATE INDEX [IX_GoodsReceipts_shipment_id] ON silver.[GoodsReceipts] ([shipment_id]);
GO
IF OBJECT_ID(N'silver.GoodsReceiptDetails',N'U') IS NULL
CREATE TABLE silver.[GoodsReceiptDetails]
(
    [gr_detail_id] INT NOT NULL,
    [gr_id] INT NOT NULL,
    [shipment_detail_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [received_quantity] DECIMAL(18,2) NOT NULL,
    [accepted_quantity] DECIMAL(18,2) NOT NULL,
    [rejected_quantity] DECIMAL(18,2) NOT NULL,
    [inspection_status] VARCHAR(30) NOT NULL,
    [batch_number] VARCHAR(50) NOT NULL,
    CONSTRAINT [PK_GoodsReceiptDetails] PRIMARY KEY ([gr_detail_id]),
    CONSTRAINT [FK_GoodsReceiptDetails_gr_id] FOREIGN KEY ([gr_id]) REFERENCES silver.[GoodsReceipts] ([gr_id]),
    CONSTRAINT [FK_GoodsReceiptDetails_shipment_detail_id] FOREIGN KEY ([shipment_detail_id]) REFERENCES silver.[SupplierShipmentDetails] ([shipment_detail_id]),
    CONSTRAINT [FK_GoodsReceiptDetails_material_id] FOREIGN KEY ([material_id]) REFERENCES silver.[Materials] ([material_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.GoodsReceiptDetails') AND name=N'IX_GoodsReceiptDetails_gr_id')
CREATE INDEX [IX_GoodsReceiptDetails_gr_id] ON silver.[GoodsReceiptDetails] ([gr_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.GoodsReceiptDetails') AND name=N'IX_GoodsReceiptDetails_shipment_detail_id')
CREATE INDEX [IX_GoodsReceiptDetails_shipment_detail_id] ON silver.[GoodsReceiptDetails] ([shipment_detail_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.GoodsReceiptDetails') AND name=N'IX_GoodsReceiptDetails_material_id')
CREATE INDEX [IX_GoodsReceiptDetails_material_id] ON silver.[GoodsReceiptDetails] ([material_id]);
GO
IF OBJECT_ID(N'silver.QualityInspections',N'U') IS NULL
CREATE TABLE silver.[QualityInspections]
(
    [inspection_id] INT NOT NULL,
    [gr_detail_id] INT NOT NULL,
    [inspection_date] DATE NOT NULL,
    [inspection_type] VARCHAR(50) NOT NULL,
    [inspected_quantity] DECIMAL(18,2) NOT NULL,
    [passed_quantity] DECIMAL(18,2) NOT NULL,
    [inspection_result] VARCHAR(30) NOT NULL,
    [defect_quantity] DECIMAL(18,2) NOT NULL,
    [defect_reason] VARCHAR(250) NOT NULL,
    [corrective_action] VARCHAR(250) NOT NULL,
    [reinspection_required] BIT NOT NULL,
    [status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_QualityInspections] PRIMARY KEY ([inspection_id]),
    CONSTRAINT [FK_QualityInspections_gr_detail_id] FOREIGN KEY ([gr_detail_id]) REFERENCES silver.[GoodsReceiptDetails] ([gr_detail_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.QualityInspections') AND name=N'IX_QualityInspections_gr_detail_id')
CREATE INDEX [IX_QualityInspections_gr_detail_id] ON silver.[QualityInspections] ([gr_detail_id]);
GO
IF OBJECT_ID(N'silver.SupplierInvoices',N'U') IS NULL
CREATE TABLE silver.[SupplierInvoices]
(
    [invoice_id] INT NOT NULL,
    [invoice_number] VARCHAR(30) NOT NULL,
    [shipment_id] INT NOT NULL,
    [supplier_id] INT NOT NULL,
    [invoice_date] DATE NOT NULL,
    [invoice_amount] DECIMAL(18,2) NOT NULL,
    [tax_amount] DECIMAL(18,2) NOT NULL,
    [total_amount] DECIMAL(18,2) NOT NULL,
    [due_date] DATE NOT NULL,
    [payment_terms] VARCHAR(50) NOT NULL,
    [payment_status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_SupplierInvoices] PRIMARY KEY ([invoice_id]),
    CONSTRAINT [FK_SupplierInvoices_shipment_id] FOREIGN KEY ([shipment_id]) REFERENCES silver.[SupplierShipments] ([shipment_id]),
    CONSTRAINT [FK_SupplierInvoices_supplier_id] FOREIGN KEY ([supplier_id]) REFERENCES silver.[Suppliers] ([supplier_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SupplierInvoices') AND name=N'IX_SupplierInvoices_shipment_id')
CREATE INDEX [IX_SupplierInvoices_shipment_id] ON silver.[SupplierInvoices] ([shipment_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SupplierInvoices') AND name=N'IX_SupplierInvoices_supplier_id')
CREATE INDEX [IX_SupplierInvoices_supplier_id] ON silver.[SupplierInvoices] ([supplier_id]);
GO
IF OBJECT_ID(N'silver.SupplierInvoiceDetails',N'U') IS NULL
CREATE TABLE silver.[SupplierInvoiceDetails]
(
    [invoice_detail_id] INT NOT NULL,
    [invoice_id] INT NOT NULL,
    [gr_detail_id] INT NOT NULL,
    [billed_quantity] DECIMAL(18,2) NOT NULL,
    [unit_price] DECIMAL(18,2) NOT NULL,
    [tax_amount] DECIMAL(18,2) NOT NULL,
    [line_amount] DECIMAL(18,2) NOT NULL,
    CONSTRAINT [PK_SupplierInvoiceDetails] PRIMARY KEY ([invoice_detail_id]),
    CONSTRAINT [FK_SupplierInvoiceDetails_invoice_id] FOREIGN KEY ([invoice_id]) REFERENCES silver.[SupplierInvoices] ([invoice_id]),
    CONSTRAINT [FK_SupplierInvoiceDetails_gr_detail_id] FOREIGN KEY ([gr_detail_id]) REFERENCES silver.[GoodsReceiptDetails] ([gr_detail_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SupplierInvoiceDetails') AND name=N'IX_SupplierInvoiceDetails_invoice_id')
CREATE INDEX [IX_SupplierInvoiceDetails_invoice_id] ON silver.[SupplierInvoiceDetails] ([invoice_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SupplierInvoiceDetails') AND name=N'IX_SupplierInvoiceDetails_gr_detail_id')
CREATE INDEX [IX_SupplierInvoiceDetails_gr_detail_id] ON silver.[SupplierInvoiceDetails] ([gr_detail_id]);
GO
IF OBJECT_ID(N'silver.SupplierPayments',N'U') IS NULL
CREATE TABLE silver.[SupplierPayments]
(
    [payment_id] INT NOT NULL,
    [invoice_id] INT NOT NULL,
    [payment_date] DATE NOT NULL,
    [payment_amount] DECIMAL(18,2) NOT NULL,
    [payment_method] VARCHAR(30) NOT NULL,
    [currency] CHAR(3) NOT NULL,
    [transaction_reference] VARCHAR(100) NOT NULL,
    [payment_status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_SupplierPayments] PRIMARY KEY ([payment_id]),
    CONSTRAINT [FK_SupplierPayments_invoice_id] FOREIGN KEY ([invoice_id]) REFERENCES silver.[SupplierInvoices] ([invoice_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SupplierPayments') AND name=N'IX_SupplierPayments_invoice_id')
CREATE INDEX [IX_SupplierPayments_invoice_id] ON silver.[SupplierPayments] ([invoice_id]);
GO
IF OBJECT_ID(N'silver.Warehouses',N'U') IS NULL
CREATE TABLE silver.[Warehouses]
(
    [warehouse_id] INT NOT NULL,
    [warehouse_code] VARCHAR(20) NOT NULL,
    [warehouse_name] VARCHAR(100) NOT NULL,
    [warehouse_type] VARCHAR(50) NOT NULL,
    [country] VARCHAR(50) NOT NULL,
    [city] VARCHAR(50) NOT NULL,
    [location_description] VARCHAR(250) NOT NULL,
    [status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_Warehouses] PRIMARY KEY ([warehouse_id])
);
GO
IF OBJECT_ID(N'silver.RawMaterialInventory',N'U') IS NULL
CREATE TABLE silver.[RawMaterialInventory]
(
    [raw_inventory_id] INT NOT NULL,
    [warehouse_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [quantity_on_hand] DECIMAL(18,2) NOT NULL,
    [quantity_reserved] DECIMAL(18,2) NOT NULL,
    [reorder_point] DECIMAL(18,2) NOT NULL,
    [safety_stock_level] DECIMAL(18,2) NOT NULL,
    [max_inventory_level] DECIMAL(18,2) NOT NULL,
    [unit_cost] DECIMAL(18,2) NOT NULL,
    [last_updated_at] DATE NULL,
    CONSTRAINT [PK_RawMaterialInventory] PRIMARY KEY ([raw_inventory_id]),
    CONSTRAINT [FK_RawMaterialInventory_warehouse_id] FOREIGN KEY ([warehouse_id]) REFERENCES silver.[Warehouses] ([warehouse_id]),
    CONSTRAINT [FK_RawMaterialInventory_material_id] FOREIGN KEY ([material_id]) REFERENCES silver.[Materials] ([material_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.RawMaterialInventory') AND name=N'IX_RawMaterialInventory_warehouse_id')
CREATE INDEX [IX_RawMaterialInventory_warehouse_id] ON silver.[RawMaterialInventory] ([warehouse_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.RawMaterialInventory') AND name=N'IX_RawMaterialInventory_material_id')
CREATE INDEX [IX_RawMaterialInventory_material_id] ON silver.[RawMaterialInventory] ([material_id]);
GO
IF OBJECT_ID(N'silver.Products',N'U') IS NULL
CREATE TABLE silver.[Products]
(
    [product_id] INT NOT NULL,
    [product_code] VARCHAR(30) NOT NULL,
    [product_name] VARCHAR(100) NOT NULL,
    [product_category] VARCHAR(50) NOT NULL,
    [uom] VARCHAR(20) NOT NULL,
    [standard_cost] DECIMAL(18,2) NOT NULL,
    [selling_price] DECIMAL(18,2) NOT NULL,
    [status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_Products] PRIMARY KEY ([product_id])
);
GO
IF OBJECT_ID(N'silver.ProductBOM',N'U') IS NULL
CREATE TABLE silver.[ProductBOM]
(
    [bom_id] INT NOT NULL,
    [product_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [quantity_required] DECIMAL(18,3) NOT NULL,
    [uom] VARCHAR(20) NOT NULL,
    [status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_ProductBOM] PRIMARY KEY ([bom_id]),
    CONSTRAINT [FK_ProductBOM_product_id] FOREIGN KEY ([product_id]) REFERENCES silver.[Products] ([product_id]),
    CONSTRAINT [FK_ProductBOM_material_id] FOREIGN KEY ([material_id]) REFERENCES silver.[Materials] ([material_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.ProductBOM') AND name=N'IX_ProductBOM_product_id')
CREATE INDEX [IX_ProductBOM_product_id] ON silver.[ProductBOM] ([product_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.ProductBOM') AND name=N'IX_ProductBOM_material_id')
CREATE INDEX [IX_ProductBOM_material_id] ON silver.[ProductBOM] ([material_id]);
GO
IF OBJECT_ID(N'silver.Production',N'U') IS NULL
CREATE TABLE silver.[Production]
(
    [production_id] INT NOT NULL,
    [production_order_code] VARCHAR(30) NOT NULL,
    [product_id] INT NOT NULL,
    [planned_quantity] DECIMAL(18,2) NOT NULL,
    [start_date] DATE NOT NULL,
    [expected_end_date] DATE NOT NULL,
    [actual_end_date] DATE NULL,
    [production_quantity] DECIMAL(18,2) NOT NULL,
    [rejected_quantity] DECIMAL(18,2) NOT NULL,
    [production_status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_Production] PRIMARY KEY ([production_id]),
    CONSTRAINT [FK_Production_product_id] FOREIGN KEY ([product_id]) REFERENCES silver.[Products] ([product_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.Production') AND name=N'IX_Production_product_id')
CREATE INDEX [IX_Production_product_id] ON silver.[Production] ([product_id]);
GO
IF OBJECT_ID(N'silver.ProductionDetails',N'U') IS NULL
CREATE TABLE silver.[ProductionDetails]
(
    [production_detail_id] INT NOT NULL,
    [production_id] INT NOT NULL,
    [bom_id] INT NOT NULL,
    [raw_inventory_id] INT NOT NULL,
    [actual_consumed_quantity] DECIMAL(18,3) NOT NULL,
    [return_quantity] DECIMAL(18,3) NOT NULL,
    [scrap_quantity] DECIMAL(18,3) NOT NULL,
    [unit_cost] DECIMAL(18,2) NOT NULL,
    [total_material_cost] DECIMAL(18,2) NOT NULL,
    CONSTRAINT [PK_ProductionDetails] PRIMARY KEY ([production_detail_id]),
    CONSTRAINT [FK_ProductionDetails_production_id] FOREIGN KEY ([production_id]) REFERENCES silver.[Production] ([production_id]),
    CONSTRAINT [FK_ProductionDetails_bom_id] FOREIGN KEY ([bom_id]) REFERENCES silver.[ProductBOM] ([bom_id]),
    CONSTRAINT [FK_ProductionDetails_raw_inventory_id] FOREIGN KEY ([raw_inventory_id]) REFERENCES silver.[RawMaterialInventory] ([raw_inventory_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.ProductionDetails') AND name=N'IX_ProductionDetails_production_id')
CREATE INDEX [IX_ProductionDetails_production_id] ON silver.[ProductionDetails] ([production_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.ProductionDetails') AND name=N'IX_ProductionDetails_bom_id')
CREATE INDEX [IX_ProductionDetails_bom_id] ON silver.[ProductionDetails] ([bom_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.ProductionDetails') AND name=N'IX_ProductionDetails_raw_inventory_id')
CREATE INDEX [IX_ProductionDetails_raw_inventory_id] ON silver.[ProductionDetails] ([raw_inventory_id]);
GO
IF OBJECT_ID(N'silver.RawMaterialInventoryTransactions',N'U') IS NULL
CREATE TABLE silver.[RawMaterialInventoryTransactions]
(
    [raw_transaction_id] INT NOT NULL,
    [raw_inventory_id] INT NOT NULL,
    [production_id] INT NOT NULL,
    [inspection_id] INT NOT NULL,
    [transaction_type] VARCHAR(40) NOT NULL,
    [quantity] DECIMAL(18,3) NOT NULL,
    [unit_cost] DECIMAL(18,2) NOT NULL,
    [transaction_date] DATE NULL,
    [reference_code] VARCHAR(50) NOT NULL,
    CONSTRAINT [PK_RawMaterialInventoryTransactions] PRIMARY KEY ([raw_transaction_id]),
    CONSTRAINT [FK_RawMaterialInventoryTransactions_raw_inventory_id] FOREIGN KEY ([raw_inventory_id]) REFERENCES silver.[RawMaterialInventory] ([raw_inventory_id]),
    CONSTRAINT [FK_RawMaterialInventoryTransactions_production_id] FOREIGN KEY ([production_id]) REFERENCES silver.[Production] ([production_id]),
    CONSTRAINT [FK_RawMaterialInventoryTransactions_inspection_id] FOREIGN KEY ([inspection_id]) REFERENCES silver.[QualityInspections] ([inspection_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.RawMaterialInventoryTransactions') AND name=N'IX_RawMaterialInventoryTransactions_raw_inventory_id')
CREATE INDEX [IX_RawMaterialInventoryTransactions_raw_inventory_id] ON silver.[RawMaterialInventoryTransactions] ([raw_inventory_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.RawMaterialInventoryTransactions') AND name=N'IX_RawMaterialInventoryTransactions_production_id')
CREATE INDEX [IX_RawMaterialInventoryTransactions_production_id] ON silver.[RawMaterialInventoryTransactions] ([production_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.RawMaterialInventoryTransactions') AND name=N'IX_RawMaterialInventoryTransactions_inspection_id')
CREATE INDEX [IX_RawMaterialInventoryTransactions_inspection_id] ON silver.[RawMaterialInventoryTransactions] ([inspection_id]);
GO
IF OBJECT_ID(N'silver.FinishedGoodsInventory',N'U') IS NULL
CREATE TABLE silver.[FinishedGoodsInventory]
(
    [finished_goods_inventory_id] INT NOT NULL,
    [warehouse_id] INT NOT NULL,
    [product_id] INT NOT NULL,
    [quantity_on_hand] DECIMAL(18,2) NOT NULL,
    [quantity_reserved] INT NOT NULL,
    [reorder_point] DECIMAL(18,2) NOT NULL,
    [safety_stock_level] DECIMAL(18,2) NOT NULL,
    [last_updated_at] DATE NULL,
    CONSTRAINT [PK_FinishedGoodsInventory] PRIMARY KEY ([finished_goods_inventory_id]),
    CONSTRAINT [FK_FinishedGoodsInventory_warehouse_id] FOREIGN KEY ([warehouse_id]) REFERENCES silver.[Warehouses] ([warehouse_id]),
    CONSTRAINT [FK_FinishedGoodsInventory_product_id] FOREIGN KEY ([product_id]) REFERENCES silver.[Products] ([product_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.FinishedGoodsInventory') AND name=N'IX_FinishedGoodsInventory_warehouse_id')
CREATE INDEX [IX_FinishedGoodsInventory_warehouse_id] ON silver.[FinishedGoodsInventory] ([warehouse_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.FinishedGoodsInventory') AND name=N'IX_FinishedGoodsInventory_product_id')
CREATE INDEX [IX_FinishedGoodsInventory_product_id] ON silver.[FinishedGoodsInventory] ([product_id]);
GO
IF OBJECT_ID(N'silver.Customers',N'U') IS NULL
CREATE TABLE silver.[Customers]
(
    [customer_id] INT NOT NULL,
    [customer_code] VARCHAR(30) NOT NULL,
    [customer_name] VARCHAR(100) NOT NULL,
    [customer_type] VARCHAR(50) NOT NULL,
    [email] VARCHAR(120) NULL,
    [phone] VARCHAR(20) NOT NULL,
    [country] VARCHAR(50) NOT NULL,
    [city] VARCHAR(50) NOT NULL,
    [address] VARCHAR(250) NOT NULL,
    [registration_date] DATE NOT NULL,
    [default_discount_percentage] DECIMAL(5,2) NOT NULL,
    [status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_Customers] PRIMARY KEY ([customer_id])
);
GO
IF OBJECT_ID(N'silver.SalesOrders',N'U') IS NULL
CREATE TABLE silver.[SalesOrders]
(
    [sales_order_id] INT NOT NULL,
    [sales_order_code] VARCHAR(20) NOT NULL,
    [customer_id] INT NOT NULL,
    [order_date] DATE NOT NULL,
    [required_delivery_date] DATE NOT NULL,
    [payment_method] VARCHAR(30) NOT NULL,
    [tax_percentage] DECIMAL(5,2) NOT NULL,
    [sales_order_status] VARCHAR(30) NOT NULL,
    CONSTRAINT [PK_SalesOrders] PRIMARY KEY ([sales_order_id]),
    CONSTRAINT [FK_SalesOrders_customer_id] FOREIGN KEY ([customer_id]) REFERENCES silver.[Customers] ([customer_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SalesOrders') AND name=N'IX_SalesOrders_customer_id')
CREATE INDEX [IX_SalesOrders_customer_id] ON silver.[SalesOrders] ([customer_id]);
GO
IF OBJECT_ID(N'silver.SalesOrderDetails',N'U') IS NULL
CREATE TABLE silver.[SalesOrderDetails]
(
    [sales_order_detail_id] INT NOT NULL,
    [sales_order_id] INT NOT NULL,
    [product_id] INT NOT NULL,
    [ordered_quantity] DECIMAL(18,2) NOT NULL,
    [line_status] VARCHAR(30) NOT NULL,
    CONSTRAINT [PK_SalesOrderDetails] PRIMARY KEY ([sales_order_detail_id]),
    CONSTRAINT [FK_SalesOrderDetails_sales_order_id] FOREIGN KEY ([sales_order_id]) REFERENCES silver.[SalesOrders] ([sales_order_id]),
    CONSTRAINT [FK_SalesOrderDetails_product_id] FOREIGN KEY ([product_id]) REFERENCES silver.[Products] ([product_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SalesOrderDetails') AND name=N'IX_SalesOrderDetails_sales_order_id')
CREATE INDEX [IX_SalesOrderDetails_sales_order_id] ON silver.[SalesOrderDetails] ([sales_order_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SalesOrderDetails') AND name=N'IX_SalesOrderDetails_product_id')
CREATE INDEX [IX_SalesOrderDetails_product_id] ON silver.[SalesOrderDetails] ([product_id]);
GO
IF OBJECT_ID(N'silver.CustomerShipments',N'U') IS NULL
CREATE TABLE silver.[CustomerShipments]
(
    [customer_shipment_id] INT NOT NULL,
    [shipment_code] VARCHAR(20) NOT NULL,
    [sales_order_id] INT NOT NULL,
    [warehouse_id] INT NOT NULL,
    [shipment_date] DATE NOT NULL,
    [expected_delivery_date] DATE NOT NULL,
    [actual_delivery_date] DATE NULL,
    [tracking_number] VARCHAR(50) NOT NULL,
    [shipping_method] VARCHAR(30) NOT NULL,
    [shipping_cost] DECIMAL(18,2) NOT NULL,
    [delivery_address] VARCHAR(300) NOT NULL,
    [shipment_status] VARCHAR(30) NOT NULL,
    [delivery_confirmation] BIT NOT NULL,
    [customer_feedback] VARCHAR(500) NOT NULL,
    CONSTRAINT [PK_CustomerShipments] PRIMARY KEY ([customer_shipment_id]),
    CONSTRAINT [FK_CustomerShipments_sales_order_id] FOREIGN KEY ([sales_order_id]) REFERENCES silver.[SalesOrders] ([sales_order_id]),
    CONSTRAINT [FK_CustomerShipments_warehouse_id] FOREIGN KEY ([warehouse_id]) REFERENCES silver.[Warehouses] ([warehouse_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.CustomerShipments') AND name=N'IX_CustomerShipments_sales_order_id')
CREATE INDEX [IX_CustomerShipments_sales_order_id] ON silver.[CustomerShipments] ([sales_order_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.CustomerShipments') AND name=N'IX_CustomerShipments_warehouse_id')
CREATE INDEX [IX_CustomerShipments_warehouse_id] ON silver.[CustomerShipments] ([warehouse_id]);
GO
IF OBJECT_ID(N'silver.CustomerShipmentDetails',N'U') IS NULL
CREATE TABLE silver.[CustomerShipmentDetails]
(
    [customer_shipment_detail_id] INT NOT NULL,
    [customer_shipment_id] INT NOT NULL,
    [sales_order_detail_id] INT NOT NULL,
    [shipped_quantity] DECIMAL(18,2) NOT NULL,
    CONSTRAINT [PK_CustomerShipmentDetails] PRIMARY KEY ([customer_shipment_detail_id]),
    CONSTRAINT [FK_CustomerShipmentDetails_customer_shipment_id] FOREIGN KEY ([customer_shipment_id]) REFERENCES silver.[CustomerShipments] ([customer_shipment_id]),
    CONSTRAINT [FK_CustomerShipmentDetails_sales_order_detail_id] FOREIGN KEY ([sales_order_detail_id]) REFERENCES silver.[SalesOrderDetails] ([sales_order_detail_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.CustomerShipmentDetails') AND name=N'IX_CustomerShipmentDetails_customer_shipment_id')
CREATE INDEX [IX_CustomerShipmentDetails_customer_shipment_id] ON silver.[CustomerShipmentDetails] ([customer_shipment_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.CustomerShipmentDetails') AND name=N'IX_CustomerShipmentDetails_sales_order_detail_id')
CREATE INDEX [IX_CustomerShipmentDetails_sales_order_detail_id] ON silver.[CustomerShipmentDetails] ([sales_order_detail_id]);
GO
IF OBJECT_ID(N'silver.FinishedGoodsInventoryTransactions',N'U') IS NULL
CREATE TABLE silver.[FinishedGoodsInventoryTransactions]
(
    [finished_inventory_transaction_id] INT NOT NULL,
    [finished_goods_inventory_id] INT NOT NULL,
    [production_id] INT NOT NULL,
    [customer_shipment_detail_id] INT NOT NULL,
    [transaction_type] VARCHAR(40) NOT NULL,
    [quantity] DECIMAL(18,2) NOT NULL,
    [unit_cost] DECIMAL(18,2) NOT NULL,
    [transaction_date] DATE NULL,
    [reference_code] VARCHAR(50) NOT NULL,
    CONSTRAINT [PK_FinishedGoodsInventoryTransactions] PRIMARY KEY ([finished_inventory_transaction_id]),
    CONSTRAINT [FK_FinishedGoodsInventoryTransactions_finished_goods_inventory_id] FOREIGN KEY ([finished_goods_inventory_id]) REFERENCES silver.[FinishedGoodsInventory] ([finished_goods_inventory_id]),
    CONSTRAINT [FK_FinishedGoodsInventoryTransactions_production_id] FOREIGN KEY ([production_id]) REFERENCES silver.[Production] ([production_id]),
    CONSTRAINT [FK_FinishedGoodsInventoryTransactions_customer_shipment_detail_id] FOREIGN KEY ([customer_shipment_detail_id]) REFERENCES silver.[CustomerShipmentDetails] ([customer_shipment_detail_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.FinishedGoodsInventoryTransactions') AND name=N'IX_FinishedGoodsInventoryTransactions_finished_goods_inventory_id')
CREATE INDEX [IX_FinishedGoodsInventoryTransactions_finished_goods_inventory_id] ON silver.[FinishedGoodsInventoryTransactions] ([finished_goods_inventory_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.FinishedGoodsInventoryTransactions') AND name=N'IX_FinishedGoodsInventoryTransactions_production_id')
CREATE INDEX [IX_FinishedGoodsInventoryTransactions_production_id] ON silver.[FinishedGoodsInventoryTransactions] ([production_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.FinishedGoodsInventoryTransactions') AND name=N'IX_FinishedGoodsInventoryTransactions_customer_shipment_detail_id')
CREATE INDEX [IX_FinishedGoodsInventoryTransactions_customer_shipment_detail_id] ON silver.[FinishedGoodsInventoryTransactions] ([customer_shipment_detail_id]);
GO
IF OBJECT_ID(N'silver.Returns',N'U') IS NULL
CREATE TABLE silver.[Returns]
(
    [return_id] INT NOT NULL,
    [return_code] VARCHAR(20) NOT NULL,
    [customer_shipment_detail_id] INT NOT NULL,
    [return_request_date] DATE NOT NULL,
    [return_received_date] DATE NOT NULL,
    [returned_quantity] DECIMAL(18,2) NOT NULL,
    [return_reason] VARCHAR(120) NOT NULL,
    [product_condition] VARCHAR(50) NOT NULL,
    [return_status] VARCHAR(30) NOT NULL,
    CONSTRAINT [PK_Returns] PRIMARY KEY ([return_id]),
    CONSTRAINT [FK_Returns_customer_shipment_detail_id] FOREIGN KEY ([customer_shipment_detail_id]) REFERENCES silver.[CustomerShipmentDetails] ([customer_shipment_detail_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.Returns') AND name=N'IX_Returns_customer_shipment_detail_id')
CREATE INDEX [IX_Returns_customer_shipment_detail_id] ON silver.[Returns] ([customer_shipment_detail_id]);
GO
