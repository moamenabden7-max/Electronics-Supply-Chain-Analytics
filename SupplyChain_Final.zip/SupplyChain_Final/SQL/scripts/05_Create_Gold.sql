﻿USE [ElectronicsSupplyChainDB_v2];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO
-- Gold views are read-only. Quantity/value fields retain Silver precision.
IF OBJECT_ID(N'gold.DimDate',N'U') IS NULL
CREATE TABLE gold.DimDate
(
 full_date DATE PRIMARY KEY, calendar_year INT NOT NULL,
 quarter_number INT NOT NULL, quarter_name VARCHAR(2) NOT NULL,
 month_number INT NOT NULL, month_name VARCHAR(20) NOT NULL,
 year_month CHAR(7) NOT NULL, year_month_sort INT NOT NULL,
 week_number INT NOT NULL, iso_week_year INT NOT NULL,
 day_of_month INT NOT NULL, day_name VARCHAR(20) NOT NULL
);
GO
CREATE OR ALTER PROCEDURE etl.RefreshDimDate
AS
BEGIN
 SET NOCOUNT ON;
 IF @@TRANCOUNT=0 THROW 51003, 'Run etl.RefreshAll; date refresh requires its transaction.', 1;
 SET LANGUAGE us_english;
 DECLARE @MinDate DATE,@MaxDate DATE;
 SELECT @MinDate=MIN(d),@MaxDate=MAX(d) FROM (
 SELECT CAST([request_date] AS DATE) AS d FROM silver.[PurchaseRequisitions]
 UNION ALL
 SELECT CAST([order_date] AS DATE) AS d FROM silver.[PurchaseRequisitions]
 UNION ALL
 SELECT CAST([required_date] AS DATE) AS d FROM silver.[PurchaseRequisitions]
 UNION ALL
 SELECT CAST([approval_date] AS DATE) AS d FROM silver.[PurchaseRequisitions]
 UNION ALL
 SELECT CAST([created_date] AS DATE) AS d FROM silver.[PurchaseRequisitions]
 UNION ALL
 SELECT CAST([order_date] AS DATE) AS d FROM silver.[PurchaseOrders]
 UNION ALL
 SELECT CAST([expected_delivery_date] AS DATE) AS d FROM silver.[PurchaseOrders]
 UNION ALL
 SELECT CAST([expected_delivery_date] AS DATE) AS d FROM silver.[PurchaseOrderDetails]
 UNION ALL
 SELECT CAST([ship_date] AS DATE) AS d FROM silver.[SupplierShipments]
 UNION ALL
 SELECT CAST([expected_arrival_date] AS DATE) AS d FROM silver.[SupplierShipments]
 UNION ALL
 SELECT CAST([actual_arrival_date] AS DATE) AS d FROM silver.[SupplierShipments]
 UNION ALL
 SELECT CAST([receipt_date] AS DATE) AS d FROM silver.[GoodsReceipts]
 UNION ALL
 SELECT CAST([inspection_date] AS DATE) AS d FROM silver.[QualityInspections]
 UNION ALL
 SELECT CAST([invoice_date] AS DATE) AS d FROM silver.[SupplierInvoices]
 UNION ALL
 SELECT CAST([due_date] AS DATE) AS d FROM silver.[SupplierInvoices]
 UNION ALL
 SELECT CAST([payment_date] AS DATE) AS d FROM silver.[SupplierPayments]
 UNION ALL
 SELECT CAST([last_updated_at] AS DATE) AS d FROM silver.[RawMaterialInventory]
 UNION ALL
 SELECT CAST([start_date] AS DATE) AS d FROM silver.[Production]
 UNION ALL
 SELECT CAST([expected_end_date] AS DATE) AS d FROM silver.[Production]
 UNION ALL
 SELECT CAST([actual_end_date] AS DATE) AS d FROM silver.[Production]
 UNION ALL
 SELECT CAST([transaction_date] AS DATE) AS d FROM silver.[RawMaterialInventoryTransactions]
 UNION ALL
 SELECT CAST([last_updated_at] AS DATE) AS d FROM silver.[FinishedGoodsInventory]
 UNION ALL
 SELECT CAST([registration_date] AS DATE) AS d FROM silver.[Customers]
 UNION ALL
 SELECT CAST([order_date] AS DATE) AS d FROM silver.[SalesOrders]
 UNION ALL
 SELECT CAST([required_delivery_date] AS DATE) AS d FROM silver.[SalesOrders]
 UNION ALL
 SELECT CAST([shipment_date] AS DATE) AS d FROM silver.[CustomerShipments]
 UNION ALL
 SELECT CAST([expected_delivery_date] AS DATE) AS d FROM silver.[CustomerShipments]
 UNION ALL
 SELECT CAST([actual_delivery_date] AS DATE) AS d FROM silver.[CustomerShipments]
 UNION ALL
 SELECT CAST([transaction_date] AS DATE) AS d FROM silver.[FinishedGoodsInventoryTransactions]
 UNION ALL
 SELECT CAST([return_request_date] AS DATE) AS d FROM silver.[Returns]
 UNION ALL
 SELECT CAST([return_received_date] AS DATE) AS d FROM silver.[Returns]
 ) dates WHERE d IS NOT NULL;
 IF @MinDate IS NULL THROW 51004, 'No dates available; load source data first.', 1;
 SET @MinDate=DATEFROMPARTS(YEAR(@MinDate),1,1);
 SET @MaxDate=DATEFROMPARTS(YEAR(@MaxDate),12,31);
 DELETE FROM gold.DimDate;
 ;WITH DateSeries AS (
 SELECT @MinDate AS d UNION ALL SELECT DATEADD(DAY,1,d) FROM DateSeries WHERE d<@MaxDate
 )
 INSERT gold.DimDate
 SELECT d,YEAR(d),DATEPART(QUARTER,d),CONCAT('Q',DATEPART(QUARTER,d)),MONTH(d),DATENAME(MONTH,d),
 CONVERT(CHAR(7),d,120),YEAR(d)*100+MONTH(d),DATEPART(ISO_WEEK,d),
 CASE WHEN MONTH(d)=1 AND DATEPART(ISO_WEEK,d)>50 THEN YEAR(d)-1
      WHEN MONTH(d)=12 AND DATEPART(ISO_WEEK,d)=1 THEN YEAR(d)+1 ELSE YEAR(d) END,
 DAY(d),DATENAME(WEEKDAY,d) FROM DateSeries OPTION (MAXRECURSION 0);
END;
GO
CREATE OR ALTER VIEW gold.vw_DimDepartment
AS
SELECT
    department_id,
    department_code,
    department_name,
    department_description,
    status
FROM silver.Departments;
GO

CREATE OR ALTER VIEW gold.vw_DimSupplier
AS
SELECT
    supplier_id,
    supplier_code,
    supplier_name,
    supplier_type,
    supplier_category,
    country,
    city,
    status
FROM silver.Suppliers;
GO

CREATE OR ALTER VIEW gold.vw_DimMaterial
AS
SELECT
    material_id,
    material_code,
    material_name,
    material_category,
    material_type,
    uom,
    unit_weight,
    status
FROM silver.Materials;
GO

CREATE OR ALTER VIEW gold.vw_DimProduct
AS
SELECT
    product_id,
    product_code,
    product_name,
    product_category,
    uom,
    standard_cost,
    selling_price,
    status
FROM silver.Products;
GO

CREATE OR ALTER VIEW gold.vw_DimCustomer
AS
SELECT
    customer_id,
    customer_code,
    customer_name,
    customer_type,
    country,
    city,
    registration_date,
    default_discount_percentage,
    status
FROM silver.Customers;
GO

CREATE OR ALTER VIEW gold.vw_DimWarehouse
AS
SELECT
    warehouse_id,
    warehouse_code,
    warehouse_name,
    warehouse_type,
    country,
    city,
    location_description,
    status
FROM silver.Warehouses;
GO

CREATE OR ALTER VIEW gold.vw_BridgeSupplierMaterial
AS
SELECT
    supplier_material_id,
    supplier_id,
    material_id,
    supplier_material_code,
    standard_price,
    lead_time_days,
    minimum_order_quantity,
    preferred_supplier,
    status
FROM silver.SupplierMaterials;
GO

CREATE OR ALTER VIEW gold.vw_BridgeProductBOM
AS
SELECT
    bom_id,
    product_id,
    material_id,
    quantity_required,
    uom,
    status
FROM silver.ProductBOM;
GO

CREATE OR ALTER VIEW gold.vw_FactPurchaseRequisition
AS
SELECT pr.pr_id, pr.department_id, pr.request_date, pr.order_date AS pr_order_date,
 pr.required_date, pr.approval_date, pr.created_date, pr.priority, pr.approval_status,
 po.first_po_order_date, COALESCE(po.purchase_order_count,0) AS purchase_order_count
FROM silver.PurchaseRequisitions pr
LEFT JOIN (SELECT pr_id, MIN(order_date) AS first_po_order_date,COUNT_BIG(*) AS purchase_order_count
           FROM silver.PurchaseOrders GROUP BY pr_id) po ON po.pr_id=pr.pr_id;
GO

CREATE OR ALTER VIEW gold.vw_FactPurchaseOrderDetail
AS
SELECT
    pod.po_detail_id,
    pod.po_id,
    pod.pr_detail_id,

    po.pr_id,
    po.supplier_id,
    pr.department_id,
    pod.material_id,

    po.order_date,
    pod.expected_delivery_date,

    po.status AS po_status,
    pod.line_status,

    pod.ordered_quantity,
    pod.unit_price,
    pod.discount_percentage,
    pod.total_amount,

    sm.supplier_material_id,
    sm.standard_price

FROM silver.PurchaseOrderDetails pod

INNER JOIN silver.PurchaseOrders po
    ON po.po_id = pod.po_id

INNER JOIN silver.PurchaseRequisitions pr
    ON pr.pr_id = po.pr_id

OUTER APPLY
(
    SELECT TOP (1)
        x.supplier_material_id,
        x.standard_price
    FROM silver.SupplierMaterials x
    WHERE x.supplier_id = po.supplier_id
      AND x.material_id = pod.material_id
    ORDER BY
        x.preferred_supplier DESC,
        x.supplier_material_id
) sm;
GO

CREATE OR ALTER VIEW gold.vw_FactSupplierShipment
AS
SELECT
    ss.shipment_id,
    ss.po_id,
    ss.supplier_id,

    po.pr_id,
    pr.department_id,

    ss.ship_date,
    ss.expected_arrival_date,
    ss.actual_arrival_date,

    po.order_date AS po_order_date,
    pr.request_date AS pr_request_date,

    ss.total_shipment_value,
    ss.shipping_cost

FROM silver.SupplierShipments ss

INNER JOIN silver.PurchaseOrders po
    ON po.po_id = ss.po_id

INNER JOIN silver.PurchaseRequisitions pr
    ON pr.pr_id = po.pr_id;
GO

CREATE OR ALTER VIEW gold.vw_FactSupplierShipmentDetail
AS
SELECT
    ssd.shipment_detail_id,
    ssd.shipment_id,
    ssd.po_detail_id,

    ss.po_id,
    ss.supplier_id,

    pod.pr_detail_id,
    pod.material_id,

    ss.ship_date,
    ss.expected_arrival_date,
    ss.actual_arrival_date,

    pod.ordered_quantity AS line_ordered_quantity_nonadditive,
    ssd.received_quantity,
    ssd.accepted_quantity,
    ssd.rejected_quantity

FROM silver.SupplierShipmentDetails ssd

INNER JOIN silver.SupplierShipments ss
    ON ss.shipment_id = ssd.shipment_id

INNER JOIN silver.PurchaseOrderDetails pod
    ON pod.po_detail_id = ssd.po_detail_id;
GO

CREATE OR ALTER VIEW gold.vw_FactGoodsReceiptDetail
AS
SELECT
    grd.gr_detail_id,
    grd.gr_id,
    grd.shipment_detail_id,

    gr.shipment_id,
    ss.supplier_id,
    grd.material_id,

    ss.actual_arrival_date,
    gr.receipt_date,

    grd.batch_number,
    grd.inspection_status,

    grd.received_quantity,
    grd.accepted_quantity,
    grd.rejected_quantity

FROM silver.GoodsReceiptDetails grd

INNER JOIN silver.GoodsReceipts gr
    ON gr.gr_id = grd.gr_id

INNER JOIN silver.SupplierShipments ss
    ON ss.shipment_id = gr.shipment_id;
GO

CREATE OR ALTER VIEW gold.vw_FactQualityInspection
AS
SELECT
    qi.inspection_id,
    qi.gr_detail_id,

    grd.gr_id,
    grd.material_id,
    ss.supplier_id,

    qi.inspection_date,

    qi.inspection_type,
    qi.inspection_result,
    qi.defect_reason,
    qi.reinspection_required,
    qi.status,

    qi.inspected_quantity,
    qi.passed_quantity,
    qi.defect_quantity

FROM silver.QualityInspections qi

INNER JOIN silver.GoodsReceiptDetails grd
    ON grd.gr_detail_id = qi.gr_detail_id

INNER JOIN silver.GoodsReceipts gr
    ON gr.gr_id = grd.gr_id

INNER JOIN silver.SupplierShipments ss
    ON ss.shipment_id = gr.shipment_id;
GO

CREATE OR ALTER VIEW gold.vw_FactRawMaterialInventory
AS
SELECT
    raw_inventory_id,
    warehouse_id,
    material_id,

    quantity_on_hand,
    quantity_reserved,
    reorder_point,
    safety_stock_level,
    max_inventory_level,
    unit_cost,

    last_updated_at

FROM silver.RawMaterialInventory;
GO

CREATE OR ALTER VIEW gold.vw_FactRawInventoryTransaction
AS
SELECT
    tx.raw_transaction_id,
    tx.raw_inventory_id,

    inv.warehouse_id,
    inv.material_id,

    tx.production_id,
    tx.inspection_id,

    tx.transaction_type,
    tx.quantity,
    tx.unit_cost,
    tx.transaction_date,
    CAST(tx.transaction_date AS DATE) AS transaction_day,
    tx.reference_code

FROM silver.RawMaterialInventoryTransactions tx

INNER JOIN silver.RawMaterialInventory inv
    ON inv.raw_inventory_id = tx.raw_inventory_id;
GO

CREATE OR ALTER VIEW gold.vw_FactProductionOrder
AS
SELECT
    production_id,
    product_id,

    start_date,
    expected_end_date,
    actual_end_date,

    production_status,

    planned_quantity,
    production_quantity,
    rejected_quantity

FROM silver.Production;
GO

CREATE OR ALTER VIEW gold.vw_FactProductionMaterial
AS
SELECT
    pd.production_detail_id,
    pd.production_id,
    pd.bom_id,
    pd.raw_inventory_id,

    p.product_id,
    bom.material_id,
    inv.warehouse_id,

    p.start_date,
    p.expected_end_date,
    p.actual_end_date,
    p.production_status,

    bom.quantity_required,

    p.planned_quantity AS order_planned_quantity_nonadditive,
    p.production_quantity AS order_production_quantity_nonadditive,
    p.rejected_quantity AS order_rejected_quantity_nonadditive,

    pd.actual_consumed_quantity,
    pd.return_quantity,
    pd.scrap_quantity,

    pd.unit_cost,
    pd.total_material_cost

FROM silver.ProductionDetails pd

INNER JOIN silver.Production p
    ON p.production_id = pd.production_id

INNER JOIN silver.ProductBOM bom
    ON bom.bom_id = pd.bom_id

INNER JOIN silver.RawMaterialInventory inv
    ON inv.raw_inventory_id = pd.raw_inventory_id;
GO

CREATE OR ALTER VIEW gold.vw_FactFinishedGoodsInventory
AS
SELECT
    fg.finished_goods_inventory_id,
    fg.warehouse_id,
    fg.product_id,

    fg.quantity_on_hand,
    fg.quantity_reserved,
    fg.reorder_point,
    fg.safety_stock_level,

    p.standard_cost,

    fg.last_updated_at

FROM silver.FinishedGoodsInventory fg

INNER JOIN silver.Products p
    ON p.product_id = fg.product_id;
GO

CREATE OR ALTER VIEW gold.vw_FactFinishedGoodsTransaction
AS
SELECT
    tx.finished_inventory_transaction_id,
    tx.finished_goods_inventory_id,

    inv.warehouse_id,
    inv.product_id,

    tx.production_id,
    tx.customer_shipment_detail_id,

    tx.transaction_type,
    tx.quantity,
    tx.unit_cost,
    tx.transaction_date,
    CAST(tx.transaction_date AS DATE) AS transaction_day,
    tx.reference_code

FROM silver.FinishedGoodsInventoryTransactions tx

INNER JOIN silver.FinishedGoodsInventory inv
    ON inv.finished_goods_inventory_id = tx.finished_goods_inventory_id;
GO

CREATE OR ALTER VIEW gold.vw_FactSalesOrderDetail
AS
SELECT
    sod.sales_order_detail_id,
    sod.sales_order_id,

    so.customer_id,
    sod.product_id,

    so.order_date,
    so.required_delivery_date,

    so.sales_order_status,
    sod.line_status,

    so.payment_method,
    so.tax_percentage,

    sod.ordered_quantity,

    p.selling_price,
    p.standard_cost

FROM silver.SalesOrderDetails sod

INNER JOIN silver.SalesOrders so
    ON so.sales_order_id = sod.sales_order_id

INNER JOIN silver.Products p
    ON p.product_id = sod.product_id;
GO

CREATE OR ALTER VIEW gold.vw_FactCustomerShipment
AS
SELECT
    cs.customer_shipment_id,
    cs.sales_order_id,

    so.customer_id,
    cs.warehouse_id,

    so.order_date,
    so.required_delivery_date,

    cs.shipment_date,
    cs.expected_delivery_date,
    cs.actual_delivery_date,

    cs.shipping_method,
    cs.shipping_cost,
    cs.shipment_status,
    cs.delivery_confirmation

FROM silver.CustomerShipments cs

INNER JOIN silver.SalesOrders so
    ON so.sales_order_id = cs.sales_order_id;
GO

CREATE OR ALTER VIEW gold.vw_FactCustomerShipmentDetail
AS
SELECT
    csd.customer_shipment_detail_id,
    csd.customer_shipment_id,
    csd.sales_order_detail_id,

    cs.sales_order_id,
    so.customer_id,
    sod.product_id,
    cs.warehouse_id,

    so.order_date,
    cs.shipment_date,
    cs.expected_delivery_date,
    cs.actual_delivery_date,

    so.sales_order_status,
    sod.line_status,
    cs.shipment_status,

    sod.ordered_quantity AS line_ordered_quantity_nonadditive,
    csd.shipped_quantity,

    p.selling_price,
    p.standard_cost

FROM silver.CustomerShipmentDetails csd

INNER JOIN silver.CustomerShipments cs
    ON cs.customer_shipment_id = csd.customer_shipment_id

INNER JOIN silver.SalesOrders so
    ON so.sales_order_id = cs.sales_order_id

INNER JOIN silver.SalesOrderDetails sod
    ON sod.sales_order_detail_id = csd.sales_order_detail_id

INNER JOIN silver.Products p
    ON p.product_id = sod.product_id;
GO

CREATE OR ALTER VIEW gold.vw_FactReturn
AS
SELECT
    r.return_id,
    r.customer_shipment_detail_id,

    csd.customer_shipment_id,
    sod.sales_order_detail_id,
    cs.sales_order_id,

    so.customer_id,
    sod.product_id,
    cs.warehouse_id,

    cs.shipment_date,
    cs.actual_delivery_date,

    r.return_request_date,
    r.return_received_date,

    r.returned_quantity,
    csd.shipped_quantity AS line_shipped_quantity_nonadditive,

    r.return_reason,
    r.product_condition,
    r.return_status

FROM silver.Returns r

INNER JOIN silver.CustomerShipmentDetails csd
    ON csd.customer_shipment_detail_id = r.customer_shipment_detail_id

INNER JOIN silver.CustomerShipments cs
    ON cs.customer_shipment_id = csd.customer_shipment_id

INNER JOIN silver.SalesOrderDetails sod
    ON sod.sales_order_detail_id = csd.sales_order_detail_id

INNER JOIN silver.SalesOrders so
    ON so.sales_order_id = cs.sales_order_id;
GO

CREATE OR ALTER VIEW gold.vw_FactSalesFulfillment
AS
-- Grain: one sales order detail, including every unshipped line.
-- Order-date cohort; do not use as shipment-date-period fill rate.
SELECT sod.sales_order_detail_id,sod.sales_order_id,so.customer_id,sod.product_id,
 so.order_date,so.required_delivery_date,so.sales_order_status,sod.line_status,
 sod.ordered_quantity,COALESCE(sh.shipped_quantity,0) AS shipped_quantity,
 sod.ordered_quantity-COALESCE(sh.shipped_quantity,0) AS unfulfilled_quantity,
 COALESCE(sh.shipment_line_count,0) AS shipment_line_count,
 sh.first_shipment_date,sh.last_shipment_date,
 p.selling_price AS reference_selling_price,p.standard_cost AS reference_standard_cost
FROM silver.SalesOrderDetails sod
JOIN silver.SalesOrders so ON so.sales_order_id=sod.sales_order_id
JOIN silver.Products p ON p.product_id=sod.product_id
LEFT JOIN (
 SELECT d.sales_order_detail_id,SUM(d.shipped_quantity) AS shipped_quantity,
 COUNT_BIG(*) AS shipment_line_count,MIN(h.shipment_date) AS first_shipment_date,MAX(h.shipment_date) AS last_shipment_date
 FROM silver.CustomerShipmentDetails d
 JOIN silver.CustomerShipments h ON h.customer_shipment_id=d.customer_shipment_id
 GROUP BY d.sales_order_detail_id
) sh ON sh.sales_order_detail_id=sod.sales_order_detail_id;
GO

CREATE OR ALTER VIEW gold.vw_FactSupplierInvoice
AS
-- One invoice. paid_amount is completed payments only, across all supplied payment dates.
-- Current extract balance; NOT a historical/as-of-date accounts payable balance.
SELECT i.invoice_id,i.shipment_id,i.supplier_id,i.invoice_date,i.due_date,
 i.invoice_amount,i.tax_amount,i.total_amount,i.payment_terms,i.payment_status,
 COALESCE(p.paid_amount,0) AS paid_amount,
 i.total_amount-COALESCE(p.paid_amount,0) AS outstanding_amount
FROM silver.SupplierInvoices i
LEFT JOIN (SELECT invoice_id,SUM(payment_amount) AS paid_amount FROM silver.SupplierPayments
 WHERE payment_status='Completed' GROUP BY invoice_id) p ON p.invoice_id=i.invoice_id;
GO

CREATE OR ALTER VIEW gold.vw_FactSupplierInvoiceDetail
AS
SELECT d.invoice_detail_id,d.invoice_id,d.gr_detail_id,i.supplier_id,g.material_id,
 i.invoice_date,i.due_date,d.billed_quantity,d.unit_price,d.tax_amount,d.line_amount
FROM silver.SupplierInvoiceDetails d
JOIN silver.SupplierInvoices i ON i.invoice_id=d.invoice_id
JOIN silver.GoodsReceiptDetails g ON g.gr_detail_id=d.gr_detail_id;
GO

CREATE OR ALTER VIEW gold.vw_FactSupplierPayment
AS
SELECT p.payment_id,p.invoice_id,i.supplier_id,p.payment_date,p.payment_amount,
 p.payment_method,p.currency,p.payment_status,i.due_date
FROM silver.SupplierPayments p JOIN silver.SupplierInvoices i ON i.invoice_id=p.invoice_id;
GO

