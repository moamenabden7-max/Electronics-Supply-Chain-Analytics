﻿USE [ElectronicsSupplyChainDB_v2];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO
-- Non-destructive setup. Re-running does not drop existing tables.
IF OBJECT_ID(N'bronze.Departments',N'U') IS NULL
CREATE TABLE bronze.[Departments]
(
    [department_id] INT NOT NULL,
    [department_code] VARCHAR(20) NOT NULL,
    [department_name] VARCHAR(100) NOT NULL,
    [department_description] VARCHAR(250) NOT NULL,
    [status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.Materials',N'U') IS NULL
CREATE TABLE bronze.[Materials]
(
    [material_id] INT NOT NULL,
    [material_code] VARCHAR(30) NOT NULL,
    [material_name] VARCHAR(100) NOT NULL,
    [material_category] VARCHAR(60) NOT NULL,
    [material_type] VARCHAR(50) NOT NULL,
    [uom] VARCHAR(20) NOT NULL,
    [unit_weight] DECIMAL(18,3) NOT NULL,
    [status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.Suppliers',N'U') IS NULL
CREATE TABLE bronze.[Suppliers]
(
    [supplier_id] INT NOT NULL,
    [supplier_code] VARCHAR(30) NOT NULL,
    [supplier_name] VARCHAR(120) NOT NULL,
    [supplier_type] VARCHAR(50) NOT NULL,
    [supplier_category] VARCHAR(50) NOT NULL,
    [country] VARCHAR(50) NOT NULL,
    [city] VARCHAR(50) NOT NULL,
    [address] VARCHAR(250) NOT NULL,
    [contact_person] VARCHAR(100) NOT NULL,
    [phone] VARCHAR(20) NOT NULL,
    [email] VARCHAR(120) NOT NULL,
    [payment_terms] VARCHAR(50) NOT NULL,
    [status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.SupplierMaterials',N'U') IS NULL
CREATE TABLE bronze.[SupplierMaterials]
(
    [supplier_material_id] INT NOT NULL,
    [supplier_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [supplier_material_code] VARCHAR(50) NOT NULL,
    [standard_price] DECIMAL(18,2) NOT NULL,
    [lead_time_days] INT NOT NULL,
    [minimum_order_quantity] DECIMAL(18,2) NOT NULL,
    [preferred_supplier] BIT NOT NULL,
    [status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.PurchaseRequisitions',N'U') IS NULL
CREATE TABLE bronze.[PurchaseRequisitions]
(
    [pr_id] INT NOT NULL,
    [pr_code] VARCHAR(20) NOT NULL,
    [department_id] INT NOT NULL,
    [requested_by] VARCHAR(100) NOT NULL,
    [request_date] DATE NOT NULL,
    [order_date] DATE NULL,
    [required_date] DATE NOT NULL,
    [priority] VARCHAR(20) NOT NULL,
    [approval_status] VARCHAR(20) NOT NULL,
    [approved_by] VARCHAR(100) NOT NULL,
    [approval_date] DATE NOT NULL,
    [rejection_reason] VARCHAR(250) NULL,
    [created_date] DATE NULL
);
GO
IF OBJECT_ID(N'bronze.PurchaseRequisitionDetails',N'U') IS NULL
CREATE TABLE bronze.[PurchaseRequisitionDetails]
(
    [pr_detail_id] INT NOT NULL,
    [pr_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [requested_quantity] DECIMAL(18,2) NOT NULL,
    [estimated_unit_cost] DECIMAL(18,2) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.PurchaseOrders',N'U') IS NULL
CREATE TABLE bronze.[PurchaseOrders]
(
    [po_id] INT NOT NULL,
    [po_code] VARCHAR(20) NOT NULL,
    [supplier_id] INT NOT NULL,
    [pr_id] INT NOT NULL,
    [order_date] DATE NOT NULL,
    [expected_delivery_date] DATE NOT NULL,
    [payment_terms] VARCHAR(50) NOT NULL,
    [status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.PurchaseOrderDetails',N'U') IS NULL
CREATE TABLE bronze.[PurchaseOrderDetails]
(
    [po_detail_id] INT NOT NULL,
    [po_id] INT NOT NULL,
    [pr_detail_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [ordered_quantity] DECIMAL(18,2) NOT NULL,
    [unit_price] DECIMAL(18,2) NOT NULL,
    [discount_percentage] DECIMAL(5,2) NOT NULL,
    [expected_delivery_date] DATE NOT NULL,
    [total_amount] DECIMAL(18,2) NOT NULL,
    [line_status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.SupplierShipments',N'U') IS NULL
CREATE TABLE bronze.[SupplierShipments]
(
    [shipment_id] INT NOT NULL,
    [shipment_code] VARCHAR(20) NOT NULL,
    [po_id] INT NOT NULL,
    [supplier_id] INT NOT NULL,
    [supplier_reference] VARCHAR(50) NOT NULL,
    [ship_date] DATE NOT NULL,
    [expected_arrival_date] DATE NOT NULL,
    [actual_arrival_date] DATE NOT NULL,
    [total_shipment_value] DECIMAL(18,2) NOT NULL,
    [shipping_cost] DECIMAL(18,2) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.SupplierShipmentDetails',N'U') IS NULL
CREATE TABLE bronze.[SupplierShipmentDetails]
(
    [shipment_detail_id] INT NOT NULL,
    [shipment_id] INT NOT NULL,
    [po_detail_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [received_quantity] DECIMAL(18,2) NOT NULL,
    [accepted_quantity] DECIMAL(18,2) NOT NULL,
    [rejected_quantity] DECIMAL(18,2) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.GoodsReceipts',N'U') IS NULL
CREATE TABLE bronze.[GoodsReceipts]
(
    [gr_id] INT NOT NULL,
    [gr_code] VARCHAR(20) NOT NULL,
    [shipment_id] INT NOT NULL,
    [receipt_date] DATE NOT NULL,
    [received_by] VARCHAR(100) NOT NULL,
    [quality_check_status] VARCHAR(20) NOT NULL,
    [total_received_value] DECIMAL(18,2) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.GoodsReceiptDetails',N'U') IS NULL
CREATE TABLE bronze.[GoodsReceiptDetails]
(
    [gr_detail_id] INT NOT NULL,
    [gr_id] INT NOT NULL,
    [shipment_detail_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [received_quantity] DECIMAL(18,2) NOT NULL,
    [accepted_quantity] DECIMAL(18,2) NOT NULL,
    [rejected_quantity] DECIMAL(18,2) NOT NULL,
    [inspection_status] VARCHAR(30) NOT NULL,
    [batch_number] VARCHAR(50) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.QualityInspections',N'U') IS NULL
CREATE TABLE bronze.[QualityInspections]
(
    [inspection_id] INT NOT NULL,
    [gr_detail_id] INT NOT NULL,
    [inspection_date] DATE NOT NULL,
    [inspection_type] VARCHAR(50) NOT NULL,
    [inspected_quantity] DECIMAL(18,2) NOT NULL,
    [passed_quantity] DECIMAL(18,2) NOT NULL,
    [inspection_result] VARCHAR(30) NOT NULL,
    [defect_quantity] DECIMAL(18,2) NOT NULL,
    [defect_reason] VARCHAR(250) NOT NULL,
    [corrective_action] VARCHAR(250) NOT NULL,
    [reinspection_required] BIT NOT NULL,
    [status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.SupplierInvoices',N'U') IS NULL
CREATE TABLE bronze.[SupplierInvoices]
(
    [invoice_id] INT NOT NULL,
    [invoice_number] VARCHAR(30) NOT NULL,
    [shipment_id] INT NOT NULL,
    [supplier_id] INT NOT NULL,
    [invoice_date] DATE NOT NULL,
    [invoice_amount] DECIMAL(18,2) NOT NULL,
    [tax_amount] DECIMAL(18,2) NOT NULL,
    [total_amount] DECIMAL(18,2) NOT NULL,
    [due_date] DATE NOT NULL,
    [payment_terms] VARCHAR(50) NOT NULL,
    [payment_status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.SupplierInvoiceDetails',N'U') IS NULL
CREATE TABLE bronze.[SupplierInvoiceDetails]
(
    [invoice_detail_id] INT NOT NULL,
    [invoice_id] INT NOT NULL,
    [gr_detail_id] INT NOT NULL,
    [billed_quantity] DECIMAL(18,2) NOT NULL,
    [unit_price] DECIMAL(18,2) NOT NULL,
    [tax_amount] DECIMAL(18,2) NOT NULL,
    [line_amount] DECIMAL(18,2) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.SupplierPayments',N'U') IS NULL
CREATE TABLE bronze.[SupplierPayments]
(
    [payment_id] INT NOT NULL,
    [invoice_id] INT NOT NULL,
    [payment_date] DATE NOT NULL,
    [payment_amount] DECIMAL(18,2) NOT NULL,
    [payment_method] VARCHAR(30) NOT NULL,
    [currency] CHAR(3) NOT NULL,
    [transaction_reference] VARCHAR(100) NOT NULL,
    [payment_status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.Warehouses',N'U') IS NULL
CREATE TABLE bronze.[Warehouses]
(
    [warehouse_id] INT NOT NULL,
    [warehouse_code] VARCHAR(20) NOT NULL,
    [warehouse_name] VARCHAR(100) NOT NULL,
    [warehouse_type] VARCHAR(50) NOT NULL,
    [country] VARCHAR(50) NOT NULL,
    [city] VARCHAR(50) NOT NULL,
    [location_description] VARCHAR(250) NOT NULL,
    [status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.RawMaterialInventory',N'U') IS NULL
CREATE TABLE bronze.[RawMaterialInventory]
(
    [raw_inventory_id] INT NOT NULL,
    [warehouse_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [quantity_on_hand] DECIMAL(18,2) NOT NULL,
    [quantity_reserved] DECIMAL(18,2) NOT NULL,
    [reorder_point] DECIMAL(18,2) NOT NULL,
    [safety_stock_level] DECIMAL(18,2) NOT NULL,
    [max_inventory_level] DECIMAL(18,2) NOT NULL,
    [unit_cost] DECIMAL(18,2) NOT NULL,
    [last_updated_at] DATE NULL
);
GO
IF OBJECT_ID(N'bronze.Products',N'U') IS NULL
CREATE TABLE bronze.[Products]
(
    [product_id] INT NOT NULL,
    [product_code] VARCHAR(30) NOT NULL,
    [product_name] VARCHAR(100) NOT NULL,
    [product_category] VARCHAR(50) NOT NULL,
    [uom] VARCHAR(20) NOT NULL,
    [standard_cost] DECIMAL(18,2) NOT NULL,
    [selling_price] DECIMAL(18,2) NOT NULL,
    [status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.ProductBOM',N'U') IS NULL
CREATE TABLE bronze.[ProductBOM]
(
    [bom_id] INT NOT NULL,
    [product_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [quantity_required] DECIMAL(18,3) NOT NULL,
    [uom] VARCHAR(20) NOT NULL,
    [status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.Production',N'U') IS NULL
CREATE TABLE bronze.[Production]
(
    [production_id] INT NOT NULL,
    [production_order_code] VARCHAR(30) NOT NULL,
    [product_id] INT NOT NULL,
    [planned_quantity] DECIMAL(18,2) NOT NULL,
    [start_date] DATE NOT NULL,
    [expected_end_date] DATE NOT NULL,
    [actual_end_date] DATE NULL,
    [production_quantity] DECIMAL(18,2) NOT NULL,
    [rejected_quantity] DECIMAL(18,2) NOT NULL,
    [production_status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.ProductionDetails',N'U') IS NULL
CREATE TABLE bronze.[ProductionDetails]
(
    [production_detail_id] INT NOT NULL,
    [production_id] INT NOT NULL,
    [bom_id] INT NOT NULL,
    [raw_inventory_id] INT NOT NULL,
    [actual_consumed_quantity] DECIMAL(18,3) NOT NULL,
    [return_quantity] DECIMAL(18,3) NOT NULL,
    [scrap_quantity] DECIMAL(18,3) NOT NULL,
    [unit_cost] DECIMAL(18,2) NOT NULL,
    [total_material_cost] DECIMAL(18,2) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.RawMaterialInventoryTransactions',N'U') IS NULL
CREATE TABLE bronze.[RawMaterialInventoryTransactions]
(
    [raw_transaction_id] INT NOT NULL,
    [raw_inventory_id] INT NOT NULL,
    [production_id] INT NOT NULL,
    [inspection_id] INT NOT NULL,
    [transaction_type] VARCHAR(40) NOT NULL,
    [quantity] DECIMAL(18,3) NOT NULL,
    [unit_cost] DECIMAL(18,2) NOT NULL,
    [transaction_date] DATE NULL,
    [reference_code] VARCHAR(50) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.FinishedGoodsInventory',N'U') IS NULL
CREATE TABLE bronze.[FinishedGoodsInventory]
(
    [finished_goods_inventory_id] INT NOT NULL,
    [warehouse_id] INT NOT NULL,
    [product_id] INT NOT NULL,
    [quantity_on_hand] DECIMAL(18,2) NOT NULL,
    [quantity_reserved] INT NOT NULL,
    [reorder_point] DECIMAL(18,2) NOT NULL,
    [safety_stock_level] DECIMAL(18,2) NOT NULL,
    [last_updated_at] DATE NULL
);
GO
IF OBJECT_ID(N'bronze.Customers',N'U') IS NULL
CREATE TABLE bronze.[Customers]
(
    [customer_id] INT NOT NULL,
    [customer_code] VARCHAR(30) NOT NULL,
    [customer_name] VARCHAR(100) NOT NULL,
    [customer_type] VARCHAR(50) NOT NULL,
    [email] VARCHAR(120) NULL,
    [phone] VARCHAR(20) NOT NULL,
    [country] VARCHAR(50) NOT NULL,
    [city] VARCHAR(50) NOT NULL,
    [address] VARCHAR(250) NOT NULL,
    [registration_date] DATE NOT NULL,
    [default_discount_percentage] DECIMAL(5,2) NOT NULL,
    [status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.SalesOrders',N'U') IS NULL
CREATE TABLE bronze.[SalesOrders]
(
    [sales_order_id] INT NOT NULL,
    [sales_order_code] VARCHAR(20) NOT NULL,
    [customer_id] INT NOT NULL,
    [order_date] DATE NOT NULL,
    [required_delivery_date] DATE NOT NULL,
    [payment_method] VARCHAR(30) NOT NULL,
    [tax_percentage] DECIMAL(5,2) NOT NULL,
    [sales_order_status] VARCHAR(30) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.SalesOrderDetails',N'U') IS NULL
CREATE TABLE bronze.[SalesOrderDetails]
(
    [sales_order_detail_id] INT NOT NULL,
    [sales_order_id] INT NOT NULL,
    [product_id] INT NOT NULL,
    [ordered_quantity] DECIMAL(18,2) NOT NULL,
    [line_status] VARCHAR(30) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.CustomerShipments',N'U') IS NULL
CREATE TABLE bronze.[CustomerShipments]
(
    [customer_shipment_id] INT NOT NULL,
    [shipment_code] VARCHAR(20) NOT NULL,
    [sales_order_id] INT NOT NULL,
    [warehouse_id] INT NOT NULL,
    [shipment_date] DATE NOT NULL,
    [expected_delivery_date] DATE NOT NULL,
    [actual_delivery_date] DATE NULL,
    [tracking_number] VARCHAR(50) NOT NULL,
    [shipping_method] VARCHAR(30) NOT NULL,
    [shipping_cost] DECIMAL(18,2) NOT NULL,
    [delivery_address] VARCHAR(300) NOT NULL,
    [shipment_status] VARCHAR(30) NOT NULL,
    [delivery_confirmation] BIT NOT NULL,
    [customer_feedback] VARCHAR(500) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.CustomerShipmentDetails',N'U') IS NULL
CREATE TABLE bronze.[CustomerShipmentDetails]
(
    [customer_shipment_detail_id] INT NOT NULL,
    [customer_shipment_id] INT NOT NULL,
    [sales_order_detail_id] INT NOT NULL,
    [shipped_quantity] DECIMAL(18,2) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.FinishedGoodsInventoryTransactions',N'U') IS NULL
CREATE TABLE bronze.[FinishedGoodsInventoryTransactions]
(
    [finished_inventory_transaction_id] INT NOT NULL,
    [finished_goods_inventory_id] INT NOT NULL,
    [production_id] INT NOT NULL,
    [customer_shipment_detail_id] INT NOT NULL,
    [transaction_type] VARCHAR(40) NOT NULL,
    [quantity] DECIMAL(18,2) NOT NULL,
    [unit_cost] DECIMAL(18,2) NOT NULL,
    [transaction_date] DATE NULL,
    [reference_code] VARCHAR(50) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.Returns',N'U') IS NULL
CREATE TABLE bronze.[Returns]
(
    [return_id] INT NOT NULL,
    [return_code] VARCHAR(20) NOT NULL,
    [customer_shipment_detail_id] INT NOT NULL,
    [return_request_date] DATE NOT NULL,
    [return_received_date] DATE NOT NULL,
    [returned_quantity] DECIMAL(18,2) NOT NULL,
    [return_reason] VARCHAR(120) NOT NULL,
    [product_condition] VARCHAR(50) NOT NULL,
    [return_status] VARCHAR(30) NOT NULL
);
GO
