﻿USE [ElectronicsSupplyChainDB_v2];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO
SELECT TOP(10) * FROM etl.RunLog ORDER BY run_id DESC;
SELECT COUNT_BIG(*) AS sales_lines,SUM(ordered_quantity) AS ordered_quantity,
 SUM(shipped_quantity) AS shipped_quantity,
 CAST(100.0*SUM(shipped_quantity)/NULLIF(SUM(ordered_quantity),0) AS DECIMAL(10,4)) AS quantity_fill_rate_pct
FROM gold.vw_FactSalesFulfillment;
SELECT production_status,COUNT_BIG(*) AS orders_count FROM silver.Production GROUP BY production_status;
SELECT COUNT_BIG(*) AS calendar_days,MIN(full_date) AS start_date,MAX(full_date) AS end_date FROM gold.DimDate;
SELECT SUM(scrap_quantity) AS scrap_quantity_diagnostic FROM silver.ProductionDetails;
-- Diagnostic sum only: do not combine different material UOM as one business KPI.
GO
