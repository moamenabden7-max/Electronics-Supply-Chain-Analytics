﻿-- INSTALL ONLY. Does not load, delete, or replace existing business data.

-- FILE: 00_Create_Database.sql
-- SQL Server 2017+ on Windows. New database; original database is untouched.
USE master;
GO
IF DB_ID(N'ElectronicsSupplyChainDB_v2') IS NULL
    EXEC(N'CREATE DATABASE [ElectronicsSupplyChainDB_v2]');
GO
USE [ElectronicsSupplyChainDB_v2];
GO
IF SCHEMA_ID(N'bronze') IS NULL EXEC(N'CREATE SCHEMA bronze AUTHORIZATION dbo');
IF SCHEMA_ID(N'silver') IS NULL EXEC(N'CREATE SCHEMA silver AUTHORIZATION dbo');
IF SCHEMA_ID(N'gold') IS NULL EXEC(N'CREATE SCHEMA gold AUTHORIZATION dbo');
IF SCHEMA_ID(N'etl') IS NULL EXEC(N'CREATE SCHEMA etl AUTHORIZATION dbo');
GO
IF OBJECT_ID(N'etl.RunLog',N'U') IS NULL
CREATE TABLE etl.RunLog
(
 run_id BIGINT IDENTITY PRIMARY KEY,
 started_at DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
 completed_at DATETIME2(0) NULL,
 run_status VARCHAR(20) NOT NULL,
 error_message NVARCHAR(2048) NULL
);
GO


-- FILE: 01_Create_Bronze.sql
USE [ElectronicsSupplyChainDB_v2];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO
-- Non-destructive setup. Re-running does not drop existing tables.
IF OBJECT_ID(N'bronze.Departments',N'U') IS NULL
CREATE TABLE bronze.[Departments]
(
    [department_id] INT NOT NULL,
    [department_code] VARCHAR(20) NOT NULL,
    [department_name] VARCHAR(100) NOT NULL,
    [department_description] VARCHAR(250) NOT NULL,
    [status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.Materials',N'U') IS NULL
CREATE TABLE bronze.[Materials]
(
    [material_id] INT NOT NULL,
    [material_code] VARCHAR(30) NOT NULL,
    [material_name] VARCHAR(100) NOT NULL,
    [material_category] VARCHAR(60) NOT NULL,
    [material_type] VARCHAR(50) NOT NULL,
    [uom] VARCHAR(20) NOT NULL,
    [unit_weight] DECIMAL(18,3) NOT NULL,
    [status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.Suppliers',N'U') IS NULL
CREATE TABLE bronze.[Suppliers]
(
    [supplier_id] INT NOT NULL,
    [supplier_code] VARCHAR(30) NOT NULL,
    [supplier_name] VARCHAR(120) NOT NULL,
    [supplier_type] VARCHAR(50) NOT NULL,
    [supplier_category] VARCHAR(50) NOT NULL,
    [country] VARCHAR(50) NOT NULL,
    [city] VARCHAR(50) NOT NULL,
    [address] VARCHAR(250) NOT NULL,
    [contact_person] VARCHAR(100) NOT NULL,
    [phone] VARCHAR(20) NOT NULL,
    [email] VARCHAR(120) NOT NULL,
    [payment_terms] VARCHAR(50) NOT NULL,
    [status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.SupplierMaterials',N'U') IS NULL
CREATE TABLE bronze.[SupplierMaterials]
(
    [supplier_material_id] INT NOT NULL,
    [supplier_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [supplier_material_code] VARCHAR(50) NOT NULL,
    [standard_price] DECIMAL(18,2) NOT NULL,
    [lead_time_days] INT NOT NULL,
    [minimum_order_quantity] DECIMAL(18,2) NOT NULL,
    [preferred_supplier] BIT NOT NULL,
    [status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.PurchaseRequisitions',N'U') IS NULL
CREATE TABLE bronze.[PurchaseRequisitions]
(
    [pr_id] INT NOT NULL,
    [pr_code] VARCHAR(20) NOT NULL,
    [department_id] INT NOT NULL,
    [requested_by] VARCHAR(100) NOT NULL,
    [request_date] DATE NOT NULL,
    [order_date] DATE NULL,
    [required_date] DATE NOT NULL,
    [priority] VARCHAR(20) NOT NULL,
    [approval_status] VARCHAR(20) NOT NULL,
    [approved_by] VARCHAR(100) NOT NULL,
    [approval_date] DATE NOT NULL,
    [rejection_reason] VARCHAR(250) NULL,
    [created_date] DATE NULL
);
GO
IF OBJECT_ID(N'bronze.PurchaseRequisitionDetails',N'U') IS NULL
CREATE TABLE bronze.[PurchaseRequisitionDetails]
(
    [pr_detail_id] INT NOT NULL,
    [pr_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [requested_quantity] DECIMAL(18,2) NOT NULL,
    [estimated_unit_cost] DECIMAL(18,2) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.PurchaseOrders',N'U') IS NULL
CREATE TABLE bronze.[PurchaseOrders]
(
    [po_id] INT NOT NULL,
    [po_code] VARCHAR(20) NOT NULL,
    [supplier_id] INT NOT NULL,
    [pr_id] INT NOT NULL,
    [order_date] DATE NOT NULL,
    [expected_delivery_date] DATE NOT NULL,
    [payment_terms] VARCHAR(50) NOT NULL,
    [status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.PurchaseOrderDetails',N'U') IS NULL
CREATE TABLE bronze.[PurchaseOrderDetails]
(
    [po_detail_id] INT NOT NULL,
    [po_id] INT NOT NULL,
    [pr_detail_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [ordered_quantity] DECIMAL(18,2) NOT NULL,
    [unit_price] DECIMAL(18,2) NOT NULL,
    [discount_percentage] DECIMAL(5,2) NOT NULL,
    [expected_delivery_date] DATE NOT NULL,
    [total_amount] DECIMAL(18,2) NOT NULL,
    [line_status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.SupplierShipments',N'U') IS NULL
CREATE TABLE bronze.[SupplierShipments]
(
    [shipment_id] INT NOT NULL,
    [shipment_code] VARCHAR(20) NOT NULL,
    [po_id] INT NOT NULL,
    [supplier_id] INT NOT NULL,
    [supplier_reference] VARCHAR(50) NOT NULL,
    [ship_date] DATE NOT NULL,
    [expected_arrival_date] DATE NOT NULL,
    [actual_arrival_date] DATE NOT NULL,
    [total_shipment_value] DECIMAL(18,2) NOT NULL,
    [shipping_cost] DECIMAL(18,2) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.SupplierShipmentDetails',N'U') IS NULL
CREATE TABLE bronze.[SupplierShipmentDetails]
(
    [shipment_detail_id] INT NOT NULL,
    [shipment_id] INT NOT NULL,
    [po_detail_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [received_quantity] DECIMAL(18,2) NOT NULL,
    [accepted_quantity] DECIMAL(18,2) NOT NULL,
    [rejected_quantity] DECIMAL(18,2) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.GoodsReceipts',N'U') IS NULL
CREATE TABLE bronze.[GoodsReceipts]
(
    [gr_id] INT NOT NULL,
    [gr_code] VARCHAR(20) NOT NULL,
    [shipment_id] INT NOT NULL,
    [receipt_date] DATE NOT NULL,
    [received_by] VARCHAR(100) NOT NULL,
    [quality_check_status] VARCHAR(20) NOT NULL,
    [total_received_value] DECIMAL(18,2) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.GoodsReceiptDetails',N'U') IS NULL
CREATE TABLE bronze.[GoodsReceiptDetails]
(
    [gr_detail_id] INT NOT NULL,
    [gr_id] INT NOT NULL,
    [shipment_detail_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [received_quantity] DECIMAL(18,2) NOT NULL,
    [accepted_quantity] DECIMAL(18,2) NOT NULL,
    [rejected_quantity] DECIMAL(18,2) NOT NULL,
    [inspection_status] VARCHAR(30) NOT NULL,
    [batch_number] VARCHAR(50) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.QualityInspections',N'U') IS NULL
CREATE TABLE bronze.[QualityInspections]
(
    [inspection_id] INT NOT NULL,
    [gr_detail_id] INT NOT NULL,
    [inspection_date] DATE NOT NULL,
    [inspection_type] VARCHAR(50) NOT NULL,
    [inspected_quantity] DECIMAL(18,2) NOT NULL,
    [passed_quantity] DECIMAL(18,2) NOT NULL,
    [inspection_result] VARCHAR(30) NOT NULL,
    [defect_quantity] DECIMAL(18,2) NOT NULL,
    [defect_reason] VARCHAR(250) NOT NULL,
    [corrective_action] VARCHAR(250) NOT NULL,
    [reinspection_required] BIT NOT NULL,
    [status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.SupplierInvoices',N'U') IS NULL
CREATE TABLE bronze.[SupplierInvoices]
(
    [invoice_id] INT NOT NULL,
    [invoice_number] VARCHAR(30) NOT NULL,
    [shipment_id] INT NOT NULL,
    [supplier_id] INT NOT NULL,
    [invoice_date] DATE NOT NULL,
    [invoice_amount] DECIMAL(18,2) NOT NULL,
    [tax_amount] DECIMAL(18,2) NOT NULL,
    [total_amount] DECIMAL(18,2) NOT NULL,
    [due_date] DATE NOT NULL,
    [payment_terms] VARCHAR(50) NOT NULL,
    [payment_status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.SupplierInvoiceDetails',N'U') IS NULL
CREATE TABLE bronze.[SupplierInvoiceDetails]
(
    [invoice_detail_id] INT NOT NULL,
    [invoice_id] INT NOT NULL,
    [gr_detail_id] INT NOT NULL,
    [billed_quantity] DECIMAL(18,2) NOT NULL,
    [unit_price] DECIMAL(18,2) NOT NULL,
    [tax_amount] DECIMAL(18,2) NOT NULL,
    [line_amount] DECIMAL(18,2) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.SupplierPayments',N'U') IS NULL
CREATE TABLE bronze.[SupplierPayments]
(
    [payment_id] INT NOT NULL,
    [invoice_id] INT NOT NULL,
    [payment_date] DATE NOT NULL,
    [payment_amount] DECIMAL(18,2) NOT NULL,
    [payment_method] VARCHAR(30) NOT NULL,
    [currency] CHAR(3) NOT NULL,
    [transaction_reference] VARCHAR(100) NOT NULL,
    [payment_status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.Warehouses',N'U') IS NULL
CREATE TABLE bronze.[Warehouses]
(
    [warehouse_id] INT NOT NULL,
    [warehouse_code] VARCHAR(20) NOT NULL,
    [warehouse_name] VARCHAR(100) NOT NULL,
    [warehouse_type] VARCHAR(50) NOT NULL,
    [country] VARCHAR(50) NOT NULL,
    [city] VARCHAR(50) NOT NULL,
    [location_description] VARCHAR(250) NOT NULL,
    [status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.RawMaterialInventory',N'U') IS NULL
CREATE TABLE bronze.[RawMaterialInventory]
(
    [raw_inventory_id] INT NOT NULL,
    [warehouse_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [quantity_on_hand] DECIMAL(18,2) NOT NULL,
    [quantity_reserved] DECIMAL(18,2) NOT NULL,
    [reorder_point] DECIMAL(18,2) NOT NULL,
    [safety_stock_level] DECIMAL(18,2) NOT NULL,
    [max_inventory_level] DECIMAL(18,2) NOT NULL,
    [unit_cost] DECIMAL(18,2) NOT NULL,
    [last_updated_at] DATE NULL
);
GO
IF OBJECT_ID(N'bronze.Products',N'U') IS NULL
CREATE TABLE bronze.[Products]
(
    [product_id] INT NOT NULL,
    [product_code] VARCHAR(30) NOT NULL,
    [product_name] VARCHAR(100) NOT NULL,
    [product_category] VARCHAR(50) NOT NULL,
    [uom] VARCHAR(20) NOT NULL,
    [standard_cost] DECIMAL(18,2) NOT NULL,
    [selling_price] DECIMAL(18,2) NOT NULL,
    [status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.ProductBOM',N'U') IS NULL
CREATE TABLE bronze.[ProductBOM]
(
    [bom_id] INT NOT NULL,
    [product_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [quantity_required] DECIMAL(18,3) NOT NULL,
    [uom] VARCHAR(20) NOT NULL,
    [status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.Production',N'U') IS NULL
CREATE TABLE bronze.[Production]
(
    [production_id] INT NOT NULL,
    [production_order_code] VARCHAR(30) NOT NULL,
    [product_id] INT NOT NULL,
    [planned_quantity] DECIMAL(18,2) NOT NULL,
    [start_date] DATE NOT NULL,
    [expected_end_date] DATE NOT NULL,
    [actual_end_date] DATE NULL,
    [production_quantity] DECIMAL(18,2) NOT NULL,
    [rejected_quantity] DECIMAL(18,2) NOT NULL,
    [production_status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.ProductionDetails',N'U') IS NULL
CREATE TABLE bronze.[ProductionDetails]
(
    [production_detail_id] INT NOT NULL,
    [production_id] INT NOT NULL,
    [bom_id] INT NOT NULL,
    [raw_inventory_id] INT NOT NULL,
    [actual_consumed_quantity] DECIMAL(18,3) NOT NULL,
    [return_quantity] DECIMAL(18,3) NOT NULL,
    [scrap_quantity] DECIMAL(18,3) NOT NULL,
    [unit_cost] DECIMAL(18,2) NOT NULL,
    [total_material_cost] DECIMAL(18,2) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.RawMaterialInventoryTransactions',N'U') IS NULL
CREATE TABLE bronze.[RawMaterialInventoryTransactions]
(
    [raw_transaction_id] INT NOT NULL,
    [raw_inventory_id] INT NOT NULL,
    [production_id] INT NOT NULL,
    [inspection_id] INT NOT NULL,
    [transaction_type] VARCHAR(40) NOT NULL,
    [quantity] DECIMAL(18,3) NOT NULL,
    [unit_cost] DECIMAL(18,2) NOT NULL,
    [transaction_date] DATE NULL,
    [reference_code] VARCHAR(50) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.FinishedGoodsInventory',N'U') IS NULL
CREATE TABLE bronze.[FinishedGoodsInventory]
(
    [finished_goods_inventory_id] INT NOT NULL,
    [warehouse_id] INT NOT NULL,
    [product_id] INT NOT NULL,
    [quantity_on_hand] DECIMAL(18,2) NOT NULL,
    [quantity_reserved] INT NOT NULL,
    [reorder_point] DECIMAL(18,2) NOT NULL,
    [safety_stock_level] DECIMAL(18,2) NOT NULL,
    [last_updated_at] DATE NULL
);
GO
IF OBJECT_ID(N'bronze.Customers',N'U') IS NULL
CREATE TABLE bronze.[Customers]
(
    [customer_id] INT NOT NULL,
    [customer_code] VARCHAR(30) NOT NULL,
    [customer_name] VARCHAR(100) NOT NULL,
    [customer_type] VARCHAR(50) NOT NULL,
    [email] VARCHAR(120) NULL,
    [phone] VARCHAR(20) NOT NULL,
    [country] VARCHAR(50) NOT NULL,
    [city] VARCHAR(50) NOT NULL,
    [address] VARCHAR(250) NOT NULL,
    [registration_date] DATE NOT NULL,
    [default_discount_percentage] DECIMAL(5,2) NOT NULL,
    [status] VARCHAR(20) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.SalesOrders',N'U') IS NULL
CREATE TABLE bronze.[SalesOrders]
(
    [sales_order_id] INT NOT NULL,
    [sales_order_code] VARCHAR(20) NOT NULL,
    [customer_id] INT NOT NULL,
    [order_date] DATE NOT NULL,
    [required_delivery_date] DATE NOT NULL,
    [payment_method] VARCHAR(30) NOT NULL,
    [tax_percentage] DECIMAL(5,2) NOT NULL,
    [sales_order_status] VARCHAR(30) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.SalesOrderDetails',N'U') IS NULL
CREATE TABLE bronze.[SalesOrderDetails]
(
    [sales_order_detail_id] INT NOT NULL,
    [sales_order_id] INT NOT NULL,
    [product_id] INT NOT NULL,
    [ordered_quantity] DECIMAL(18,2) NOT NULL,
    [line_status] VARCHAR(30) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.CustomerShipments',N'U') IS NULL
CREATE TABLE bronze.[CustomerShipments]
(
    [customer_shipment_id] INT NOT NULL,
    [shipment_code] VARCHAR(20) NOT NULL,
    [sales_order_id] INT NOT NULL,
    [warehouse_id] INT NOT NULL,
    [shipment_date] DATE NOT NULL,
    [expected_delivery_date] DATE NOT NULL,
    [actual_delivery_date] DATE NULL,
    [tracking_number] VARCHAR(50) NOT NULL,
    [shipping_method] VARCHAR(30) NOT NULL,
    [shipping_cost] DECIMAL(18,2) NOT NULL,
    [delivery_address] VARCHAR(300) NOT NULL,
    [shipment_status] VARCHAR(30) NOT NULL,
    [delivery_confirmation] BIT NOT NULL,
    [customer_feedback] VARCHAR(500) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.CustomerShipmentDetails',N'U') IS NULL
CREATE TABLE bronze.[CustomerShipmentDetails]
(
    [customer_shipment_detail_id] INT NOT NULL,
    [customer_shipment_id] INT NOT NULL,
    [sales_order_detail_id] INT NOT NULL,
    [shipped_quantity] DECIMAL(18,2) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.FinishedGoodsInventoryTransactions',N'U') IS NULL
CREATE TABLE bronze.[FinishedGoodsInventoryTransactions]
(
    [finished_inventory_transaction_id] INT NOT NULL,
    [finished_goods_inventory_id] INT NOT NULL,
    [production_id] INT NOT NULL,
    [customer_shipment_detail_id] INT NOT NULL,
    [transaction_type] VARCHAR(40) NOT NULL,
    [quantity] DECIMAL(18,2) NOT NULL,
    [unit_cost] DECIMAL(18,2) NOT NULL,
    [transaction_date] DATE NULL,
    [reference_code] VARCHAR(50) NOT NULL
);
GO
IF OBJECT_ID(N'bronze.Returns',N'U') IS NULL
CREATE TABLE bronze.[Returns]
(
    [return_id] INT NOT NULL,
    [return_code] VARCHAR(20) NOT NULL,
    [customer_shipment_detail_id] INT NOT NULL,
    [return_request_date] DATE NOT NULL,
    [return_received_date] DATE NOT NULL,
    [returned_quantity] DECIMAL(18,2) NOT NULL,
    [return_reason] VARCHAR(120) NOT NULL,
    [product_condition] VARCHAR(50) NOT NULL,
    [return_status] VARCHAR(30) NOT NULL
);
GO


-- FILE: 02_Load_Bronze.sql
USE [ElectronicsSupplyChainDB_v2];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO
CREATE OR ALTER PROCEDURE etl.LoadBronze
    @DataFolder NVARCHAR(3000)
AS
BEGIN
 SET NOCOUNT ON;
 SET XACT_ABORT ON;
 IF @@TRANCOUNT=0 THROW 51000, 'Run etl.RefreshAll; this loader requires its transaction.', 1;
 IF NULLIF(TRIM(@DataFolder),N'') IS NULL THROW 51001, 'Data folder is required.', 1;
 IF RIGHT(@DataFolder,1) NOT IN (N'\',N'/') SET @DataFolder+=N'\';
 DECLARE @sql NVARCHAR(MAX), @path NVARCHAR(4000);
 DELETE FROM bronze.[Returns];
 DELETE FROM bronze.[FinishedGoodsInventoryTransactions];
 DELETE FROM bronze.[CustomerShipmentDetails];
 DELETE FROM bronze.[CustomerShipments];
 DELETE FROM bronze.[SalesOrderDetails];
 DELETE FROM bronze.[SalesOrders];
 DELETE FROM bronze.[Customers];
 DELETE FROM bronze.[FinishedGoodsInventory];
 DELETE FROM bronze.[RawMaterialInventoryTransactions];
 DELETE FROM bronze.[ProductionDetails];
 DELETE FROM bronze.[Production];
 DELETE FROM bronze.[ProductBOM];
 DELETE FROM bronze.[Products];
 DELETE FROM bronze.[RawMaterialInventory];
 DELETE FROM bronze.[Warehouses];
 DELETE FROM bronze.[SupplierPayments];
 DELETE FROM bronze.[SupplierInvoiceDetails];
 DELETE FROM bronze.[SupplierInvoices];
 DELETE FROM bronze.[QualityInspections];
 DELETE FROM bronze.[GoodsReceiptDetails];
 DELETE FROM bronze.[GoodsReceipts];
 DELETE FROM bronze.[SupplierShipmentDetails];
 DELETE FROM bronze.[SupplierShipments];
 DELETE FROM bronze.[PurchaseOrderDetails];
 DELETE FROM bronze.[PurchaseOrders];
 DELETE FROM bronze.[PurchaseRequisitionDetails];
 DELETE FROM bronze.[PurchaseRequisitions];
 DELETE FROM bronze.[SupplierMaterials];
 DELETE FROM bronze.[Suppliers];
 DELETE FROM bronze.[Materials];
 DELETE FROM bronze.[Departments];
 SET @path=@DataFolder+N'Departments.csv';
 SET @sql=N'BULK INSERT bronze.[Departments] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'Materials.csv';
 SET @sql=N'BULK INSERT bronze.[Materials] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'Suppliers.csv';
 SET @sql=N'BULK INSERT bronze.[Suppliers] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'SupplierMaterials.csv';
 SET @sql=N'BULK INSERT bronze.[SupplierMaterials] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'PurchaseRequisitions.csv';
 SET @sql=N'BULK INSERT bronze.[PurchaseRequisitions] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'PurchaseRequisitionDetails.csv';
 SET @sql=N'BULK INSERT bronze.[PurchaseRequisitionDetails] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'PurchaseOrders.csv';
 SET @sql=N'BULK INSERT bronze.[PurchaseOrders] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'PurchaseOrderDetails.csv';
 SET @sql=N'BULK INSERT bronze.[PurchaseOrderDetails] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'SupplierShipments.csv';
 SET @sql=N'BULK INSERT bronze.[SupplierShipments] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'SupplierShipmentDetails.csv';
 SET @sql=N'BULK INSERT bronze.[SupplierShipmentDetails] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'GoodsReceipts.csv';
 SET @sql=N'BULK INSERT bronze.[GoodsReceipts] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'GoodsReceiptDetails.csv';
 SET @sql=N'BULK INSERT bronze.[GoodsReceiptDetails] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'QualityInspections.csv';
 SET @sql=N'BULK INSERT bronze.[QualityInspections] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'SupplierInvoices.csv';
 SET @sql=N'BULK INSERT bronze.[SupplierInvoices] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'SupplierInvoiceDetails.csv';
 SET @sql=N'BULK INSERT bronze.[SupplierInvoiceDetails] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'SupplierPayments.csv';
 SET @sql=N'BULK INSERT bronze.[SupplierPayments] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'Warehouses.csv';
 SET @sql=N'BULK INSERT bronze.[Warehouses] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'RawMaterialInventory.csv';
 SET @sql=N'BULK INSERT bronze.[RawMaterialInventory] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'Products.csv';
 SET @sql=N'BULK INSERT bronze.[Products] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'ProductBOM.csv';
 SET @sql=N'BULK INSERT bronze.[ProductBOM] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'Production.csv';
 SET @sql=N'BULK INSERT bronze.[Production] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'ProductionDetails.csv';
 SET @sql=N'BULK INSERT bronze.[ProductionDetails] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'RawMaterialInventoryTransactions.csv';
 SET @sql=N'BULK INSERT bronze.[RawMaterialInventoryTransactions] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'FinishedGoodsInventory.csv';
 SET @sql=N'BULK INSERT bronze.[FinishedGoodsInventory] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'Customers.csv';
 SET @sql=N'BULK INSERT bronze.[Customers] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'SalesOrders.csv';
 SET @sql=N'BULK INSERT bronze.[SalesOrders] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'SalesOrderDetails.csv';
 SET @sql=N'BULK INSERT bronze.[SalesOrderDetails] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'CustomerShipments.csv';
 SET @sql=N'BULK INSERT bronze.[CustomerShipments] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'CustomerShipmentDetails.csv';
 SET @sql=N'BULK INSERT bronze.[CustomerShipmentDetails] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'FinishedGoodsInventoryTransactions.csv';
 SET @sql=N'BULK INSERT bronze.[FinishedGoodsInventoryTransactions] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
 SET @path=@DataFolder+N'Returns.csv';
 SET @sql=N'BULK INSERT bronze.[Returns] FROM '+N''''+REPLACE(@path,N'''',N'''''')+N''''+N' WITH (FORMAT=''CSV'', FIELDQUOTE=''"'', FIRSTROW=2, FIELDTERMINATOR='','', ROWTERMINATOR=''0x0a'', CODEPAGE=''65001'', KEEPNULLS, MAXERRORS=0, TABLOCK);';
 EXEC sys.sp_executesql @sql;
END;
GO


-- FILE: 03_Create_Silver.sql
USE [ElectronicsSupplyChainDB_v2];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO
-- Non-destructive setup. Re-running does not drop existing tables.
IF OBJECT_ID(N'silver.Departments',N'U') IS NULL
CREATE TABLE silver.[Departments]
(
    [department_id] INT NOT NULL,
    [department_code] VARCHAR(20) NOT NULL,
    [department_name] VARCHAR(100) NOT NULL,
    [department_description] VARCHAR(250) NOT NULL,
    [status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_Departments] PRIMARY KEY ([department_id])
);
GO
IF OBJECT_ID(N'silver.Materials',N'U') IS NULL
CREATE TABLE silver.[Materials]
(
    [material_id] INT NOT NULL,
    [material_code] VARCHAR(30) NOT NULL,
    [material_name] VARCHAR(100) NOT NULL,
    [material_category] VARCHAR(60) NOT NULL,
    [material_type] VARCHAR(50) NOT NULL,
    [uom] VARCHAR(20) NOT NULL,
    [unit_weight] DECIMAL(18,3) NOT NULL,
    [status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_Materials] PRIMARY KEY ([material_id])
);
GO
IF OBJECT_ID(N'silver.Suppliers',N'U') IS NULL
CREATE TABLE silver.[Suppliers]
(
    [supplier_id] INT NOT NULL,
    [supplier_code] VARCHAR(30) NOT NULL,
    [supplier_name] VARCHAR(120) NOT NULL,
    [supplier_type] VARCHAR(50) NOT NULL,
    [supplier_category] VARCHAR(50) NOT NULL,
    [country] VARCHAR(50) NOT NULL,
    [city] VARCHAR(50) NOT NULL,
    [address] VARCHAR(250) NOT NULL,
    [contact_person] VARCHAR(100) NOT NULL,
    [phone] VARCHAR(20) NOT NULL,
    [email] VARCHAR(120) NOT NULL,
    [payment_terms] VARCHAR(50) NOT NULL,
    [status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_Suppliers] PRIMARY KEY ([supplier_id])
);
GO
IF OBJECT_ID(N'silver.SupplierMaterials',N'U') IS NULL
CREATE TABLE silver.[SupplierMaterials]
(
    [supplier_material_id] INT NOT NULL,
    [supplier_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [supplier_material_code] VARCHAR(50) NOT NULL,
    [standard_price] DECIMAL(18,2) NOT NULL,
    [lead_time_days] INT NOT NULL,
    [minimum_order_quantity] DECIMAL(18,2) NOT NULL,
    [preferred_supplier] BIT NOT NULL,
    [status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_SupplierMaterials] PRIMARY KEY ([supplier_material_id]),
    CONSTRAINT [FK_SupplierMaterials_supplier_id] FOREIGN KEY ([supplier_id]) REFERENCES silver.[Suppliers] ([supplier_id]),
    CONSTRAINT [FK_SupplierMaterials_material_id] FOREIGN KEY ([material_id]) REFERENCES silver.[Materials] ([material_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SupplierMaterials') AND name=N'IX_SupplierMaterials_supplier_id')
CREATE INDEX [IX_SupplierMaterials_supplier_id] ON silver.[SupplierMaterials] ([supplier_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SupplierMaterials') AND name=N'IX_SupplierMaterials_material_id')
CREATE INDEX [IX_SupplierMaterials_material_id] ON silver.[SupplierMaterials] ([material_id]);
GO
IF OBJECT_ID(N'silver.PurchaseRequisitions',N'U') IS NULL
CREATE TABLE silver.[PurchaseRequisitions]
(
    [pr_id] INT NOT NULL,
    [pr_code] VARCHAR(20) NOT NULL,
    [department_id] INT NOT NULL,
    [requested_by] VARCHAR(100) NOT NULL,
    [request_date] DATE NOT NULL,
    [order_date] DATE NULL,
    [required_date] DATE NOT NULL,
    [priority] VARCHAR(20) NOT NULL,
    [approval_status] VARCHAR(20) NOT NULL,
    [approved_by] VARCHAR(100) NOT NULL,
    [approval_date] DATE NOT NULL,
    [rejection_reason] VARCHAR(250) NULL,
    [created_date] DATE NULL,
    CONSTRAINT [PK_PurchaseRequisitions] PRIMARY KEY ([pr_id]),
    CONSTRAINT [FK_PurchaseRequisitions_department_id] FOREIGN KEY ([department_id]) REFERENCES silver.[Departments] ([department_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.PurchaseRequisitions') AND name=N'IX_PurchaseRequisitions_department_id')
CREATE INDEX [IX_PurchaseRequisitions_department_id] ON silver.[PurchaseRequisitions] ([department_id]);
GO
IF OBJECT_ID(N'silver.PurchaseRequisitionDetails',N'U') IS NULL
CREATE TABLE silver.[PurchaseRequisitionDetails]
(
    [pr_detail_id] INT NOT NULL,
    [pr_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [requested_quantity] DECIMAL(18,2) NOT NULL,
    [estimated_unit_cost] DECIMAL(18,2) NOT NULL,
    CONSTRAINT [PK_PurchaseRequisitionDetails] PRIMARY KEY ([pr_detail_id]),
    CONSTRAINT [FK_PurchaseRequisitionDetails_pr_id] FOREIGN KEY ([pr_id]) REFERENCES silver.[PurchaseRequisitions] ([pr_id]),
    CONSTRAINT [FK_PurchaseRequisitionDetails_material_id] FOREIGN KEY ([material_id]) REFERENCES silver.[Materials] ([material_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.PurchaseRequisitionDetails') AND name=N'IX_PurchaseRequisitionDetails_pr_id')
CREATE INDEX [IX_PurchaseRequisitionDetails_pr_id] ON silver.[PurchaseRequisitionDetails] ([pr_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.PurchaseRequisitionDetails') AND name=N'IX_PurchaseRequisitionDetails_material_id')
CREATE INDEX [IX_PurchaseRequisitionDetails_material_id] ON silver.[PurchaseRequisitionDetails] ([material_id]);
GO
IF OBJECT_ID(N'silver.PurchaseOrders',N'U') IS NULL
CREATE TABLE silver.[PurchaseOrders]
(
    [po_id] INT NOT NULL,
    [po_code] VARCHAR(20) NOT NULL,
    [supplier_id] INT NOT NULL,
    [pr_id] INT NOT NULL,
    [order_date] DATE NOT NULL,
    [expected_delivery_date] DATE NOT NULL,
    [payment_terms] VARCHAR(50) NOT NULL,
    [status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_PurchaseOrders] PRIMARY KEY ([po_id]),
    CONSTRAINT [FK_PurchaseOrders_supplier_id] FOREIGN KEY ([supplier_id]) REFERENCES silver.[Suppliers] ([supplier_id]),
    CONSTRAINT [FK_PurchaseOrders_pr_id] FOREIGN KEY ([pr_id]) REFERENCES silver.[PurchaseRequisitions] ([pr_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.PurchaseOrders') AND name=N'IX_PurchaseOrders_supplier_id')
CREATE INDEX [IX_PurchaseOrders_supplier_id] ON silver.[PurchaseOrders] ([supplier_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.PurchaseOrders') AND name=N'IX_PurchaseOrders_pr_id')
CREATE INDEX [IX_PurchaseOrders_pr_id] ON silver.[PurchaseOrders] ([pr_id]);
GO
IF OBJECT_ID(N'silver.PurchaseOrderDetails',N'U') IS NULL
CREATE TABLE silver.[PurchaseOrderDetails]
(
    [po_detail_id] INT NOT NULL,
    [po_id] INT NOT NULL,
    [pr_detail_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [ordered_quantity] DECIMAL(18,2) NOT NULL,
    [unit_price] DECIMAL(18,2) NOT NULL,
    [discount_percentage] DECIMAL(5,2) NOT NULL,
    [expected_delivery_date] DATE NOT NULL,
    [total_amount] DECIMAL(18,2) NOT NULL,
    [line_status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_PurchaseOrderDetails] PRIMARY KEY ([po_detail_id]),
    CONSTRAINT [FK_PurchaseOrderDetails_po_id] FOREIGN KEY ([po_id]) REFERENCES silver.[PurchaseOrders] ([po_id]),
    CONSTRAINT [FK_PurchaseOrderDetails_pr_detail_id] FOREIGN KEY ([pr_detail_id]) REFERENCES silver.[PurchaseRequisitionDetails] ([pr_detail_id]),
    CONSTRAINT [FK_PurchaseOrderDetails_material_id] FOREIGN KEY ([material_id]) REFERENCES silver.[Materials] ([material_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.PurchaseOrderDetails') AND name=N'IX_PurchaseOrderDetails_po_id')
CREATE INDEX [IX_PurchaseOrderDetails_po_id] ON silver.[PurchaseOrderDetails] ([po_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.PurchaseOrderDetails') AND name=N'IX_PurchaseOrderDetails_pr_detail_id')
CREATE INDEX [IX_PurchaseOrderDetails_pr_detail_id] ON silver.[PurchaseOrderDetails] ([pr_detail_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.PurchaseOrderDetails') AND name=N'IX_PurchaseOrderDetails_material_id')
CREATE INDEX [IX_PurchaseOrderDetails_material_id] ON silver.[PurchaseOrderDetails] ([material_id]);
GO
IF OBJECT_ID(N'silver.SupplierShipments',N'U') IS NULL
CREATE TABLE silver.[SupplierShipments]
(
    [shipment_id] INT NOT NULL,
    [shipment_code] VARCHAR(20) NOT NULL,
    [po_id] INT NOT NULL,
    [supplier_id] INT NOT NULL,
    [supplier_reference] VARCHAR(50) NOT NULL,
    [ship_date] DATE NOT NULL,
    [expected_arrival_date] DATE NOT NULL,
    [actual_arrival_date] DATE NOT NULL,
    [total_shipment_value] DECIMAL(18,2) NOT NULL,
    [shipping_cost] DECIMAL(18,2) NOT NULL,
    CONSTRAINT [PK_SupplierShipments] PRIMARY KEY ([shipment_id]),
    CONSTRAINT [FK_SupplierShipments_po_id] FOREIGN KEY ([po_id]) REFERENCES silver.[PurchaseOrders] ([po_id]),
    CONSTRAINT [FK_SupplierShipments_supplier_id] FOREIGN KEY ([supplier_id]) REFERENCES silver.[Suppliers] ([supplier_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SupplierShipments') AND name=N'IX_SupplierShipments_po_id')
CREATE INDEX [IX_SupplierShipments_po_id] ON silver.[SupplierShipments] ([po_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SupplierShipments') AND name=N'IX_SupplierShipments_supplier_id')
CREATE INDEX [IX_SupplierShipments_supplier_id] ON silver.[SupplierShipments] ([supplier_id]);
GO
IF OBJECT_ID(N'silver.SupplierShipmentDetails',N'U') IS NULL
CREATE TABLE silver.[SupplierShipmentDetails]
(
    [shipment_detail_id] INT NOT NULL,
    [shipment_id] INT NOT NULL,
    [po_detail_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [received_quantity] DECIMAL(18,2) NOT NULL,
    [accepted_quantity] DECIMAL(18,2) NOT NULL,
    [rejected_quantity] DECIMAL(18,2) NOT NULL,
    CONSTRAINT [PK_SupplierShipmentDetails] PRIMARY KEY ([shipment_detail_id]),
    CONSTRAINT [FK_SupplierShipmentDetails_shipment_id] FOREIGN KEY ([shipment_id]) REFERENCES silver.[SupplierShipments] ([shipment_id]),
    CONSTRAINT [FK_SupplierShipmentDetails_po_detail_id] FOREIGN KEY ([po_detail_id]) REFERENCES silver.[PurchaseOrderDetails] ([po_detail_id]),
    CONSTRAINT [FK_SupplierShipmentDetails_material_id] FOREIGN KEY ([material_id]) REFERENCES silver.[Materials] ([material_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SupplierShipmentDetails') AND name=N'IX_SupplierShipmentDetails_shipment_id')
CREATE INDEX [IX_SupplierShipmentDetails_shipment_id] ON silver.[SupplierShipmentDetails] ([shipment_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SupplierShipmentDetails') AND name=N'IX_SupplierShipmentDetails_po_detail_id')
CREATE INDEX [IX_SupplierShipmentDetails_po_detail_id] ON silver.[SupplierShipmentDetails] ([po_detail_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SupplierShipmentDetails') AND name=N'IX_SupplierShipmentDetails_material_id')
CREATE INDEX [IX_SupplierShipmentDetails_material_id] ON silver.[SupplierShipmentDetails] ([material_id]);
GO
IF OBJECT_ID(N'silver.GoodsReceipts',N'U') IS NULL
CREATE TABLE silver.[GoodsReceipts]
(
    [gr_id] INT NOT NULL,
    [gr_code] VARCHAR(20) NOT NULL,
    [shipment_id] INT NOT NULL,
    [receipt_date] DATE NOT NULL,
    [received_by] VARCHAR(100) NOT NULL,
    [quality_check_status] VARCHAR(20) NOT NULL,
    [total_received_value] DECIMAL(18,2) NOT NULL,
    CONSTRAINT [PK_GoodsReceipts] PRIMARY KEY ([gr_id]),
    CONSTRAINT [FK_GoodsReceipts_shipment_id] FOREIGN KEY ([shipment_id]) REFERENCES silver.[SupplierShipments] ([shipment_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.GoodsReceipts') AND name=N'IX_GoodsReceipts_shipment_id')
CREATE INDEX [IX_GoodsReceipts_shipment_id] ON silver.[GoodsReceipts] ([shipment_id]);
GO
IF OBJECT_ID(N'silver.GoodsReceiptDetails',N'U') IS NULL
CREATE TABLE silver.[GoodsReceiptDetails]
(
    [gr_detail_id] INT NOT NULL,
    [gr_id] INT NOT NULL,
    [shipment_detail_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [received_quantity] DECIMAL(18,2) NOT NULL,
    [accepted_quantity] DECIMAL(18,2) NOT NULL,
    [rejected_quantity] DECIMAL(18,2) NOT NULL,
    [inspection_status] VARCHAR(30) NOT NULL,
    [batch_number] VARCHAR(50) NOT NULL,
    CONSTRAINT [PK_GoodsReceiptDetails] PRIMARY KEY ([gr_detail_id]),
    CONSTRAINT [FK_GoodsReceiptDetails_gr_id] FOREIGN KEY ([gr_id]) REFERENCES silver.[GoodsReceipts] ([gr_id]),
    CONSTRAINT [FK_GoodsReceiptDetails_shipment_detail_id] FOREIGN KEY ([shipment_detail_id]) REFERENCES silver.[SupplierShipmentDetails] ([shipment_detail_id]),
    CONSTRAINT [FK_GoodsReceiptDetails_material_id] FOREIGN KEY ([material_id]) REFERENCES silver.[Materials] ([material_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.GoodsReceiptDetails') AND name=N'IX_GoodsReceiptDetails_gr_id')
CREATE INDEX [IX_GoodsReceiptDetails_gr_id] ON silver.[GoodsReceiptDetails] ([gr_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.GoodsReceiptDetails') AND name=N'IX_GoodsReceiptDetails_shipment_detail_id')
CREATE INDEX [IX_GoodsReceiptDetails_shipment_detail_id] ON silver.[GoodsReceiptDetails] ([shipment_detail_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.GoodsReceiptDetails') AND name=N'IX_GoodsReceiptDetails_material_id')
CREATE INDEX [IX_GoodsReceiptDetails_material_id] ON silver.[GoodsReceiptDetails] ([material_id]);
GO
IF OBJECT_ID(N'silver.QualityInspections',N'U') IS NULL
CREATE TABLE silver.[QualityInspections]
(
    [inspection_id] INT NOT NULL,
    [gr_detail_id] INT NOT NULL,
    [inspection_date] DATE NOT NULL,
    [inspection_type] VARCHAR(50) NOT NULL,
    [inspected_quantity] DECIMAL(18,2) NOT NULL,
    [passed_quantity] DECIMAL(18,2) NOT NULL,
    [inspection_result] VARCHAR(30) NOT NULL,
    [defect_quantity] DECIMAL(18,2) NOT NULL,
    [defect_reason] VARCHAR(250) NOT NULL,
    [corrective_action] VARCHAR(250) NOT NULL,
    [reinspection_required] BIT NOT NULL,
    [status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_QualityInspections] PRIMARY KEY ([inspection_id]),
    CONSTRAINT [FK_QualityInspections_gr_detail_id] FOREIGN KEY ([gr_detail_id]) REFERENCES silver.[GoodsReceiptDetails] ([gr_detail_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.QualityInspections') AND name=N'IX_QualityInspections_gr_detail_id')
CREATE INDEX [IX_QualityInspections_gr_detail_id] ON silver.[QualityInspections] ([gr_detail_id]);
GO
IF OBJECT_ID(N'silver.SupplierInvoices',N'U') IS NULL
CREATE TABLE silver.[SupplierInvoices]
(
    [invoice_id] INT NOT NULL,
    [invoice_number] VARCHAR(30) NOT NULL,
    [shipment_id] INT NOT NULL,
    [supplier_id] INT NOT NULL,
    [invoice_date] DATE NOT NULL,
    [invoice_amount] DECIMAL(18,2) NOT NULL,
    [tax_amount] DECIMAL(18,2) NOT NULL,
    [total_amount] DECIMAL(18,2) NOT NULL,
    [due_date] DATE NOT NULL,
    [payment_terms] VARCHAR(50) NOT NULL,
    [payment_status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_SupplierInvoices] PRIMARY KEY ([invoice_id]),
    CONSTRAINT [FK_SupplierInvoices_shipment_id] FOREIGN KEY ([shipment_id]) REFERENCES silver.[SupplierShipments] ([shipment_id]),
    CONSTRAINT [FK_SupplierInvoices_supplier_id] FOREIGN KEY ([supplier_id]) REFERENCES silver.[Suppliers] ([supplier_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SupplierInvoices') AND name=N'IX_SupplierInvoices_shipment_id')
CREATE INDEX [IX_SupplierInvoices_shipment_id] ON silver.[SupplierInvoices] ([shipment_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SupplierInvoices') AND name=N'IX_SupplierInvoices_supplier_id')
CREATE INDEX [IX_SupplierInvoices_supplier_id] ON silver.[SupplierInvoices] ([supplier_id]);
GO
IF OBJECT_ID(N'silver.SupplierInvoiceDetails',N'U') IS NULL
CREATE TABLE silver.[SupplierInvoiceDetails]
(
    [invoice_detail_id] INT NOT NULL,
    [invoice_id] INT NOT NULL,
    [gr_detail_id] INT NOT NULL,
    [billed_quantity] DECIMAL(18,2) NOT NULL,
    [unit_price] DECIMAL(18,2) NOT NULL,
    [tax_amount] DECIMAL(18,2) NOT NULL,
    [line_amount] DECIMAL(18,2) NOT NULL,
    CONSTRAINT [PK_SupplierInvoiceDetails] PRIMARY KEY ([invoice_detail_id]),
    CONSTRAINT [FK_SupplierInvoiceDetails_invoice_id] FOREIGN KEY ([invoice_id]) REFERENCES silver.[SupplierInvoices] ([invoice_id]),
    CONSTRAINT [FK_SupplierInvoiceDetails_gr_detail_id] FOREIGN KEY ([gr_detail_id]) REFERENCES silver.[GoodsReceiptDetails] ([gr_detail_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SupplierInvoiceDetails') AND name=N'IX_SupplierInvoiceDetails_invoice_id')
CREATE INDEX [IX_SupplierInvoiceDetails_invoice_id] ON silver.[SupplierInvoiceDetails] ([invoice_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SupplierInvoiceDetails') AND name=N'IX_SupplierInvoiceDetails_gr_detail_id')
CREATE INDEX [IX_SupplierInvoiceDetails_gr_detail_id] ON silver.[SupplierInvoiceDetails] ([gr_detail_id]);
GO
IF OBJECT_ID(N'silver.SupplierPayments',N'U') IS NULL
CREATE TABLE silver.[SupplierPayments]
(
    [payment_id] INT NOT NULL,
    [invoice_id] INT NOT NULL,
    [payment_date] DATE NOT NULL,
    [payment_amount] DECIMAL(18,2) NOT NULL,
    [payment_method] VARCHAR(30) NOT NULL,
    [currency] CHAR(3) NOT NULL,
    [transaction_reference] VARCHAR(100) NOT NULL,
    [payment_status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_SupplierPayments] PRIMARY KEY ([payment_id]),
    CONSTRAINT [FK_SupplierPayments_invoice_id] FOREIGN KEY ([invoice_id]) REFERENCES silver.[SupplierInvoices] ([invoice_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SupplierPayments') AND name=N'IX_SupplierPayments_invoice_id')
CREATE INDEX [IX_SupplierPayments_invoice_id] ON silver.[SupplierPayments] ([invoice_id]);
GO
IF OBJECT_ID(N'silver.Warehouses',N'U') IS NULL
CREATE TABLE silver.[Warehouses]
(
    [warehouse_id] INT NOT NULL,
    [warehouse_code] VARCHAR(20) NOT NULL,
    [warehouse_name] VARCHAR(100) NOT NULL,
    [warehouse_type] VARCHAR(50) NOT NULL,
    [country] VARCHAR(50) NOT NULL,
    [city] VARCHAR(50) NOT NULL,
    [location_description] VARCHAR(250) NOT NULL,
    [status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_Warehouses] PRIMARY KEY ([warehouse_id])
);
GO
IF OBJECT_ID(N'silver.RawMaterialInventory',N'U') IS NULL
CREATE TABLE silver.[RawMaterialInventory]
(
    [raw_inventory_id] INT NOT NULL,
    [warehouse_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [quantity_on_hand] DECIMAL(18,2) NOT NULL,
    [quantity_reserved] DECIMAL(18,2) NOT NULL,
    [reorder_point] DECIMAL(18,2) NOT NULL,
    [safety_stock_level] DECIMAL(18,2) NOT NULL,
    [max_inventory_level] DECIMAL(18,2) NOT NULL,
    [unit_cost] DECIMAL(18,2) NOT NULL,
    [last_updated_at] DATE NULL,
    CONSTRAINT [PK_RawMaterialInventory] PRIMARY KEY ([raw_inventory_id]),
    CONSTRAINT [FK_RawMaterialInventory_warehouse_id] FOREIGN KEY ([warehouse_id]) REFERENCES silver.[Warehouses] ([warehouse_id]),
    CONSTRAINT [FK_RawMaterialInventory_material_id] FOREIGN KEY ([material_id]) REFERENCES silver.[Materials] ([material_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.RawMaterialInventory') AND name=N'IX_RawMaterialInventory_warehouse_id')
CREATE INDEX [IX_RawMaterialInventory_warehouse_id] ON silver.[RawMaterialInventory] ([warehouse_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.RawMaterialInventory') AND name=N'IX_RawMaterialInventory_material_id')
CREATE INDEX [IX_RawMaterialInventory_material_id] ON silver.[RawMaterialInventory] ([material_id]);
GO
IF OBJECT_ID(N'silver.Products',N'U') IS NULL
CREATE TABLE silver.[Products]
(
    [product_id] INT NOT NULL,
    [product_code] VARCHAR(30) NOT NULL,
    [product_name] VARCHAR(100) NOT NULL,
    [product_category] VARCHAR(50) NOT NULL,
    [uom] VARCHAR(20) NOT NULL,
    [standard_cost] DECIMAL(18,2) NOT NULL,
    [selling_price] DECIMAL(18,2) NOT NULL,
    [status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_Products] PRIMARY KEY ([product_id])
);
GO
IF OBJECT_ID(N'silver.ProductBOM',N'U') IS NULL
CREATE TABLE silver.[ProductBOM]
(
    [bom_id] INT NOT NULL,
    [product_id] INT NOT NULL,
    [material_id] INT NOT NULL,
    [quantity_required] DECIMAL(18,3) NOT NULL,
    [uom] VARCHAR(20) NOT NULL,
    [status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_ProductBOM] PRIMARY KEY ([bom_id]),
    CONSTRAINT [FK_ProductBOM_product_id] FOREIGN KEY ([product_id]) REFERENCES silver.[Products] ([product_id]),
    CONSTRAINT [FK_ProductBOM_material_id] FOREIGN KEY ([material_id]) REFERENCES silver.[Materials] ([material_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.ProductBOM') AND name=N'IX_ProductBOM_product_id')
CREATE INDEX [IX_ProductBOM_product_id] ON silver.[ProductBOM] ([product_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.ProductBOM') AND name=N'IX_ProductBOM_material_id')
CREATE INDEX [IX_ProductBOM_material_id] ON silver.[ProductBOM] ([material_id]);
GO
IF OBJECT_ID(N'silver.Production',N'U') IS NULL
CREATE TABLE silver.[Production]
(
    [production_id] INT NOT NULL,
    [production_order_code] VARCHAR(30) NOT NULL,
    [product_id] INT NOT NULL,
    [planned_quantity] DECIMAL(18,2) NOT NULL,
    [start_date] DATE NOT NULL,
    [expected_end_date] DATE NOT NULL,
    [actual_end_date] DATE NULL,
    [production_quantity] DECIMAL(18,2) NOT NULL,
    [rejected_quantity] DECIMAL(18,2) NOT NULL,
    [production_status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_Production] PRIMARY KEY ([production_id]),
    CONSTRAINT [FK_Production_product_id] FOREIGN KEY ([product_id]) REFERENCES silver.[Products] ([product_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.Production') AND name=N'IX_Production_product_id')
CREATE INDEX [IX_Production_product_id] ON silver.[Production] ([product_id]);
GO
IF OBJECT_ID(N'silver.ProductionDetails',N'U') IS NULL
CREATE TABLE silver.[ProductionDetails]
(
    [production_detail_id] INT NOT NULL,
    [production_id] INT NOT NULL,
    [bom_id] INT NOT NULL,
    [raw_inventory_id] INT NOT NULL,
    [actual_consumed_quantity] DECIMAL(18,3) NOT NULL,
    [return_quantity] DECIMAL(18,3) NOT NULL,
    [scrap_quantity] DECIMAL(18,3) NOT NULL,
    [unit_cost] DECIMAL(18,2) NOT NULL,
    [total_material_cost] DECIMAL(18,2) NOT NULL,
    CONSTRAINT [PK_ProductionDetails] PRIMARY KEY ([production_detail_id]),
    CONSTRAINT [FK_ProductionDetails_production_id] FOREIGN KEY ([production_id]) REFERENCES silver.[Production] ([production_id]),
    CONSTRAINT [FK_ProductionDetails_bom_id] FOREIGN KEY ([bom_id]) REFERENCES silver.[ProductBOM] ([bom_id]),
    CONSTRAINT [FK_ProductionDetails_raw_inventory_id] FOREIGN KEY ([raw_inventory_id]) REFERENCES silver.[RawMaterialInventory] ([raw_inventory_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.ProductionDetails') AND name=N'IX_ProductionDetails_production_id')
CREATE INDEX [IX_ProductionDetails_production_id] ON silver.[ProductionDetails] ([production_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.ProductionDetails') AND name=N'IX_ProductionDetails_bom_id')
CREATE INDEX [IX_ProductionDetails_bom_id] ON silver.[ProductionDetails] ([bom_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.ProductionDetails') AND name=N'IX_ProductionDetails_raw_inventory_id')
CREATE INDEX [IX_ProductionDetails_raw_inventory_id] ON silver.[ProductionDetails] ([raw_inventory_id]);
GO
IF OBJECT_ID(N'silver.RawMaterialInventoryTransactions',N'U') IS NULL
CREATE TABLE silver.[RawMaterialInventoryTransactions]
(
    [raw_transaction_id] INT NOT NULL,
    [raw_inventory_id] INT NOT NULL,
    [production_id] INT NOT NULL,
    [inspection_id] INT NOT NULL,
    [transaction_type] VARCHAR(40) NOT NULL,
    [quantity] DECIMAL(18,3) NOT NULL,
    [unit_cost] DECIMAL(18,2) NOT NULL,
    [transaction_date] DATE NULL,
    [reference_code] VARCHAR(50) NOT NULL,
    CONSTRAINT [PK_RawMaterialInventoryTransactions] PRIMARY KEY ([raw_transaction_id]),
    CONSTRAINT [FK_RawMaterialInventoryTransactions_raw_inventory_id] FOREIGN KEY ([raw_inventory_id]) REFERENCES silver.[RawMaterialInventory] ([raw_inventory_id]),
    CONSTRAINT [FK_RawMaterialInventoryTransactions_production_id] FOREIGN KEY ([production_id]) REFERENCES silver.[Production] ([production_id]),
    CONSTRAINT [FK_RawMaterialInventoryTransactions_inspection_id] FOREIGN KEY ([inspection_id]) REFERENCES silver.[QualityInspections] ([inspection_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.RawMaterialInventoryTransactions') AND name=N'IX_RawMaterialInventoryTransactions_raw_inventory_id')
CREATE INDEX [IX_RawMaterialInventoryTransactions_raw_inventory_id] ON silver.[RawMaterialInventoryTransactions] ([raw_inventory_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.RawMaterialInventoryTransactions') AND name=N'IX_RawMaterialInventoryTransactions_production_id')
CREATE INDEX [IX_RawMaterialInventoryTransactions_production_id] ON silver.[RawMaterialInventoryTransactions] ([production_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.RawMaterialInventoryTransactions') AND name=N'IX_RawMaterialInventoryTransactions_inspection_id')
CREATE INDEX [IX_RawMaterialInventoryTransactions_inspection_id] ON silver.[RawMaterialInventoryTransactions] ([inspection_id]);
GO
IF OBJECT_ID(N'silver.FinishedGoodsInventory',N'U') IS NULL
CREATE TABLE silver.[FinishedGoodsInventory]
(
    [finished_goods_inventory_id] INT NOT NULL,
    [warehouse_id] INT NOT NULL,
    [product_id] INT NOT NULL,
    [quantity_on_hand] DECIMAL(18,2) NOT NULL,
    [quantity_reserved] INT NOT NULL,
    [reorder_point] DECIMAL(18,2) NOT NULL,
    [safety_stock_level] DECIMAL(18,2) NOT NULL,
    [last_updated_at] DATE NULL,
    CONSTRAINT [PK_FinishedGoodsInventory] PRIMARY KEY ([finished_goods_inventory_id]),
    CONSTRAINT [FK_FinishedGoodsInventory_warehouse_id] FOREIGN KEY ([warehouse_id]) REFERENCES silver.[Warehouses] ([warehouse_id]),
    CONSTRAINT [FK_FinishedGoodsInventory_product_id] FOREIGN KEY ([product_id]) REFERENCES silver.[Products] ([product_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.FinishedGoodsInventory') AND name=N'IX_FinishedGoodsInventory_warehouse_id')
CREATE INDEX [IX_FinishedGoodsInventory_warehouse_id] ON silver.[FinishedGoodsInventory] ([warehouse_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.FinishedGoodsInventory') AND name=N'IX_FinishedGoodsInventory_product_id')
CREATE INDEX [IX_FinishedGoodsInventory_product_id] ON silver.[FinishedGoodsInventory] ([product_id]);
GO
IF OBJECT_ID(N'silver.Customers',N'U') IS NULL
CREATE TABLE silver.[Customers]
(
    [customer_id] INT NOT NULL,
    [customer_code] VARCHAR(30) NOT NULL,
    [customer_name] VARCHAR(100) NOT NULL,
    [customer_type] VARCHAR(50) NOT NULL,
    [email] VARCHAR(120) NULL,
    [phone] VARCHAR(20) NOT NULL,
    [country] VARCHAR(50) NOT NULL,
    [city] VARCHAR(50) NOT NULL,
    [address] VARCHAR(250) NOT NULL,
    [registration_date] DATE NOT NULL,
    [default_discount_percentage] DECIMAL(5,2) NOT NULL,
    [status] VARCHAR(20) NOT NULL,
    CONSTRAINT [PK_Customers] PRIMARY KEY ([customer_id])
);
GO
IF OBJECT_ID(N'silver.SalesOrders',N'U') IS NULL
CREATE TABLE silver.[SalesOrders]
(
    [sales_order_id] INT NOT NULL,
    [sales_order_code] VARCHAR(20) NOT NULL,
    [customer_id] INT NOT NULL,
    [order_date] DATE NOT NULL,
    [required_delivery_date] DATE NOT NULL,
    [payment_method] VARCHAR(30) NOT NULL,
    [tax_percentage] DECIMAL(5,2) NOT NULL,
    [sales_order_status] VARCHAR(30) NOT NULL,
    CONSTRAINT [PK_SalesOrders] PRIMARY KEY ([sales_order_id]),
    CONSTRAINT [FK_SalesOrders_customer_id] FOREIGN KEY ([customer_id]) REFERENCES silver.[Customers] ([customer_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SalesOrders') AND name=N'IX_SalesOrders_customer_id')
CREATE INDEX [IX_SalesOrders_customer_id] ON silver.[SalesOrders] ([customer_id]);
GO
IF OBJECT_ID(N'silver.SalesOrderDetails',N'U') IS NULL
CREATE TABLE silver.[SalesOrderDetails]
(
    [sales_order_detail_id] INT NOT NULL,
    [sales_order_id] INT NOT NULL,
    [product_id] INT NOT NULL,
    [ordered_quantity] DECIMAL(18,2) NOT NULL,
    [line_status] VARCHAR(30) NOT NULL,
    CONSTRAINT [PK_SalesOrderDetails] PRIMARY KEY ([sales_order_detail_id]),
    CONSTRAINT [FK_SalesOrderDetails_sales_order_id] FOREIGN KEY ([sales_order_id]) REFERENCES silver.[SalesOrders] ([sales_order_id]),
    CONSTRAINT [FK_SalesOrderDetails_product_id] FOREIGN KEY ([product_id]) REFERENCES silver.[Products] ([product_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SalesOrderDetails') AND name=N'IX_SalesOrderDetails_sales_order_id')
CREATE INDEX [IX_SalesOrderDetails_sales_order_id] ON silver.[SalesOrderDetails] ([sales_order_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.SalesOrderDetails') AND name=N'IX_SalesOrderDetails_product_id')
CREATE INDEX [IX_SalesOrderDetails_product_id] ON silver.[SalesOrderDetails] ([product_id]);
GO
IF OBJECT_ID(N'silver.CustomerShipments',N'U') IS NULL
CREATE TABLE silver.[CustomerShipments]
(
    [customer_shipment_id] INT NOT NULL,
    [shipment_code] VARCHAR(20) NOT NULL,
    [sales_order_id] INT NOT NULL,
    [warehouse_id] INT NOT NULL,
    [shipment_date] DATE NOT NULL,
    [expected_delivery_date] DATE NOT NULL,
    [actual_delivery_date] DATE NULL,
    [tracking_number] VARCHAR(50) NOT NULL,
    [shipping_method] VARCHAR(30) NOT NULL,
    [shipping_cost] DECIMAL(18,2) NOT NULL,
    [delivery_address] VARCHAR(300) NOT NULL,
    [shipment_status] VARCHAR(30) NOT NULL,
    [delivery_confirmation] BIT NOT NULL,
    [customer_feedback] VARCHAR(500) NOT NULL,
    CONSTRAINT [PK_CustomerShipments] PRIMARY KEY ([customer_shipment_id]),
    CONSTRAINT [FK_CustomerShipments_sales_order_id] FOREIGN KEY ([sales_order_id]) REFERENCES silver.[SalesOrders] ([sales_order_id]),
    CONSTRAINT [FK_CustomerShipments_warehouse_id] FOREIGN KEY ([warehouse_id]) REFERENCES silver.[Warehouses] ([warehouse_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.CustomerShipments') AND name=N'IX_CustomerShipments_sales_order_id')
CREATE INDEX [IX_CustomerShipments_sales_order_id] ON silver.[CustomerShipments] ([sales_order_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.CustomerShipments') AND name=N'IX_CustomerShipments_warehouse_id')
CREATE INDEX [IX_CustomerShipments_warehouse_id] ON silver.[CustomerShipments] ([warehouse_id]);
GO
IF OBJECT_ID(N'silver.CustomerShipmentDetails',N'U') IS NULL
CREATE TABLE silver.[CustomerShipmentDetails]
(
    [customer_shipment_detail_id] INT NOT NULL,
    [customer_shipment_id] INT NOT NULL,
    [sales_order_detail_id] INT NOT NULL,
    [shipped_quantity] DECIMAL(18,2) NOT NULL,
    CONSTRAINT [PK_CustomerShipmentDetails] PRIMARY KEY ([customer_shipment_detail_id]),
    CONSTRAINT [FK_CustomerShipmentDetails_customer_shipment_id] FOREIGN KEY ([customer_shipment_id]) REFERENCES silver.[CustomerShipments] ([customer_shipment_id]),
    CONSTRAINT [FK_CustomerShipmentDetails_sales_order_detail_id] FOREIGN KEY ([sales_order_detail_id]) REFERENCES silver.[SalesOrderDetails] ([sales_order_detail_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.CustomerShipmentDetails') AND name=N'IX_CustomerShipmentDetails_customer_shipment_id')
CREATE INDEX [IX_CustomerShipmentDetails_customer_shipment_id] ON silver.[CustomerShipmentDetails] ([customer_shipment_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.CustomerShipmentDetails') AND name=N'IX_CustomerShipmentDetails_sales_order_detail_id')
CREATE INDEX [IX_CustomerShipmentDetails_sales_order_detail_id] ON silver.[CustomerShipmentDetails] ([sales_order_detail_id]);
GO
IF OBJECT_ID(N'silver.FinishedGoodsInventoryTransactions',N'U') IS NULL
CREATE TABLE silver.[FinishedGoodsInventoryTransactions]
(
    [finished_inventory_transaction_id] INT NOT NULL,
    [finished_goods_inventory_id] INT NOT NULL,
    [production_id] INT NOT NULL,
    [customer_shipment_detail_id] INT NOT NULL,
    [transaction_type] VARCHAR(40) NOT NULL,
    [quantity] DECIMAL(18,2) NOT NULL,
    [unit_cost] DECIMAL(18,2) NOT NULL,
    [transaction_date] DATE NULL,
    [reference_code] VARCHAR(50) NOT NULL,
    CONSTRAINT [PK_FinishedGoodsInventoryTransactions] PRIMARY KEY ([finished_inventory_transaction_id]),
    CONSTRAINT [FK_FinishedGoodsInventoryTransactions_finished_goods_inventory_id] FOREIGN KEY ([finished_goods_inventory_id]) REFERENCES silver.[FinishedGoodsInventory] ([finished_goods_inventory_id]),
    CONSTRAINT [FK_FinishedGoodsInventoryTransactions_production_id] FOREIGN KEY ([production_id]) REFERENCES silver.[Production] ([production_id]),
    CONSTRAINT [FK_FinishedGoodsInventoryTransactions_customer_shipment_detail_id] FOREIGN KEY ([customer_shipment_detail_id]) REFERENCES silver.[CustomerShipmentDetails] ([customer_shipment_detail_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.FinishedGoodsInventoryTransactions') AND name=N'IX_FinishedGoodsInventoryTransactions_finished_goods_inventory_id')
CREATE INDEX [IX_FinishedGoodsInventoryTransactions_finished_goods_inventory_id] ON silver.[FinishedGoodsInventoryTransactions] ([finished_goods_inventory_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.FinishedGoodsInventoryTransactions') AND name=N'IX_FinishedGoodsInventoryTransactions_production_id')
CREATE INDEX [IX_FinishedGoodsInventoryTransactions_production_id] ON silver.[FinishedGoodsInventoryTransactions] ([production_id]);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.FinishedGoodsInventoryTransactions') AND name=N'IX_FinishedGoodsInventoryTransactions_customer_shipment_detail_id')
CREATE INDEX [IX_FinishedGoodsInventoryTransactions_customer_shipment_detail_id] ON silver.[FinishedGoodsInventoryTransactions] ([customer_shipment_detail_id]);
GO
IF OBJECT_ID(N'silver.Returns',N'U') IS NULL
CREATE TABLE silver.[Returns]
(
    [return_id] INT NOT NULL,
    [return_code] VARCHAR(20) NOT NULL,
    [customer_shipment_detail_id] INT NOT NULL,
    [return_request_date] DATE NOT NULL,
    [return_received_date] DATE NOT NULL,
    [returned_quantity] DECIMAL(18,2) NOT NULL,
    [return_reason] VARCHAR(120) NOT NULL,
    [product_condition] VARCHAR(50) NOT NULL,
    [return_status] VARCHAR(30) NOT NULL,
    CONSTRAINT [PK_Returns] PRIMARY KEY ([return_id]),
    CONSTRAINT [FK_Returns_customer_shipment_detail_id] FOREIGN KEY ([customer_shipment_detail_id]) REFERENCES silver.[CustomerShipmentDetails] ([customer_shipment_detail_id])
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'silver.Returns') AND name=N'IX_Returns_customer_shipment_detail_id')
CREATE INDEX [IX_Returns_customer_shipment_detail_id] ON silver.[Returns] ([customer_shipment_detail_id]);
GO


-- FILE: 04_Load_Silver.sql
USE [ElectronicsSupplyChainDB_v2];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO
CREATE OR ALTER FUNCTION etl.CleanText(@value VARCHAR(4000))
RETURNS VARCHAR(4000)
AS
BEGIN
 SET @value=TRIM(REPLACE(REPLACE(REPLACE(@value,CHAR(13),' '),CHAR(10),' '),CHAR(9),' '));
 WHILE CHARINDEX('  ',@value)>0 SET @value=REPLACE(@value,'  ',' ');
 RETURN NULLIF(@value,'');
END;
GO
IF OBJECT_ID(N'etl.TextMap',N'U') IS NULL
CREATE TABLE etl.TextMap
(
 domain VARCHAR(80) NOT NULL,
 normalized_value VARCHAR(250) NOT NULL,
 canonical_value VARCHAR(250) NOT NULL,
 CONSTRAINT PK_TextMap PRIMARY KEY(domain,normalized_value)
);
GO
-- Existing user-edited dictionary values are preserved on reinstall.
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'approval_status' AND normalized_value=N'approved')
 INSERT etl.TextMap VALUES (N'approval_status',N'approved',N'Approved');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'approval_status' AND normalized_value=N'rejected')
 INSERT etl.TextMap VALUES (N'approval_status',N'rejected',N'Rejected');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'al sharqia')
 INSERT etl.TextMap VALUES (N'city',N'al sharqia',N'Al Sharqia');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'alexandria')
 INSERT etl.TextMap VALUES (N'city',N'alexandria',N'Alexandria');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'assiut')
 INSERT etl.TextMap VALUES (N'city',N'assiut',N'Assiut');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'aswan')
 INSERT etl.TextMap VALUES (N'city',N'aswan',N'Aswan');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'beheira')
 INSERT etl.TextMap VALUES (N'city',N'beheira',N'Beheira');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'beni suef')
 INSERT etl.TextMap VALUES (N'city',N'beni suef',N'Beni Suef');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'cairo')
 INSERT etl.TextMap VALUES (N'city',N'cairo',N'Cairo');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'dakahlia')
 INSERT etl.TextMap VALUES (N'city',N'dakahlia',N'Dakahlia');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'damietta')
 INSERT etl.TextMap VALUES (N'city',N'damietta',N'Damietta');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'fayoum')
 INSERT etl.TextMap VALUES (N'city',N'fayoum',N'Fayoum');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'gharbia')
 INSERT etl.TextMap VALUES (N'city',N'gharbia',N'Gharbia');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'giza')
 INSERT etl.TextMap VALUES (N'city',N'giza',N'Giza');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'ismailia')
 INSERT etl.TextMap VALUES (N'city',N'ismailia',N'Ismailia');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'kafr el sheikh')
 INSERT etl.TextMap VALUES (N'city',N'kafr el sheikh',N'Kafr El Sheikh');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'luxor')
 INSERT etl.TextMap VALUES (N'city',N'luxor',N'Luxor');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'minya')
 INSERT etl.TextMap VALUES (N'city',N'minya',N'Minya');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'monufia')
 INSERT etl.TextMap VALUES (N'city',N'monufia',N'Monufia');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'north sinai')
 INSERT etl.TextMap VALUES (N'city',N'north sinai',N'North Sinai');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'port said')
 INSERT etl.TextMap VALUES (N'city',N'port said',N'Port Said');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'qalyubia')
 INSERT etl.TextMap VALUES (N'city',N'qalyubia',N'Qalyubia');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'qena')
 INSERT etl.TextMap VALUES (N'city',N'qena',N'Qena');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'red sea')
 INSERT etl.TextMap VALUES (N'city',N'red sea',N'Red Sea');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'sohag')
 INSERT etl.TextMap VALUES (N'city',N'sohag',N'Sohag');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'city' AND normalized_value=N'suez')
 INSERT etl.TextMap VALUES (N'city',N'suez',N'Suez');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'country' AND normalized_value=N'egypt')
 INSERT etl.TextMap VALUES (N'country',N'egypt',N'Egypt');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'customer_type' AND normalized_value=N'corporate customer')
 INSERT etl.TextMap VALUES (N'customer_type',N'corporate customer',N'Corporate Customer');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'customer_type' AND normalized_value=N'distributor')
 INSERT etl.TextMap VALUES (N'customer_type',N'distributor',N'Distributor');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'customer_type' AND normalized_value=N'e-commerce retailer')
 INSERT etl.TextMap VALUES (N'customer_type',N'e-commerce retailer',N'E-commerce Retailer');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'customer_type' AND normalized_value=N'regional distributor')
 INSERT etl.TextMap VALUES (N'customer_type',N'regional distributor',N'Regional Distributor');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'customer_type' AND normalized_value=N'reseller')
 INSERT etl.TextMap VALUES (N'customer_type',N'reseller',N'Reseller');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'customer_type' AND normalized_value=N'retail chain')
 INSERT etl.TextMap VALUES (N'customer_type',N'retail chain',N'Retail Chain');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'defect_reason' AND normalized_value=N'damaged connector')
 INSERT etl.TextMap VALUES (N'defect_reason',N'damaged connector',N'Damaged connector');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'defect_reason' AND normalized_value=N'electrical test failure')
 INSERT etl.TextMap VALUES (N'defect_reason',N'electrical test failure',N'Electrical test failure');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'defect_reason' AND normalized_value=N'no defect')
 INSERT etl.TextMap VALUES (N'defect_reason',N'no defect',N'No Defect');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'defect_reason' AND normalized_value=N'packaging damage')
 INSERT etl.TextMap VALUES (N'defect_reason',N'packaging damage',N'Packaging damage');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'defect_reason' AND normalized_value=N'specification deviation')
 INSERT etl.TextMap VALUES (N'defect_reason',N'specification deviation',N'Specification deviation');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'defect_reason' AND normalized_value=N'surface defect')
 INSERT etl.TextMap VALUES (N'defect_reason',N'surface defect',N'Surface defect');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'inspection_result' AND normalized_value=N'partial acceptance')
 INSERT etl.TextMap VALUES (N'inspection_result',N'partial acceptance',N'Partial Acceptance');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'inspection_result' AND normalized_value=N'passed')
 INSERT etl.TextMap VALUES (N'inspection_result',N'passed',N'Passed');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'inspection_status' AND normalized_value=N'accepted')
 INSERT etl.TextMap VALUES (N'inspection_status',N'accepted',N'Accepted');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'inspection_status' AND normalized_value=N'partially accepted')
 INSERT etl.TextMap VALUES (N'inspection_status',N'partially accepted',N'Partially Accepted');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'inspection_type' AND normalized_value=N'incoming material inspection')
 INSERT etl.TextMap VALUES (N'inspection_type',N'incoming material inspection',N'Incoming Material Inspection');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'line_status' AND normalized_value=N'closed')
 INSERT etl.TextMap VALUES (N'line_status',N'closed',N'Closed');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'line_status' AND normalized_value=N'fulfilled')
 INSERT etl.TextMap VALUES (N'line_status',N'fulfilled',N'Fulfilled');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'line_status' AND normalized_value=N'partially fulfilled')
 INSERT etl.TextMap VALUES (N'line_status',N'partially fulfilled',N'Partially Fulfilled');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_category' AND normalized_value=N'battery and power')
 INSERT etl.TextMap VALUES (N'material_category',N'battery and power',N'Battery and Power');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_category' AND normalized_value=N'camera audio and sensors')
 INSERT etl.TextMap VALUES (N'material_category',N'camera audio and sensors',N'Camera Audio and Sensors');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_category' AND normalized_value=N'display')
 INSERT etl.TextMap VALUES (N'material_category',N'display',N'Display');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_category' AND normalized_value=N'enclosure and mechanical')
 INSERT etl.TextMap VALUES (N'material_category',N'enclosure and mechanical',N'Enclosure and Mechanical');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_category' AND normalized_value=N'memory and storage')
 INSERT etl.TextMap VALUES (N'material_category',N'memory and storage',N'Memory and Storage');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_category' AND normalized_value=N'packaging and accessories')
 INSERT etl.TextMap VALUES (N'material_category',N'packaging and accessories',N'Packaging and Accessories');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_category' AND normalized_value=N'pcb and connectivity')
 INSERT etl.TextMap VALUES (N'material_category',N'pcb and connectivity',N'PCB and Connectivity');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_category' AND normalized_value=N'processing')
 INSERT etl.TextMap VALUES (N'material_category',N'processing',N'Processing');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_type' AND normalized_value=N'assembly component')
 INSERT etl.TextMap VALUES (N'material_type',N'assembly component',N'Assembly Component');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_type' AND normalized_value=N'display module')
 INSERT etl.TextMap VALUES (N'material_type',N'display module',N'Display Module');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_type' AND normalized_value=N'electronic component')
 INSERT etl.TextMap VALUES (N'material_type',N'electronic component',N'Electronic Component');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_type' AND normalized_value=N'functional module')
 INSERT etl.TextMap VALUES (N'material_type',N'functional module',N'Functional Module');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_type' AND normalized_value=N'mechanical component')
 INSERT etl.TextMap VALUES (N'material_type',N'mechanical component',N'Mechanical Component');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_type' AND normalized_value=N'packaging material')
 INSERT etl.TextMap VALUES (N'material_type',N'packaging material',N'Packaging Material');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'material_type' AND normalized_value=N'power component')
 INSERT etl.TextMap VALUES (N'material_type',N'power component',N'Power Component');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'payment_method' AND normalized_value=N'bank transfer')
 INSERT etl.TextMap VALUES (N'payment_method',N'bank transfer',N'Bank Transfer');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'payment_method' AND normalized_value=N'cheque')
 INSERT etl.TextMap VALUES (N'payment_method',N'cheque',N'Cheque');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'payment_method' AND normalized_value=N'credit terms')
 INSERT etl.TextMap VALUES (N'payment_method',N'credit terms',N'Credit Terms');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'payment_method' AND normalized_value=N'electronic payment')
 INSERT etl.TextMap VALUES (N'payment_method',N'electronic payment',N'Electronic Payment');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'payment_method' AND normalized_value=N'electronic transfer')
 INSERT etl.TextMap VALUES (N'payment_method',N'electronic transfer',N'Electronic Transfer');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'payment_status' AND normalized_value=N'completed')
 INSERT etl.TextMap VALUES (N'payment_status',N'completed',N'Completed');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'payment_status' AND normalized_value=N'paid')
 INSERT etl.TextMap VALUES (N'payment_status',N'paid',N'Paid');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'payment_terms' AND normalized_value=N'30% advance - 70% net 30')
 INSERT etl.TextMap VALUES (N'payment_terms',N'30% advance - 70% net 30',N'30% Advance - 70% Net 30');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'payment_terms' AND normalized_value=N'net 30')
 INSERT etl.TextMap VALUES (N'payment_terms',N'net 30',N'Net 30');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'payment_terms' AND normalized_value=N'net 45')
 INSERT etl.TextMap VALUES (N'payment_terms',N'net 45',N'Net 45');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'priority' AND normalized_value=N'high')
 INSERT etl.TextMap VALUES (N'priority',N'high',N'High');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'priority' AND normalized_value=N'normal')
 INSERT etl.TextMap VALUES (N'priority',N'normal',N'Normal');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'priority' AND normalized_value=N'urgent')
 INSERT etl.TextMap VALUES (N'priority',N'urgent',N'Urgent');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'product_category' AND normalized_value=N'earbuds')
 INSERT etl.TextMap VALUES (N'product_category',N'earbuds',N'Earbuds');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'product_category' AND normalized_value=N'laptop')
 INSERT etl.TextMap VALUES (N'product_category',N'laptop',N'Laptop');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'product_category' AND normalized_value=N'smartphone')
 INSERT etl.TextMap VALUES (N'product_category',N'smartphone',N'Smartphone');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'product_category' AND normalized_value=N'smartwatch')
 INSERT etl.TextMap VALUES (N'product_category',N'smartwatch',N'Smartwatch');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'product_condition' AND normalized_value=N'damaged')
 INSERT etl.TextMap VALUES (N'product_condition',N'damaged',N'Damaged');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'product_condition' AND normalized_value=N'defective')
 INSERT etl.TextMap VALUES (N'product_condition',N'defective',N'Defective');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'product_condition' AND normalized_value=N'good')
 INSERT etl.TextMap VALUES (N'product_condition',N'good',N'Good');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'product_condition' AND normalized_value=N'not working')
 INSERT etl.TextMap VALUES (N'product_condition',N'not working',N'Not Working');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'product_condition' AND normalized_value=N'unopened')
 INSERT etl.TextMap VALUES (N'product_condition',N'unopened',N'Unopened');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'production_status' AND normalized_value=N'completed')
 INSERT etl.TextMap VALUES (N'production_status',N'completed',N'Completed');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'production_status' AND normalized_value=N'in progress')
 INSERT etl.TextMap VALUES (N'production_status',N'in progress',N'In Progress');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'quality_check_status' AND normalized_value=N'completed')
 INSERT etl.TextMap VALUES (N'quality_check_status',N'completed',N'Completed');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'return_reason' AND normalized_value=N'customer changed purchase plan')
 INSERT etl.TextMap VALUES (N'return_reason',N'customer changed purchase plan',N'Customer changed purchase plan');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'return_reason' AND normalized_value=N'customer ordered excess quantity')
 INSERT etl.TextMap VALUES (N'return_reason',N'customer ordered excess quantity',N'Customer ordered excess quantity');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'return_reason' AND normalized_value=N'device did not power on')
 INSERT etl.TextMap VALUES (N'return_reason',N'device did not power on',N'Device did not power on');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'return_reason' AND normalized_value=N'product performance defect')
 INSERT etl.TextMap VALUES (N'return_reason',N'product performance defect',N'Product performance defect');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'return_reason' AND normalized_value=N'transit or packaging damage')
 INSERT etl.TextMap VALUES (N'return_reason',N'transit or packaging damage',N'Transit or packaging damage');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'return_status' AND normalized_value=N'completed')
 INSERT etl.TextMap VALUES (N'return_status',N'completed',N'Completed');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'sales_order_status' AND normalized_value=N'completed')
 INSERT etl.TextMap VALUES (N'sales_order_status',N'completed',N'Completed');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'sales_order_status' AND normalized_value=N'partially fulfilled')
 INSERT etl.TextMap VALUES (N'sales_order_status',N'partially fulfilled',N'Partially Fulfilled');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'sales_order_status' AND normalized_value=N'shipped')
 INSERT etl.TextMap VALUES (N'sales_order_status',N'shipped',N'Shipped');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'shipment_status' AND normalized_value=N'delayed')
 INSERT etl.TextMap VALUES (N'shipment_status',N'delayed',N'Delayed');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'shipment_status' AND normalized_value=N'delivered')
 INSERT etl.TextMap VALUES (N'shipment_status',N'delivered',N'Delivered');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'shipment_status' AND normalized_value=N'delivered late')
 INSERT etl.TextMap VALUES (N'shipment_status',N'delivered late',N'Delivered Late');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'shipment_status' AND normalized_value=N'delivery exception')
 INSERT etl.TextMap VALUES (N'shipment_status',N'delivery exception',N'Delivery Exception');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'shipment_status' AND normalized_value=N'in transit')
 INSERT etl.TextMap VALUES (N'shipment_status',N'in transit',N'In Transit');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'shipping_method' AND normalized_value=N'dedicated truck')
 INSERT etl.TextMap VALUES (N'shipping_method',N'dedicated truck',N'Dedicated Truck');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'shipping_method' AND normalized_value=N'domestic courier')
 INSERT etl.TextMap VALUES (N'shipping_method',N'domestic courier',N'Domestic Courier');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'status' AND normalized_value=N'active')
 INSERT etl.TextMap VALUES (N'status',N'active',N'Active');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'status' AND normalized_value=N'closed')
 INSERT etl.TextMap VALUES (N'status',N'closed',N'Closed');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'status' AND normalized_value=N'completed')
 INSERT etl.TextMap VALUES (N'status',N'completed',N'Completed');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'status' AND normalized_value=N'inactive')
 INSERT etl.TextMap VALUES (N'status',N'inactive',N'Inactive');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'supplier_category' AND normalized_value=N'industrial wholesaler')
 INSERT etl.TextMap VALUES (N'supplier_category',N'industrial wholesaler',N'Industrial Wholesaler');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'supplier_category' AND normalized_value=N'local distributor')
 INSERT etl.TextMap VALUES (N'supplier_category',N'local distributor',N'Local Distributor');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'supplier_category' AND normalized_value=N'local manufacturer')
 INSERT etl.TextMap VALUES (N'supplier_category',N'local manufacturer',N'Local Manufacturer');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'supplier_type' AND normalized_value=N'component supplier')
 INSERT etl.TextMap VALUES (N'supplier_type',N'component supplier',N'Component Supplier');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'supplier_type' AND normalized_value=N'materials supplier')
 INSERT etl.TextMap VALUES (N'supplier_type',N'materials supplier',N'Materials Supplier');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'supplier_type' AND normalized_value=N'packaging supplier')
 INSERT etl.TextMap VALUES (N'supplier_type',N'packaging supplier',N'Packaging Supplier');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'transaction_type' AND normalized_value=N'customer return')
 INSERT etl.TextMap VALUES (N'transaction_type',N'customer return',N'Customer Return');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'transaction_type' AND normalized_value=N'customer shipment')
 INSERT etl.TextMap VALUES (N'transaction_type',N'customer shipment',N'Customer Shipment');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'transaction_type' AND normalized_value=N'cycle count adjustment in')
 INSERT etl.TextMap VALUES (N'transaction_type',N'cycle count adjustment in',N'Cycle Count Adjustment In');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'transaction_type' AND normalized_value=N'opening balance')
 INSERT etl.TextMap VALUES (N'transaction_type',N'opening balance',N'Opening Balance');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'transaction_type' AND normalized_value=N'production issue')
 INSERT etl.TextMap VALUES (N'transaction_type',N'production issue',N'Production Issue');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'transaction_type' AND normalized_value=N'production receipt')
 INSERT etl.TextMap VALUES (N'transaction_type',N'production receipt',N'Production Receipt');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'transaction_type' AND normalized_value=N'quality receipt')
 INSERT etl.TextMap VALUES (N'transaction_type',N'quality receipt',N'Quality Receipt');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'transaction_type' AND normalized_value=N'warehouse transfer in')
 INSERT etl.TextMap VALUES (N'transaction_type',N'warehouse transfer in',N'Warehouse Transfer In');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'transaction_type' AND normalized_value=N'warehouse transfer out')
 INSERT etl.TextMap VALUES (N'transaction_type',N'warehouse transfer out',N'Warehouse Transfer Out');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'uom' AND normalized_value=N'piece')
 INSERT etl.TextMap VALUES (N'uom',N'piece',N'Piece');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'warehouse_type' AND normalized_value=N'finished goods')
 INSERT etl.TextMap VALUES (N'warehouse_type',N'finished goods',N'Finished Goods');
IF NOT EXISTS (SELECT 1 FROM etl.TextMap WHERE domain=N'warehouse_type' AND normalized_value=N'raw material')
 INSERT etl.TextMap VALUES (N'warehouse_type',N'raw material',N'Raw Material');
GO
CREATE OR ALTER FUNCTION etl.CanonicalText(@domain VARCHAR(80),@value VARCHAR(4000))
RETURNS VARCHAR(4000)
AS
BEGIN
 DECLARE @clean VARCHAR(4000)=etl.CleanText(@value), @result VARCHAR(250);
 SELECT @result=canonical_value FROM etl.TextMap WHERE domain=@domain AND normalized_value=LOWER(@clean);
 RETURN COALESCE(@result,@clean);
END;
GO
CREATE OR ALTER PROCEDURE etl.LoadSilver
AS
BEGIN
 SET NOCOUNT ON;
 SET XACT_ABORT ON;
 IF @@TRANCOUNT=0 THROW 51002, 'Run etl.RefreshAll; this loader requires its transaction.', 1;
 DELETE FROM silver.[Returns];
 DELETE FROM silver.[FinishedGoodsInventoryTransactions];
 DELETE FROM silver.[CustomerShipmentDetails];
 DELETE FROM silver.[CustomerShipments];
 DELETE FROM silver.[SalesOrderDetails];
 DELETE FROM silver.[SalesOrders];
 DELETE FROM silver.[Customers];
 DELETE FROM silver.[FinishedGoodsInventory];
 DELETE FROM silver.[RawMaterialInventoryTransactions];
 DELETE FROM silver.[ProductionDetails];
 DELETE FROM silver.[Production];
 DELETE FROM silver.[ProductBOM];
 DELETE FROM silver.[Products];
 DELETE FROM silver.[RawMaterialInventory];
 DELETE FROM silver.[Warehouses];
 DELETE FROM silver.[SupplierPayments];
 DELETE FROM silver.[SupplierInvoiceDetails];
 DELETE FROM silver.[SupplierInvoices];
 DELETE FROM silver.[QualityInspections];
 DELETE FROM silver.[GoodsReceiptDetails];
 DELETE FROM silver.[GoodsReceipts];
 DELETE FROM silver.[SupplierShipmentDetails];
 DELETE FROM silver.[SupplierShipments];
 DELETE FROM silver.[PurchaseOrderDetails];
 DELETE FROM silver.[PurchaseOrders];
 DELETE FROM silver.[PurchaseRequisitionDetails];
 DELETE FROM silver.[PurchaseRequisitions];
 DELETE FROM silver.[SupplierMaterials];
 DELETE FROM silver.[Suppliers];
 DELETE FROM silver.[Materials];
 DELETE FROM silver.[Departments];
 INSERT silver.[Departments] ([department_id], [department_code], [department_name], [department_description], [status])
 SELECT [department_id],
        UPPER(etl.CleanText([department_code])),
        etl.CleanText([department_name]),
        etl.CleanText([department_description]),
        etl.CanonicalText('status',[status])
 FROM bronze.[Departments];
 INSERT silver.[Materials] ([material_id], [material_code], [material_name], [material_category], [material_type], [uom], [unit_weight], [status])
 SELECT [material_id],
        UPPER(etl.CleanText([material_code])),
        etl.CleanText([material_name]),
        etl.CanonicalText('material_category',[material_category]),
        etl.CanonicalText('material_type',[material_type]),
        etl.CanonicalText('uom',[uom]),
        [unit_weight],
        etl.CanonicalText('status',[status])
 FROM bronze.[Materials];
 INSERT silver.[Suppliers] ([supplier_id], [supplier_code], [supplier_name], [supplier_type], [supplier_category], [country], [city], [address], [contact_person], [phone], [email], [payment_terms], [status])
 SELECT [supplier_id],
        UPPER(etl.CleanText([supplier_code])),
        etl.CleanText([supplier_name]),
        etl.CanonicalText('supplier_type',[supplier_type]),
        etl.CanonicalText('supplier_category',[supplier_category]),
        etl.CanonicalText('country',[country]),
        etl.CanonicalText('city',[city]),
        etl.CleanText([address]),
        etl.CleanText([contact_person]),
        etl.CleanText([phone]),
        LOWER(etl.CleanText([email])),
        etl.CanonicalText('payment_terms',[payment_terms]),
        etl.CanonicalText('status',[status])
 FROM bronze.[Suppliers];
 INSERT silver.[SupplierMaterials] ([supplier_material_id], [supplier_id], [material_id], [supplier_material_code], [standard_price], [lead_time_days], [minimum_order_quantity], [preferred_supplier], [status])
 SELECT [supplier_material_id],
        [supplier_id],
        [material_id],
        UPPER(etl.CleanText([supplier_material_code])),
        [standard_price],
        [lead_time_days],
        [minimum_order_quantity],
        [preferred_supplier],
        etl.CanonicalText('status',[status])
 FROM bronze.[SupplierMaterials];
 INSERT silver.[PurchaseRequisitions] ([pr_id], [pr_code], [department_id], [requested_by], [request_date], [order_date], [required_date], [priority], [approval_status], [approved_by], [approval_date], [rejection_reason], [created_date])
 SELECT [pr_id],
        UPPER(etl.CleanText([pr_code])),
        [department_id],
        etl.CleanText([requested_by]),
        [request_date],
        [order_date],
        [required_date],
        etl.CanonicalText('priority',[priority]),
        etl.CanonicalText('approval_status',[approval_status]),
        etl.CleanText([approved_by]),
        [approval_date],
        etl.CleanText([rejection_reason]),
        [created_date]
 FROM bronze.[PurchaseRequisitions];
 INSERT silver.[PurchaseRequisitionDetails] ([pr_detail_id], [pr_id], [material_id], [requested_quantity], [estimated_unit_cost])
 SELECT [pr_detail_id],
        [pr_id],
        [material_id],
        [requested_quantity],
        [estimated_unit_cost]
 FROM bronze.[PurchaseRequisitionDetails];
 INSERT silver.[PurchaseOrders] ([po_id], [po_code], [supplier_id], [pr_id], [order_date], [expected_delivery_date], [payment_terms], [status])
 SELECT [po_id],
        UPPER(etl.CleanText([po_code])),
        [supplier_id],
        [pr_id],
        [order_date],
        [expected_delivery_date],
        etl.CanonicalText('payment_terms',[payment_terms]),
        etl.CanonicalText('status',[status])
 FROM bronze.[PurchaseOrders];
 INSERT silver.[PurchaseOrderDetails] ([po_detail_id], [po_id], [pr_detail_id], [material_id], [ordered_quantity], [unit_price], [discount_percentage], [expected_delivery_date], [total_amount], [line_status])
 SELECT [po_detail_id],
        [po_id],
        [pr_detail_id],
        [material_id],
        [ordered_quantity],
        [unit_price],
        [discount_percentage],
        [expected_delivery_date],
        [total_amount],
        etl.CanonicalText('line_status',[line_status])
 FROM bronze.[PurchaseOrderDetails];
 INSERT silver.[SupplierShipments] ([shipment_id], [shipment_code], [po_id], [supplier_id], [supplier_reference], [ship_date], [expected_arrival_date], [actual_arrival_date], [total_shipment_value], [shipping_cost])
 SELECT [shipment_id],
        UPPER(etl.CleanText([shipment_code])),
        [po_id],
        [supplier_id],
        etl.CleanText([supplier_reference]),
        [ship_date],
        [expected_arrival_date],
        [actual_arrival_date],
        [total_shipment_value],
        [shipping_cost]
 FROM bronze.[SupplierShipments];
 INSERT silver.[SupplierShipmentDetails] ([shipment_detail_id], [shipment_id], [po_detail_id], [material_id], [received_quantity], [accepted_quantity], [rejected_quantity])
 SELECT [shipment_detail_id],
        [shipment_id],
        [po_detail_id],
        [material_id],
        [received_quantity],
        [accepted_quantity],
        [rejected_quantity]
 FROM bronze.[SupplierShipmentDetails];
 INSERT silver.[GoodsReceipts] ([gr_id], [gr_code], [shipment_id], [receipt_date], [received_by], [quality_check_status], [total_received_value])
 SELECT [gr_id],
        UPPER(etl.CleanText([gr_code])),
        [shipment_id],
        [receipt_date],
        etl.CleanText([received_by]),
        etl.CanonicalText('quality_check_status',[quality_check_status]),
        [total_received_value]
 FROM bronze.[GoodsReceipts];
 INSERT silver.[GoodsReceiptDetails] ([gr_detail_id], [gr_id], [shipment_detail_id], [material_id], [received_quantity], [accepted_quantity], [rejected_quantity], [inspection_status], [batch_number])
 SELECT [gr_detail_id],
        [gr_id],
        [shipment_detail_id],
        [material_id],
        [received_quantity],
        [accepted_quantity],
        [rejected_quantity],
        etl.CanonicalText('inspection_status',[inspection_status]),
        etl.CleanText([batch_number])
 FROM bronze.[GoodsReceiptDetails];
 INSERT silver.[QualityInspections] ([inspection_id], [gr_detail_id], [inspection_date], [inspection_type], [inspected_quantity], [passed_quantity], [inspection_result], [defect_quantity], [defect_reason], [corrective_action], [reinspection_required], [status])
 SELECT [inspection_id],
        [gr_detail_id],
        [inspection_date],
        etl.CanonicalText('inspection_type',[inspection_type]),
        [inspected_quantity],
        [passed_quantity],
        etl.CanonicalText('inspection_result',[inspection_result]),
        [defect_quantity],
        etl.CanonicalText('defect_reason',[defect_reason]),
        etl.CleanText([corrective_action]),
        [reinspection_required],
        etl.CanonicalText('status',[status])
 FROM bronze.[QualityInspections];
 INSERT silver.[SupplierInvoices] ([invoice_id], [invoice_number], [shipment_id], [supplier_id], [invoice_date], [invoice_amount], [tax_amount], [total_amount], [due_date], [payment_terms], [payment_status])
 SELECT [invoice_id],
        etl.CleanText([invoice_number]),
        [shipment_id],
        [supplier_id],
        [invoice_date],
        [invoice_amount],
        [tax_amount],
        [total_amount],
        [due_date],
        etl.CanonicalText('payment_terms',[payment_terms]),
        etl.CanonicalText('payment_status',[payment_status])
 FROM bronze.[SupplierInvoices];
 INSERT silver.[SupplierInvoiceDetails] ([invoice_detail_id], [invoice_id], [gr_detail_id], [billed_quantity], [unit_price], [tax_amount], [line_amount])
 SELECT [invoice_detail_id],
        [invoice_id],
        [gr_detail_id],
        [billed_quantity],
        [unit_price],
        [tax_amount],
        [line_amount]
 FROM bronze.[SupplierInvoiceDetails];
 INSERT silver.[SupplierPayments] ([payment_id], [invoice_id], [payment_date], [payment_amount], [payment_method], [currency], [transaction_reference], [payment_status])
 SELECT [payment_id],
        [invoice_id],
        [payment_date],
        [payment_amount],
        etl.CanonicalText('payment_method',[payment_method]),
        UPPER(etl.CleanText([currency])),
        etl.CleanText([transaction_reference]),
        etl.CanonicalText('payment_status',[payment_status])
 FROM bronze.[SupplierPayments];
 INSERT silver.[Warehouses] ([warehouse_id], [warehouse_code], [warehouse_name], [warehouse_type], [country], [city], [location_description], [status])
 SELECT [warehouse_id],
        UPPER(etl.CleanText([warehouse_code])),
        etl.CleanText([warehouse_name]),
        etl.CanonicalText('warehouse_type',[warehouse_type]),
        etl.CanonicalText('country',[country]),
        etl.CanonicalText('city',[city]),
        etl.CleanText([location_description]),
        etl.CanonicalText('status',[status])
 FROM bronze.[Warehouses];
 INSERT silver.[RawMaterialInventory] ([raw_inventory_id], [warehouse_id], [material_id], [quantity_on_hand], [quantity_reserved], [reorder_point], [safety_stock_level], [max_inventory_level], [unit_cost], [last_updated_at])
 SELECT [raw_inventory_id],
        [warehouse_id],
        [material_id],
        [quantity_on_hand],
        [quantity_reserved],
        [reorder_point],
        [safety_stock_level],
        [max_inventory_level],
        [unit_cost],
        [last_updated_at]
 FROM bronze.[RawMaterialInventory];
 INSERT silver.[Products] ([product_id], [product_code], [product_name], [product_category], [uom], [standard_cost], [selling_price], [status])
 SELECT [product_id],
        UPPER(etl.CleanText([product_code])),
        etl.CleanText([product_name]),
        etl.CanonicalText('product_category',[product_category]),
        etl.CanonicalText('uom',[uom]),
        [standard_cost],
        [selling_price],
        etl.CanonicalText('status',[status])
 FROM bronze.[Products];
 INSERT silver.[ProductBOM] ([bom_id], [product_id], [material_id], [quantity_required], [uom], [status])
 SELECT [bom_id],
        [product_id],
        [material_id],
        [quantity_required],
        etl.CanonicalText('uom',[uom]),
        etl.CanonicalText('status',[status])
 FROM bronze.[ProductBOM];
 INSERT silver.[Production] ([production_id], [production_order_code], [product_id], [planned_quantity], [start_date], [expected_end_date], [actual_end_date], [production_quantity], [rejected_quantity], [production_status])
 SELECT [production_id],
        UPPER(etl.CleanText([production_order_code])),
        [product_id],
        [planned_quantity],
        [start_date],
        [expected_end_date],
        [actual_end_date],
        [production_quantity],
        [rejected_quantity],
        etl.CanonicalText('production_status',[production_status])
 FROM bronze.[Production];
 INSERT silver.[ProductionDetails] ([production_detail_id], [production_id], [bom_id], [raw_inventory_id], [actual_consumed_quantity], [return_quantity], [scrap_quantity], [unit_cost], [total_material_cost])
 SELECT [production_detail_id],
        [production_id],
        [bom_id],
        [raw_inventory_id],
        [actual_consumed_quantity],
        [return_quantity],
        [scrap_quantity],
        [unit_cost],
        [total_material_cost]
 FROM bronze.[ProductionDetails];
 INSERT silver.[RawMaterialInventoryTransactions] ([raw_transaction_id], [raw_inventory_id], [production_id], [inspection_id], [transaction_type], [quantity], [unit_cost], [transaction_date], [reference_code])
 SELECT [raw_transaction_id],
        [raw_inventory_id],
        [production_id],
        [inspection_id],
        etl.CanonicalText('transaction_type',[transaction_type]),
        [quantity],
        [unit_cost],
        [transaction_date],
        UPPER(etl.CleanText([reference_code]))
 FROM bronze.[RawMaterialInventoryTransactions];
 INSERT silver.[FinishedGoodsInventory] ([finished_goods_inventory_id], [warehouse_id], [product_id], [quantity_on_hand], [quantity_reserved], [reorder_point], [safety_stock_level], [last_updated_at])
 SELECT [finished_goods_inventory_id],
        [warehouse_id],
        [product_id],
        [quantity_on_hand],
        [quantity_reserved],
        [reorder_point],
        [safety_stock_level],
        [last_updated_at]
 FROM bronze.[FinishedGoodsInventory];
 INSERT silver.[Customers] ([customer_id], [customer_code], [customer_name], [customer_type], [email], [phone], [country], [city], [address], [registration_date], [default_discount_percentage], [status])
 SELECT [customer_id],
        UPPER(etl.CleanText([customer_code])),
        etl.CleanText([customer_name]),
        etl.CanonicalText('customer_type',[customer_type]),
        LOWER(etl.CleanText([email])),
        etl.CleanText([phone]),
        etl.CanonicalText('country',[country]),
        etl.CanonicalText('city',[city]),
        etl.CleanText([address]),
        [registration_date],
        [default_discount_percentage],
        etl.CanonicalText('status',[status])
 FROM bronze.[Customers];
 INSERT silver.[SalesOrders] ([sales_order_id], [sales_order_code], [customer_id], [order_date], [required_delivery_date], [payment_method], [tax_percentage], [sales_order_status])
 SELECT [sales_order_id],
        UPPER(etl.CleanText([sales_order_code])),
        [customer_id],
        [order_date],
        [required_delivery_date],
        etl.CanonicalText('payment_method',[payment_method]),
        [tax_percentage],
        etl.CanonicalText('sales_order_status',[sales_order_status])
 FROM bronze.[SalesOrders];
 INSERT silver.[SalesOrderDetails] ([sales_order_detail_id], [sales_order_id], [product_id], [ordered_quantity], [line_status])
 SELECT [sales_order_detail_id],
        [sales_order_id],
        [product_id],
        [ordered_quantity],
        etl.CanonicalText('line_status',[line_status])
 FROM bronze.[SalesOrderDetails];
 INSERT silver.[CustomerShipments] ([customer_shipment_id], [shipment_code], [sales_order_id], [warehouse_id], [shipment_date], [expected_delivery_date], [actual_delivery_date], [tracking_number], [shipping_method], [shipping_cost], [delivery_address], [shipment_status], [delivery_confirmation], [customer_feedback])
 SELECT [customer_shipment_id],
        UPPER(etl.CleanText([shipment_code])),
        [sales_order_id],
        [warehouse_id],
        [shipment_date],
        [expected_delivery_date],
        [actual_delivery_date],
        etl.CleanText([tracking_number]),
        etl.CanonicalText('shipping_method',[shipping_method]),
        [shipping_cost],
        etl.CleanText([delivery_address]),
        etl.CanonicalText('shipment_status',[shipment_status]),
        [delivery_confirmation],
        etl.CleanText([customer_feedback])
 FROM bronze.[CustomerShipments];
 INSERT silver.[CustomerShipmentDetails] ([customer_shipment_detail_id], [customer_shipment_id], [sales_order_detail_id], [shipped_quantity])
 SELECT [customer_shipment_detail_id],
        [customer_shipment_id],
        [sales_order_detail_id],
        [shipped_quantity]
 FROM bronze.[CustomerShipmentDetails];
 INSERT silver.[FinishedGoodsInventoryTransactions] ([finished_inventory_transaction_id], [finished_goods_inventory_id], [production_id], [customer_shipment_detail_id], [transaction_type], [quantity], [unit_cost], [transaction_date], [reference_code])
 SELECT [finished_inventory_transaction_id],
        [finished_goods_inventory_id],
        [production_id],
        [customer_shipment_detail_id],
        etl.CanonicalText('transaction_type',[transaction_type]),
        [quantity],
        [unit_cost],
        [transaction_date],
        UPPER(etl.CleanText([reference_code]))
 FROM bronze.[FinishedGoodsInventoryTransactions];
 INSERT silver.[Returns] ([return_id], [return_code], [customer_shipment_detail_id], [return_request_date], [return_received_date], [returned_quantity], [return_reason], [product_condition], [return_status])
 SELECT [return_id],
        UPPER(etl.CleanText([return_code])),
        [customer_shipment_detail_id],
        [return_request_date],
        [return_received_date],
        [returned_quantity],
        etl.CanonicalText('return_reason',[return_reason]),
        etl.CanonicalText('product_condition',[product_condition]),
        etl.CanonicalText('return_status',[return_status])
 FROM bronze.[Returns];
END;
GO


-- FILE: 05_Create_Gold.sql
USE [ElectronicsSupplyChainDB_v2];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO
-- Gold views are read-only. Quantity/value fields retain Silver precision.
IF OBJECT_ID(N'gold.DimDate',N'U') IS NULL
CREATE TABLE gold.DimDate
(
 full_date DATE PRIMARY KEY, calendar_year INT NOT NULL,
 quarter_number INT NOT NULL, quarter_name VARCHAR(2) NOT NULL,
 month_number INT NOT NULL, month_name VARCHAR(20) NOT NULL,
 year_month CHAR(7) NOT NULL, year_month_sort INT NOT NULL,
 week_number INT NOT NULL, iso_week_year INT NOT NULL,
 day_of_month INT NOT NULL, day_name VARCHAR(20) NOT NULL
);
GO
CREATE OR ALTER PROCEDURE etl.RefreshDimDate
AS
BEGIN
 SET NOCOUNT ON;
 IF @@TRANCOUNT=0 THROW 51003, 'Run etl.RefreshAll; date refresh requires its transaction.', 1;
 SET LANGUAGE us_english;
 DECLARE @MinDate DATE,@MaxDate DATE;
 SELECT @MinDate=MIN(d),@MaxDate=MAX(d) FROM (
 SELECT CAST([request_date] AS DATE) AS d FROM silver.[PurchaseRequisitions]
 UNION ALL
 SELECT CAST([order_date] AS DATE) AS d FROM silver.[PurchaseRequisitions]
 UNION ALL
 SELECT CAST([required_date] AS DATE) AS d FROM silver.[PurchaseRequisitions]
 UNION ALL
 SELECT CAST([approval_date] AS DATE) AS d FROM silver.[PurchaseRequisitions]
 UNION ALL
 SELECT CAST([created_date] AS DATE) AS d FROM silver.[PurchaseRequisitions]
 UNION ALL
 SELECT CAST([order_date] AS DATE) AS d FROM silver.[PurchaseOrders]
 UNION ALL
 SELECT CAST([expected_delivery_date] AS DATE) AS d FROM silver.[PurchaseOrders]
 UNION ALL
 SELECT CAST([expected_delivery_date] AS DATE) AS d FROM silver.[PurchaseOrderDetails]
 UNION ALL
 SELECT CAST([ship_date] AS DATE) AS d FROM silver.[SupplierShipments]
 UNION ALL
 SELECT CAST([expected_arrival_date] AS DATE) AS d FROM silver.[SupplierShipments]
 UNION ALL
 SELECT CAST([actual_arrival_date] AS DATE) AS d FROM silver.[SupplierShipments]
 UNION ALL
 SELECT CAST([receipt_date] AS DATE) AS d FROM silver.[GoodsReceipts]
 UNION ALL
 SELECT CAST([inspection_date] AS DATE) AS d FROM silver.[QualityInspections]
 UNION ALL
 SELECT CAST([invoice_date] AS DATE) AS d FROM silver.[SupplierInvoices]
 UNION ALL
 SELECT CAST([due_date] AS DATE) AS d FROM silver.[SupplierInvoices]
 UNION ALL
 SELECT CAST([payment_date] AS DATE) AS d FROM silver.[SupplierPayments]
 UNION ALL
 SELECT CAST([last_updated_at] AS DATE) AS d FROM silver.[RawMaterialInventory]
 UNION ALL
 SELECT CAST([start_date] AS DATE) AS d FROM silver.[Production]
 UNION ALL
 SELECT CAST([expected_end_date] AS DATE) AS d FROM silver.[Production]
 UNION ALL
 SELECT CAST([actual_end_date] AS DATE) AS d FROM silver.[Production]
 UNION ALL
 SELECT CAST([transaction_date] AS DATE) AS d FROM silver.[RawMaterialInventoryTransactions]
 UNION ALL
 SELECT CAST([last_updated_at] AS DATE) AS d FROM silver.[FinishedGoodsInventory]
 UNION ALL
 SELECT CAST([registration_date] AS DATE) AS d FROM silver.[Customers]
 UNION ALL
 SELECT CAST([order_date] AS DATE) AS d FROM silver.[SalesOrders]
 UNION ALL
 SELECT CAST([required_delivery_date] AS DATE) AS d FROM silver.[SalesOrders]
 UNION ALL
 SELECT CAST([shipment_date] AS DATE) AS d FROM silver.[CustomerShipments]
 UNION ALL
 SELECT CAST([expected_delivery_date] AS DATE) AS d FROM silver.[CustomerShipments]
 UNION ALL
 SELECT CAST([actual_delivery_date] AS DATE) AS d FROM silver.[CustomerShipments]
 UNION ALL
 SELECT CAST([transaction_date] AS DATE) AS d FROM silver.[FinishedGoodsInventoryTransactions]
 UNION ALL
 SELECT CAST([return_request_date] AS DATE) AS d FROM silver.[Returns]
 UNION ALL
 SELECT CAST([return_received_date] AS DATE) AS d FROM silver.[Returns]
 ) dates WHERE d IS NOT NULL;
 IF @MinDate IS NULL THROW 51004, 'No dates available; load source data first.', 1;
 SET @MinDate=DATEFROMPARTS(YEAR(@MinDate),1,1);
 SET @MaxDate=DATEFROMPARTS(YEAR(@MaxDate),12,31);
 DELETE FROM gold.DimDate;
 ;WITH DateSeries AS (
 SELECT @MinDate AS d UNION ALL SELECT DATEADD(DAY,1,d) FROM DateSeries WHERE d<@MaxDate
 )
 INSERT gold.DimDate
 SELECT d,YEAR(d),DATEPART(QUARTER,d),CONCAT('Q',DATEPART(QUARTER,d)),MONTH(d),DATENAME(MONTH,d),
 CONVERT(CHAR(7),d,120),YEAR(d)*100+MONTH(d),DATEPART(ISO_WEEK,d),
 CASE WHEN MONTH(d)=1 AND DATEPART(ISO_WEEK,d)>50 THEN YEAR(d)-1
      WHEN MONTH(d)=12 AND DATEPART(ISO_WEEK,d)=1 THEN YEAR(d)+1 ELSE YEAR(d) END,
 DAY(d),DATENAME(WEEKDAY,d) FROM DateSeries OPTION (MAXRECURSION 0);
END;
GO
CREATE OR ALTER VIEW gold.vw_DimDepartment
AS
SELECT
    department_id,
    department_code,
    department_name,
    department_description,
    status
FROM silver.Departments;
GO

CREATE OR ALTER VIEW gold.vw_DimSupplier
AS
SELECT
    supplier_id,
    supplier_code,
    supplier_name,
    supplier_type,
    supplier_category,
    country,
    city,
    status
FROM silver.Suppliers;
GO

CREATE OR ALTER VIEW gold.vw_DimMaterial
AS
SELECT
    material_id,
    material_code,
    material_name,
    material_category,
    material_type,
    uom,
    unit_weight,
    status
FROM silver.Materials;
GO

CREATE OR ALTER VIEW gold.vw_DimProduct
AS
SELECT
    product_id,
    product_code,
    product_name,
    product_category,
    uom,
    standard_cost,
    selling_price,
    status
FROM silver.Products;
GO

CREATE OR ALTER VIEW gold.vw_DimCustomer
AS
SELECT
    customer_id,
    customer_code,
    customer_name,
    customer_type,
    country,
    city,
    registration_date,
    default_discount_percentage,
    status
FROM silver.Customers;
GO

CREATE OR ALTER VIEW gold.vw_DimWarehouse
AS
SELECT
    warehouse_id,
    warehouse_code,
    warehouse_name,
    warehouse_type,
    country,
    city,
    location_description,
    status
FROM silver.Warehouses;
GO

CREATE OR ALTER VIEW gold.vw_BridgeSupplierMaterial
AS
SELECT
    supplier_material_id,
    supplier_id,
    material_id,
    supplier_material_code,
    standard_price,
    lead_time_days,
    minimum_order_quantity,
    preferred_supplier,
    status
FROM silver.SupplierMaterials;
GO

CREATE OR ALTER VIEW gold.vw_BridgeProductBOM
AS
SELECT
    bom_id,
    product_id,
    material_id,
    quantity_required,
    uom,
    status
FROM silver.ProductBOM;
GO

CREATE OR ALTER VIEW gold.vw_FactPurchaseRequisition
AS
SELECT pr.pr_id, pr.department_id, pr.request_date, pr.order_date AS pr_order_date,
 pr.required_date, pr.approval_date, pr.created_date, pr.priority, pr.approval_status,
 po.first_po_order_date, COALESCE(po.purchase_order_count,0) AS purchase_order_count
FROM silver.PurchaseRequisitions pr
LEFT JOIN (SELECT pr_id, MIN(order_date) AS first_po_order_date,COUNT_BIG(*) AS purchase_order_count
           FROM silver.PurchaseOrders GROUP BY pr_id) po ON po.pr_id=pr.pr_id;
GO

CREATE OR ALTER VIEW gold.vw_FactPurchaseOrderDetail
AS
SELECT
    pod.po_detail_id,
    pod.po_id,
    pod.pr_detail_id,

    po.pr_id,
    po.supplier_id,
    pr.department_id,
    pod.material_id,

    po.order_date,
    pod.expected_delivery_date,

    po.status AS po_status,
    pod.line_status,

    pod.ordered_quantity,
    pod.unit_price,
    pod.discount_percentage,
    pod.total_amount,

    sm.supplier_material_id,
    sm.standard_price

FROM silver.PurchaseOrderDetails pod

INNER JOIN silver.PurchaseOrders po
    ON po.po_id = pod.po_id

INNER JOIN silver.PurchaseRequisitions pr
    ON pr.pr_id = po.pr_id

OUTER APPLY
(
    SELECT TOP (1)
        x.supplier_material_id,
        x.standard_price
    FROM silver.SupplierMaterials x
    WHERE x.supplier_id = po.supplier_id
      AND x.material_id = pod.material_id
    ORDER BY
        x.preferred_supplier DESC,
        x.supplier_material_id
) sm;
GO

CREATE OR ALTER VIEW gold.vw_FactSupplierShipment
AS
SELECT
    ss.shipment_id,
    ss.po_id,
    ss.supplier_id,

    po.pr_id,
    pr.department_id,

    ss.ship_date,
    ss.expected_arrival_date,
    ss.actual_arrival_date,

    po.order_date AS po_order_date,
    pr.request_date AS pr_request_date,

    ss.total_shipment_value,
    ss.shipping_cost

FROM silver.SupplierShipments ss

INNER JOIN silver.PurchaseOrders po
    ON po.po_id = ss.po_id

INNER JOIN silver.PurchaseRequisitions pr
    ON pr.pr_id = po.pr_id;
GO

CREATE OR ALTER VIEW gold.vw_FactSupplierShipmentDetail
AS
SELECT
    ssd.shipment_detail_id,
    ssd.shipment_id,
    ssd.po_detail_id,

    ss.po_id,
    ss.supplier_id,

    pod.pr_detail_id,
    pod.material_id,

    ss.ship_date,
    ss.expected_arrival_date,
    ss.actual_arrival_date,

    pod.ordered_quantity AS line_ordered_quantity_nonadditive,
    ssd.received_quantity,
    ssd.accepted_quantity,
    ssd.rejected_quantity

FROM silver.SupplierShipmentDetails ssd

INNER JOIN silver.SupplierShipments ss
    ON ss.shipment_id = ssd.shipment_id

INNER JOIN silver.PurchaseOrderDetails pod
    ON pod.po_detail_id = ssd.po_detail_id;
GO

CREATE OR ALTER VIEW gold.vw_FactGoodsReceiptDetail
AS
SELECT
    grd.gr_detail_id,
    grd.gr_id,
    grd.shipment_detail_id,

    gr.shipment_id,
    ss.supplier_id,
    grd.material_id,

    ss.actual_arrival_date,
    gr.receipt_date,

    grd.batch_number,
    grd.inspection_status,

    grd.received_quantity,
    grd.accepted_quantity,
    grd.rejected_quantity

FROM silver.GoodsReceiptDetails grd

INNER JOIN silver.GoodsReceipts gr
    ON gr.gr_id = grd.gr_id

INNER JOIN silver.SupplierShipments ss
    ON ss.shipment_id = gr.shipment_id;
GO

CREATE OR ALTER VIEW gold.vw_FactQualityInspection
AS
SELECT
    qi.inspection_id,
    qi.gr_detail_id,

    grd.gr_id,
    grd.material_id,
    ss.supplier_id,

    qi.inspection_date,

    qi.inspection_type,
    qi.inspection_result,
    qi.defect_reason,
    qi.reinspection_required,
    qi.status,

    qi.inspected_quantity,
    qi.passed_quantity,
    qi.defect_quantity

FROM silver.QualityInspections qi

INNER JOIN silver.GoodsReceiptDetails grd
    ON grd.gr_detail_id = qi.gr_detail_id

INNER JOIN silver.GoodsReceipts gr
    ON gr.gr_id = grd.gr_id

INNER JOIN silver.SupplierShipments ss
    ON ss.shipment_id = gr.shipment_id;
GO

CREATE OR ALTER VIEW gold.vw_FactRawMaterialInventory
AS
SELECT
    raw_inventory_id,
    warehouse_id,
    material_id,

    quantity_on_hand,
    quantity_reserved,
    reorder_point,
    safety_stock_level,
    max_inventory_level,
    unit_cost,

    last_updated_at

FROM silver.RawMaterialInventory;
GO

CREATE OR ALTER VIEW gold.vw_FactRawInventoryTransaction
AS
SELECT
    tx.raw_transaction_id,
    tx.raw_inventory_id,

    inv.warehouse_id,
    inv.material_id,

    tx.production_id,
    tx.inspection_id,

    tx.transaction_type,
    tx.quantity,
    tx.unit_cost,
    tx.transaction_date,
    CAST(tx.transaction_date AS DATE) AS transaction_day,
    tx.reference_code

FROM silver.RawMaterialInventoryTransactions tx

INNER JOIN silver.RawMaterialInventory inv
    ON inv.raw_inventory_id = tx.raw_inventory_id;
GO

CREATE OR ALTER VIEW gold.vw_FactProductionOrder
AS
SELECT
    production_id,
    product_id,

    start_date,
    expected_end_date,
    actual_end_date,

    production_status,

    planned_quantity,
    production_quantity,
    rejected_quantity

FROM silver.Production;
GO

CREATE OR ALTER VIEW gold.vw_FactProductionMaterial
AS
SELECT
    pd.production_detail_id,
    pd.production_id,
    pd.bom_id,
    pd.raw_inventory_id,

    p.product_id,
    bom.material_id,
    inv.warehouse_id,

    p.start_date,
    p.expected_end_date,
    p.actual_end_date,
    p.production_status,

    bom.quantity_required,

    p.planned_quantity AS order_planned_quantity_nonadditive,
    p.production_quantity AS order_production_quantity_nonadditive,
    p.rejected_quantity AS order_rejected_quantity_nonadditive,

    pd.actual_consumed_quantity,
    pd.return_quantity,
    pd.scrap_quantity,

    pd.unit_cost,
    pd.total_material_cost

FROM silver.ProductionDetails pd

INNER JOIN silver.Production p
    ON p.production_id = pd.production_id

INNER JOIN silver.ProductBOM bom
    ON bom.bom_id = pd.bom_id

INNER JOIN silver.RawMaterialInventory inv
    ON inv.raw_inventory_id = pd.raw_inventory_id;
GO

CREATE OR ALTER VIEW gold.vw_FactFinishedGoodsInventory
AS
SELECT
    fg.finished_goods_inventory_id,
    fg.warehouse_id,
    fg.product_id,

    fg.quantity_on_hand,
    fg.quantity_reserved,
    fg.reorder_point,
    fg.safety_stock_level,

    p.standard_cost,

    fg.last_updated_at

FROM silver.FinishedGoodsInventory fg

INNER JOIN silver.Products p
    ON p.product_id = fg.product_id;
GO

CREATE OR ALTER VIEW gold.vw_FactFinishedGoodsTransaction
AS
SELECT
    tx.finished_inventory_transaction_id,
    tx.finished_goods_inventory_id,

    inv.warehouse_id,
    inv.product_id,

    tx.production_id,
    tx.customer_shipment_detail_id,

    tx.transaction_type,
    tx.quantity,
    tx.unit_cost,
    tx.transaction_date,
    CAST(tx.transaction_date AS DATE) AS transaction_day,
    tx.reference_code

FROM silver.FinishedGoodsInventoryTransactions tx

INNER JOIN silver.FinishedGoodsInventory inv
    ON inv.finished_goods_inventory_id = tx.finished_goods_inventory_id;
GO

CREATE OR ALTER VIEW gold.vw_FactSalesOrderDetail
AS
SELECT
    sod.sales_order_detail_id,
    sod.sales_order_id,

    so.customer_id,
    sod.product_id,

    so.order_date,
    so.required_delivery_date,

    so.sales_order_status,
    sod.line_status,

    so.payment_method,
    so.tax_percentage,

    sod.ordered_quantity,

    p.selling_price,
    p.standard_cost

FROM silver.SalesOrderDetails sod

INNER JOIN silver.SalesOrders so
    ON so.sales_order_id = sod.sales_order_id

INNER JOIN silver.Products p
    ON p.product_id = sod.product_id;
GO

CREATE OR ALTER VIEW gold.vw_FactCustomerShipment
AS
SELECT
    cs.customer_shipment_id,
    cs.sales_order_id,

    so.customer_id,
    cs.warehouse_id,

    so.order_date,
    so.required_delivery_date,

    cs.shipment_date,
    cs.expected_delivery_date,
    cs.actual_delivery_date,

    cs.shipping_method,
    cs.shipping_cost,
    cs.shipment_status,
    cs.delivery_confirmation

FROM silver.CustomerShipments cs

INNER JOIN silver.SalesOrders so
    ON so.sales_order_id = cs.sales_order_id;
GO

CREATE OR ALTER VIEW gold.vw_FactCustomerShipmentDetail
AS
SELECT
    csd.customer_shipment_detail_id,
    csd.customer_shipment_id,
    csd.sales_order_detail_id,

    cs.sales_order_id,
    so.customer_id,
    sod.product_id,
    cs.warehouse_id,

    so.order_date,
    cs.shipment_date,
    cs.expected_delivery_date,
    cs.actual_delivery_date,

    so.sales_order_status,
    sod.line_status,
    cs.shipment_status,

    sod.ordered_quantity AS line_ordered_quantity_nonadditive,
    csd.shipped_quantity,

    p.selling_price,
    p.standard_cost

FROM silver.CustomerShipmentDetails csd

INNER JOIN silver.CustomerShipments cs
    ON cs.customer_shipment_id = csd.customer_shipment_id

INNER JOIN silver.SalesOrders so
    ON so.sales_order_id = cs.sales_order_id

INNER JOIN silver.SalesOrderDetails sod
    ON sod.sales_order_detail_id = csd.sales_order_detail_id

INNER JOIN silver.Products p
    ON p.product_id = sod.product_id;
GO

CREATE OR ALTER VIEW gold.vw_FactReturn
AS
SELECT
    r.return_id,
    r.customer_shipment_detail_id,

    csd.customer_shipment_id,
    sod.sales_order_detail_id,
    cs.sales_order_id,

    so.customer_id,
    sod.product_id,
    cs.warehouse_id,

    cs.shipment_date,
    cs.actual_delivery_date,

    r.return_request_date,
    r.return_received_date,

    r.returned_quantity,
    csd.shipped_quantity AS line_shipped_quantity_nonadditive,

    r.return_reason,
    r.product_condition,
    r.return_status

FROM silver.Returns r

INNER JOIN silver.CustomerShipmentDetails csd
    ON csd.customer_shipment_detail_id = r.customer_shipment_detail_id

INNER JOIN silver.CustomerShipments cs
    ON cs.customer_shipment_id = csd.customer_shipment_id

INNER JOIN silver.SalesOrderDetails sod
    ON sod.sales_order_detail_id = csd.sales_order_detail_id

INNER JOIN silver.SalesOrders so
    ON so.sales_order_id = cs.sales_order_id;
GO

CREATE OR ALTER VIEW gold.vw_FactSalesFulfillment
AS
-- Grain: one sales order detail, including every unshipped line.
-- Order-date cohort; do not use as shipment-date-period fill rate.
SELECT sod.sales_order_detail_id,sod.sales_order_id,so.customer_id,sod.product_id,
 so.order_date,so.required_delivery_date,so.sales_order_status,sod.line_status,
 sod.ordered_quantity,COALESCE(sh.shipped_quantity,0) AS shipped_quantity,
 sod.ordered_quantity-COALESCE(sh.shipped_quantity,0) AS unfulfilled_quantity,
 COALESCE(sh.shipment_line_count,0) AS shipment_line_count,
 sh.first_shipment_date,sh.last_shipment_date,
 p.selling_price AS reference_selling_price,p.standard_cost AS reference_standard_cost
FROM silver.SalesOrderDetails sod
JOIN silver.SalesOrders so ON so.sales_order_id=sod.sales_order_id
JOIN silver.Products p ON p.product_id=sod.product_id
LEFT JOIN (
 SELECT d.sales_order_detail_id,SUM(d.shipped_quantity) AS shipped_quantity,
 COUNT_BIG(*) AS shipment_line_count,MIN(h.shipment_date) AS first_shipment_date,MAX(h.shipment_date) AS last_shipment_date
 FROM silver.CustomerShipmentDetails d
 JOIN silver.CustomerShipments h ON h.customer_shipment_id=d.customer_shipment_id
 GROUP BY d.sales_order_detail_id
) sh ON sh.sales_order_detail_id=sod.sales_order_detail_id;
GO

CREATE OR ALTER VIEW gold.vw_FactSupplierInvoice
AS
-- One invoice. paid_amount is completed payments only, across all supplied payment dates.
-- Current extract balance; NOT a historical/as-of-date accounts payable balance.
SELECT i.invoice_id,i.shipment_id,i.supplier_id,i.invoice_date,i.due_date,
 i.invoice_amount,i.tax_amount,i.total_amount,i.payment_terms,i.payment_status,
 COALESCE(p.paid_amount,0) AS paid_amount,
 i.total_amount-COALESCE(p.paid_amount,0) AS outstanding_amount
FROM silver.SupplierInvoices i
LEFT JOIN (SELECT invoice_id,SUM(payment_amount) AS paid_amount FROM silver.SupplierPayments
 WHERE payment_status='Completed' GROUP BY invoice_id) p ON p.invoice_id=i.invoice_id;
GO

CREATE OR ALTER VIEW gold.vw_FactSupplierInvoiceDetail
AS
SELECT d.invoice_detail_id,d.invoice_id,d.gr_detail_id,i.supplier_id,g.material_id,
 i.invoice_date,i.due_date,d.billed_quantity,d.unit_price,d.tax_amount,d.line_amount
FROM silver.SupplierInvoiceDetails d
JOIN silver.SupplierInvoices i ON i.invoice_id=d.invoice_id
JOIN silver.GoodsReceiptDetails g ON g.gr_detail_id=d.gr_detail_id;
GO

CREATE OR ALTER VIEW gold.vw_FactSupplierPayment
AS
SELECT p.payment_id,p.invoice_id,i.supplier_id,p.payment_date,p.payment_amount,
 p.payment_method,p.currency,p.payment_status,i.due_date
FROM silver.SupplierPayments p JOIN silver.SupplierInvoices i ON i.invoice_id=p.invoice_id;
GO



-- FILE: 06_Validate_Data.sql
USE [ElectronicsSupplyChainDB_v2];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO
CREATE OR ALTER PROCEDURE etl.ValidateData
 @CheckSampleBaseline BIT=1
AS
BEGIN
 SET NOCOUNT ON;
 CREATE TABLE #Checks (check_name VARCHAR(200), failures BIGINT);
 INSERT #Checks SELECT N'Departments: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[Departments])-(SELECT COUNT_BIG(*) FROM silver.[Departments])));
 INSERT #Checks SELECT N'Departments: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [department_id] FROM bronze.[Departments] EXCEPT SELECT [department_id] FROM silver.[Departments]) d);
 INSERT #Checks SELECT N'Materials: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[Materials])-(SELECT COUNT_BIG(*) FROM silver.[Materials])));
 INSERT #Checks SELECT N'Materials: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [material_id],[unit_weight] FROM bronze.[Materials] EXCEPT SELECT [material_id],[unit_weight] FROM silver.[Materials]) d);
 INSERT #Checks SELECT N'Materials.unit_weight: negative values', (SELECT COUNT_BIG(*) FROM silver.[Materials] WHERE [unit_weight]<0);
 INSERT #Checks SELECT N'Suppliers: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[Suppliers])-(SELECT COUNT_BIG(*) FROM silver.[Suppliers])));
 INSERT #Checks SELECT N'Suppliers: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [supplier_id] FROM bronze.[Suppliers] EXCEPT SELECT [supplier_id] FROM silver.[Suppliers]) d);
 INSERT #Checks SELECT N'SupplierMaterials: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[SupplierMaterials])-(SELECT COUNT_BIG(*) FROM silver.[SupplierMaterials])));
 INSERT #Checks SELECT N'SupplierMaterials: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [supplier_material_id],[supplier_id],[material_id],[standard_price],[lead_time_days],[minimum_order_quantity],[preferred_supplier] FROM bronze.[SupplierMaterials] EXCEPT SELECT [supplier_material_id],[supplier_id],[material_id],[standard_price],[lead_time_days],[minimum_order_quantity],[preferred_supplier] FROM silver.[SupplierMaterials]) d);
 INSERT #Checks SELECT N'SupplierMaterials.standard_price: negative values', (SELECT COUNT_BIG(*) FROM silver.[SupplierMaterials] WHERE [standard_price]<0);
 INSERT #Checks SELECT N'SupplierMaterials.lead_time_days: negative values', (SELECT COUNT_BIG(*) FROM silver.[SupplierMaterials] WHERE [lead_time_days]<0);
 INSERT #Checks SELECT N'SupplierMaterials.minimum_order_quantity: negative values', (SELECT COUNT_BIG(*) FROM silver.[SupplierMaterials] WHERE [minimum_order_quantity]<0);
 INSERT #Checks SELECT N'PurchaseRequisitions: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[PurchaseRequisitions])-(SELECT COUNT_BIG(*) FROM silver.[PurchaseRequisitions])));
 INSERT #Checks SELECT N'PurchaseRequisitions: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [pr_id],[department_id],[request_date],[order_date],[required_date],[approval_date],[created_date] FROM bronze.[PurchaseRequisitions] EXCEPT SELECT [pr_id],[department_id],[request_date],[order_date],[required_date],[approval_date],[created_date] FROM silver.[PurchaseRequisitions]) d);
 INSERT #Checks SELECT N'PurchaseRequisitionDetails: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[PurchaseRequisitionDetails])-(SELECT COUNT_BIG(*) FROM silver.[PurchaseRequisitionDetails])));
 INSERT #Checks SELECT N'PurchaseRequisitionDetails: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [pr_detail_id],[pr_id],[material_id],[requested_quantity],[estimated_unit_cost] FROM bronze.[PurchaseRequisitionDetails] EXCEPT SELECT [pr_detail_id],[pr_id],[material_id],[requested_quantity],[estimated_unit_cost] FROM silver.[PurchaseRequisitionDetails]) d);
 INSERT #Checks SELECT N'PurchaseRequisitionDetails.requested_quantity: negative values', (SELECT COUNT_BIG(*) FROM silver.[PurchaseRequisitionDetails] WHERE [requested_quantity]<0);
 INSERT #Checks SELECT N'PurchaseRequisitionDetails.estimated_unit_cost: negative values', (SELECT COUNT_BIG(*) FROM silver.[PurchaseRequisitionDetails] WHERE [estimated_unit_cost]<0);
 INSERT #Checks SELECT N'PurchaseOrders: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[PurchaseOrders])-(SELECT COUNT_BIG(*) FROM silver.[PurchaseOrders])));
 INSERT #Checks SELECT N'PurchaseOrders: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [po_id],[supplier_id],[pr_id],[order_date],[expected_delivery_date] FROM bronze.[PurchaseOrders] EXCEPT SELECT [po_id],[supplier_id],[pr_id],[order_date],[expected_delivery_date] FROM silver.[PurchaseOrders]) d);
 INSERT #Checks SELECT N'PurchaseOrderDetails: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[PurchaseOrderDetails])-(SELECT COUNT_BIG(*) FROM silver.[PurchaseOrderDetails])));
 INSERT #Checks SELECT N'PurchaseOrderDetails: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [po_detail_id],[po_id],[pr_detail_id],[material_id],[ordered_quantity],[unit_price],[discount_percentage],[expected_delivery_date],[total_amount] FROM bronze.[PurchaseOrderDetails] EXCEPT SELECT [po_detail_id],[po_id],[pr_detail_id],[material_id],[ordered_quantity],[unit_price],[discount_percentage],[expected_delivery_date],[total_amount] FROM silver.[PurchaseOrderDetails]) d);
 INSERT #Checks SELECT N'PurchaseOrderDetails.ordered_quantity: negative values', (SELECT COUNT_BIG(*) FROM silver.[PurchaseOrderDetails] WHERE [ordered_quantity]<0);
 INSERT #Checks SELECT N'PurchaseOrderDetails.unit_price: negative values', (SELECT COUNT_BIG(*) FROM silver.[PurchaseOrderDetails] WHERE [unit_price]<0);
 INSERT #Checks SELECT N'PurchaseOrderDetails.discount_percentage: negative values', (SELECT COUNT_BIG(*) FROM silver.[PurchaseOrderDetails] WHERE [discount_percentage]<0);
 INSERT #Checks SELECT N'PurchaseOrderDetails.total_amount: negative values', (SELECT COUNT_BIG(*) FROM silver.[PurchaseOrderDetails] WHERE [total_amount]<0);
 INSERT #Checks SELECT N'SupplierShipments: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[SupplierShipments])-(SELECT COUNT_BIG(*) FROM silver.[SupplierShipments])));
 INSERT #Checks SELECT N'SupplierShipments: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [shipment_id],[po_id],[supplier_id],[ship_date],[expected_arrival_date],[actual_arrival_date],[total_shipment_value],[shipping_cost] FROM bronze.[SupplierShipments] EXCEPT SELECT [shipment_id],[po_id],[supplier_id],[ship_date],[expected_arrival_date],[actual_arrival_date],[total_shipment_value],[shipping_cost] FROM silver.[SupplierShipments]) d);
 INSERT #Checks SELECT N'SupplierShipments.total_shipment_value: negative values', (SELECT COUNT_BIG(*) FROM silver.[SupplierShipments] WHERE [total_shipment_value]<0);
 INSERT #Checks SELECT N'SupplierShipments.shipping_cost: negative values', (SELECT COUNT_BIG(*) FROM silver.[SupplierShipments] WHERE [shipping_cost]<0);
 INSERT #Checks SELECT N'SupplierShipmentDetails: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[SupplierShipmentDetails])-(SELECT COUNT_BIG(*) FROM silver.[SupplierShipmentDetails])));
 INSERT #Checks SELECT N'SupplierShipmentDetails: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [shipment_detail_id],[shipment_id],[po_detail_id],[material_id],[received_quantity],[accepted_quantity],[rejected_quantity] FROM bronze.[SupplierShipmentDetails] EXCEPT SELECT [shipment_detail_id],[shipment_id],[po_detail_id],[material_id],[received_quantity],[accepted_quantity],[rejected_quantity] FROM silver.[SupplierShipmentDetails]) d);
 INSERT #Checks SELECT N'SupplierShipmentDetails.received_quantity: negative values', (SELECT COUNT_BIG(*) FROM silver.[SupplierShipmentDetails] WHERE [received_quantity]<0);
 INSERT #Checks SELECT N'SupplierShipmentDetails.accepted_quantity: negative values', (SELECT COUNT_BIG(*) FROM silver.[SupplierShipmentDetails] WHERE [accepted_quantity]<0);
 INSERT #Checks SELECT N'SupplierShipmentDetails.rejected_quantity: negative values', (SELECT COUNT_BIG(*) FROM silver.[SupplierShipmentDetails] WHERE [rejected_quantity]<0);
 INSERT #Checks SELECT N'GoodsReceipts: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[GoodsReceipts])-(SELECT COUNT_BIG(*) FROM silver.[GoodsReceipts])));
 INSERT #Checks SELECT N'GoodsReceipts: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [gr_id],[shipment_id],[receipt_date],[total_received_value] FROM bronze.[GoodsReceipts] EXCEPT SELECT [gr_id],[shipment_id],[receipt_date],[total_received_value] FROM silver.[GoodsReceipts]) d);
 INSERT #Checks SELECT N'GoodsReceipts.total_received_value: negative values', (SELECT COUNT_BIG(*) FROM silver.[GoodsReceipts] WHERE [total_received_value]<0);
 INSERT #Checks SELECT N'GoodsReceiptDetails: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[GoodsReceiptDetails])-(SELECT COUNT_BIG(*) FROM silver.[GoodsReceiptDetails])));
 INSERT #Checks SELECT N'GoodsReceiptDetails: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [gr_detail_id],[gr_id],[shipment_detail_id],[material_id],[received_quantity],[accepted_quantity],[rejected_quantity] FROM bronze.[GoodsReceiptDetails] EXCEPT SELECT [gr_detail_id],[gr_id],[shipment_detail_id],[material_id],[received_quantity],[accepted_quantity],[rejected_quantity] FROM silver.[GoodsReceiptDetails]) d);
 INSERT #Checks SELECT N'GoodsReceiptDetails.received_quantity: negative values', (SELECT COUNT_BIG(*) FROM silver.[GoodsReceiptDetails] WHERE [received_quantity]<0);
 INSERT #Checks SELECT N'GoodsReceiptDetails.accepted_quantity: negative values', (SELECT COUNT_BIG(*) FROM silver.[GoodsReceiptDetails] WHERE [accepted_quantity]<0);
 INSERT #Checks SELECT N'GoodsReceiptDetails.rejected_quantity: negative values', (SELECT COUNT_BIG(*) FROM silver.[GoodsReceiptDetails] WHERE [rejected_quantity]<0);
 INSERT #Checks SELECT N'QualityInspections: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[QualityInspections])-(SELECT COUNT_BIG(*) FROM silver.[QualityInspections])));
 INSERT #Checks SELECT N'QualityInspections: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [inspection_id],[gr_detail_id],[inspection_date],[inspected_quantity],[passed_quantity],[defect_quantity],[reinspection_required] FROM bronze.[QualityInspections] EXCEPT SELECT [inspection_id],[gr_detail_id],[inspection_date],[inspected_quantity],[passed_quantity],[defect_quantity],[reinspection_required] FROM silver.[QualityInspections]) d);
 INSERT #Checks SELECT N'QualityInspections.inspected_quantity: negative values', (SELECT COUNT_BIG(*) FROM silver.[QualityInspections] WHERE [inspected_quantity]<0);
 INSERT #Checks SELECT N'QualityInspections.passed_quantity: negative values', (SELECT COUNT_BIG(*) FROM silver.[QualityInspections] WHERE [passed_quantity]<0);
 INSERT #Checks SELECT N'QualityInspections.defect_quantity: negative values', (SELECT COUNT_BIG(*) FROM silver.[QualityInspections] WHERE [defect_quantity]<0);
 INSERT #Checks SELECT N'SupplierInvoices: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[SupplierInvoices])-(SELECT COUNT_BIG(*) FROM silver.[SupplierInvoices])));
 INSERT #Checks SELECT N'SupplierInvoices: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [invoice_id],[shipment_id],[supplier_id],[invoice_date],[invoice_amount],[tax_amount],[total_amount],[due_date] FROM bronze.[SupplierInvoices] EXCEPT SELECT [invoice_id],[shipment_id],[supplier_id],[invoice_date],[invoice_amount],[tax_amount],[total_amount],[due_date] FROM silver.[SupplierInvoices]) d);
 INSERT #Checks SELECT N'SupplierInvoices.invoice_amount: negative values', (SELECT COUNT_BIG(*) FROM silver.[SupplierInvoices] WHERE [invoice_amount]<0);
 INSERT #Checks SELECT N'SupplierInvoices.tax_amount: negative values', (SELECT COUNT_BIG(*) FROM silver.[SupplierInvoices] WHERE [tax_amount]<0);
 INSERT #Checks SELECT N'SupplierInvoices.total_amount: negative values', (SELECT COUNT_BIG(*) FROM silver.[SupplierInvoices] WHERE [total_amount]<0);
 INSERT #Checks SELECT N'SupplierInvoiceDetails: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[SupplierInvoiceDetails])-(SELECT COUNT_BIG(*) FROM silver.[SupplierInvoiceDetails])));
 INSERT #Checks SELECT N'SupplierInvoiceDetails: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [invoice_detail_id],[invoice_id],[gr_detail_id],[billed_quantity],[unit_price],[tax_amount],[line_amount] FROM bronze.[SupplierInvoiceDetails] EXCEPT SELECT [invoice_detail_id],[invoice_id],[gr_detail_id],[billed_quantity],[unit_price],[tax_amount],[line_amount] FROM silver.[SupplierInvoiceDetails]) d);
 INSERT #Checks SELECT N'SupplierInvoiceDetails.billed_quantity: negative values', (SELECT COUNT_BIG(*) FROM silver.[SupplierInvoiceDetails] WHERE [billed_quantity]<0);
 INSERT #Checks SELECT N'SupplierInvoiceDetails.unit_price: negative values', (SELECT COUNT_BIG(*) FROM silver.[SupplierInvoiceDetails] WHERE [unit_price]<0);
 INSERT #Checks SELECT N'SupplierInvoiceDetails.tax_amount: negative values', (SELECT COUNT_BIG(*) FROM silver.[SupplierInvoiceDetails] WHERE [tax_amount]<0);
 INSERT #Checks SELECT N'SupplierInvoiceDetails.line_amount: negative values', (SELECT COUNT_BIG(*) FROM silver.[SupplierInvoiceDetails] WHERE [line_amount]<0);
 INSERT #Checks SELECT N'SupplierPayments: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[SupplierPayments])-(SELECT COUNT_BIG(*) FROM silver.[SupplierPayments])));
 INSERT #Checks SELECT N'SupplierPayments: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [payment_id],[invoice_id],[payment_date],[payment_amount] FROM bronze.[SupplierPayments] EXCEPT SELECT [payment_id],[invoice_id],[payment_date],[payment_amount] FROM silver.[SupplierPayments]) d);
 INSERT #Checks SELECT N'SupplierPayments.payment_amount: negative values', (SELECT COUNT_BIG(*) FROM silver.[SupplierPayments] WHERE [payment_amount]<0);
 INSERT #Checks SELECT N'Warehouses: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[Warehouses])-(SELECT COUNT_BIG(*) FROM silver.[Warehouses])));
 INSERT #Checks SELECT N'Warehouses: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [warehouse_id] FROM bronze.[Warehouses] EXCEPT SELECT [warehouse_id] FROM silver.[Warehouses]) d);
 INSERT #Checks SELECT N'RawMaterialInventory: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[RawMaterialInventory])-(SELECT COUNT_BIG(*) FROM silver.[RawMaterialInventory])));
 INSERT #Checks SELECT N'RawMaterialInventory: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [raw_inventory_id],[warehouse_id],[material_id],[quantity_on_hand],[quantity_reserved],[reorder_point],[safety_stock_level],[max_inventory_level],[unit_cost],[last_updated_at] FROM bronze.[RawMaterialInventory] EXCEPT SELECT [raw_inventory_id],[warehouse_id],[material_id],[quantity_on_hand],[quantity_reserved],[reorder_point],[safety_stock_level],[max_inventory_level],[unit_cost],[last_updated_at] FROM silver.[RawMaterialInventory]) d);
 INSERT #Checks SELECT N'RawMaterialInventory.quantity_on_hand: negative values', (SELECT COUNT_BIG(*) FROM silver.[RawMaterialInventory] WHERE [quantity_on_hand]<0);
 INSERT #Checks SELECT N'RawMaterialInventory.quantity_reserved: negative values', (SELECT COUNT_BIG(*) FROM silver.[RawMaterialInventory] WHERE [quantity_reserved]<0);
 INSERT #Checks SELECT N'RawMaterialInventory.reorder_point: negative values', (SELECT COUNT_BIG(*) FROM silver.[RawMaterialInventory] WHERE [reorder_point]<0);
 INSERT #Checks SELECT N'RawMaterialInventory.safety_stock_level: negative values', (SELECT COUNT_BIG(*) FROM silver.[RawMaterialInventory] WHERE [safety_stock_level]<0);
 INSERT #Checks SELECT N'RawMaterialInventory.max_inventory_level: negative values', (SELECT COUNT_BIG(*) FROM silver.[RawMaterialInventory] WHERE [max_inventory_level]<0);
 INSERT #Checks SELECT N'RawMaterialInventory.unit_cost: negative values', (SELECT COUNT_BIG(*) FROM silver.[RawMaterialInventory] WHERE [unit_cost]<0);
 INSERT #Checks SELECT N'Products: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[Products])-(SELECT COUNT_BIG(*) FROM silver.[Products])));
 INSERT #Checks SELECT N'Products: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [product_id],[standard_cost],[selling_price] FROM bronze.[Products] EXCEPT SELECT [product_id],[standard_cost],[selling_price] FROM silver.[Products]) d);
 INSERT #Checks SELECT N'Products.standard_cost: negative values', (SELECT COUNT_BIG(*) FROM silver.[Products] WHERE [standard_cost]<0);
 INSERT #Checks SELECT N'Products.selling_price: negative values', (SELECT COUNT_BIG(*) FROM silver.[Products] WHERE [selling_price]<0);
 INSERT #Checks SELECT N'ProductBOM: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[ProductBOM])-(SELECT COUNT_BIG(*) FROM silver.[ProductBOM])));
 INSERT #Checks SELECT N'ProductBOM: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [bom_id],[product_id],[material_id],[quantity_required] FROM bronze.[ProductBOM] EXCEPT SELECT [bom_id],[product_id],[material_id],[quantity_required] FROM silver.[ProductBOM]) d);
 INSERT #Checks SELECT N'ProductBOM.quantity_required: negative values', (SELECT COUNT_BIG(*) FROM silver.[ProductBOM] WHERE [quantity_required]<0);
 INSERT #Checks SELECT N'Production: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[Production])-(SELECT COUNT_BIG(*) FROM silver.[Production])));
 INSERT #Checks SELECT N'Production: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [production_id],[product_id],[planned_quantity],[start_date],[expected_end_date],[actual_end_date],[production_quantity],[rejected_quantity] FROM bronze.[Production] EXCEPT SELECT [production_id],[product_id],[planned_quantity],[start_date],[expected_end_date],[actual_end_date],[production_quantity],[rejected_quantity] FROM silver.[Production]) d);
 INSERT #Checks SELECT N'Production.planned_quantity: negative values', (SELECT COUNT_BIG(*) FROM silver.[Production] WHERE [planned_quantity]<0);
 INSERT #Checks SELECT N'Production.production_quantity: negative values', (SELECT COUNT_BIG(*) FROM silver.[Production] WHERE [production_quantity]<0);
 INSERT #Checks SELECT N'Production.rejected_quantity: negative values', (SELECT COUNT_BIG(*) FROM silver.[Production] WHERE [rejected_quantity]<0);
 INSERT #Checks SELECT N'ProductionDetails: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[ProductionDetails])-(SELECT COUNT_BIG(*) FROM silver.[ProductionDetails])));
 INSERT #Checks SELECT N'ProductionDetails: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [production_detail_id],[production_id],[bom_id],[raw_inventory_id],[actual_consumed_quantity],[return_quantity],[scrap_quantity],[unit_cost],[total_material_cost] FROM bronze.[ProductionDetails] EXCEPT SELECT [production_detail_id],[production_id],[bom_id],[raw_inventory_id],[actual_consumed_quantity],[return_quantity],[scrap_quantity],[unit_cost],[total_material_cost] FROM silver.[ProductionDetails]) d);
 INSERT #Checks SELECT N'ProductionDetails.actual_consumed_quantity: negative values', (SELECT COUNT_BIG(*) FROM silver.[ProductionDetails] WHERE [actual_consumed_quantity]<0);
 INSERT #Checks SELECT N'ProductionDetails.return_quantity: negative values', (SELECT COUNT_BIG(*) FROM silver.[ProductionDetails] WHERE [return_quantity]<0);
 INSERT #Checks SELECT N'ProductionDetails.scrap_quantity: negative values', (SELECT COUNT_BIG(*) FROM silver.[ProductionDetails] WHERE [scrap_quantity]<0);
 INSERT #Checks SELECT N'ProductionDetails.unit_cost: negative values', (SELECT COUNT_BIG(*) FROM silver.[ProductionDetails] WHERE [unit_cost]<0);
 INSERT #Checks SELECT N'ProductionDetails.total_material_cost: negative values', (SELECT COUNT_BIG(*) FROM silver.[ProductionDetails] WHERE [total_material_cost]<0);
 INSERT #Checks SELECT N'RawMaterialInventoryTransactions: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[RawMaterialInventoryTransactions])-(SELECT COUNT_BIG(*) FROM silver.[RawMaterialInventoryTransactions])));
 INSERT #Checks SELECT N'RawMaterialInventoryTransactions: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [raw_transaction_id],[raw_inventory_id],[production_id],[inspection_id],[quantity],[unit_cost],[transaction_date] FROM bronze.[RawMaterialInventoryTransactions] EXCEPT SELECT [raw_transaction_id],[raw_inventory_id],[production_id],[inspection_id],[quantity],[unit_cost],[transaction_date] FROM silver.[RawMaterialInventoryTransactions]) d);
 INSERT #Checks SELECT N'RawMaterialInventoryTransactions.quantity: negative values', (SELECT COUNT_BIG(*) FROM silver.[RawMaterialInventoryTransactions] WHERE [quantity]<0);
 INSERT #Checks SELECT N'RawMaterialInventoryTransactions.unit_cost: negative values', (SELECT COUNT_BIG(*) FROM silver.[RawMaterialInventoryTransactions] WHERE [unit_cost]<0);
 INSERT #Checks SELECT N'FinishedGoodsInventory: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[FinishedGoodsInventory])-(SELECT COUNT_BIG(*) FROM silver.[FinishedGoodsInventory])));
 INSERT #Checks SELECT N'FinishedGoodsInventory: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [finished_goods_inventory_id],[warehouse_id],[product_id],[quantity_on_hand],[quantity_reserved],[reorder_point],[safety_stock_level],[last_updated_at] FROM bronze.[FinishedGoodsInventory] EXCEPT SELECT [finished_goods_inventory_id],[warehouse_id],[product_id],[quantity_on_hand],[quantity_reserved],[reorder_point],[safety_stock_level],[last_updated_at] FROM silver.[FinishedGoodsInventory]) d);
 INSERT #Checks SELECT N'FinishedGoodsInventory.quantity_on_hand: negative values', (SELECT COUNT_BIG(*) FROM silver.[FinishedGoodsInventory] WHERE [quantity_on_hand]<0);
 INSERT #Checks SELECT N'FinishedGoodsInventory.quantity_reserved: negative values', (SELECT COUNT_BIG(*) FROM silver.[FinishedGoodsInventory] WHERE [quantity_reserved]<0);
 INSERT #Checks SELECT N'FinishedGoodsInventory.reorder_point: negative values', (SELECT COUNT_BIG(*) FROM silver.[FinishedGoodsInventory] WHERE [reorder_point]<0);
 INSERT #Checks SELECT N'FinishedGoodsInventory.safety_stock_level: negative values', (SELECT COUNT_BIG(*) FROM silver.[FinishedGoodsInventory] WHERE [safety_stock_level]<0);
 INSERT #Checks SELECT N'Customers: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[Customers])-(SELECT COUNT_BIG(*) FROM silver.[Customers])));
 INSERT #Checks SELECT N'Customers: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [customer_id],[registration_date],[default_discount_percentage] FROM bronze.[Customers] EXCEPT SELECT [customer_id],[registration_date],[default_discount_percentage] FROM silver.[Customers]) d);
 INSERT #Checks SELECT N'Customers.default_discount_percentage: negative values', (SELECT COUNT_BIG(*) FROM silver.[Customers] WHERE [default_discount_percentage]<0);
 INSERT #Checks SELECT N'SalesOrders: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[SalesOrders])-(SELECT COUNT_BIG(*) FROM silver.[SalesOrders])));
 INSERT #Checks SELECT N'SalesOrders: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [sales_order_id],[customer_id],[order_date],[required_delivery_date],[tax_percentage] FROM bronze.[SalesOrders] EXCEPT SELECT [sales_order_id],[customer_id],[order_date],[required_delivery_date],[tax_percentage] FROM silver.[SalesOrders]) d);
 INSERT #Checks SELECT N'SalesOrders.tax_percentage: negative values', (SELECT COUNT_BIG(*) FROM silver.[SalesOrders] WHERE [tax_percentage]<0);
 INSERT #Checks SELECT N'SalesOrderDetails: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[SalesOrderDetails])-(SELECT COUNT_BIG(*) FROM silver.[SalesOrderDetails])));
 INSERT #Checks SELECT N'SalesOrderDetails: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [sales_order_detail_id],[sales_order_id],[product_id],[ordered_quantity] FROM bronze.[SalesOrderDetails] EXCEPT SELECT [sales_order_detail_id],[sales_order_id],[product_id],[ordered_quantity] FROM silver.[SalesOrderDetails]) d);
 INSERT #Checks SELECT N'SalesOrderDetails.ordered_quantity: negative values', (SELECT COUNT_BIG(*) FROM silver.[SalesOrderDetails] WHERE [ordered_quantity]<0);
 INSERT #Checks SELECT N'CustomerShipments: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[CustomerShipments])-(SELECT COUNT_BIG(*) FROM silver.[CustomerShipments])));
 INSERT #Checks SELECT N'CustomerShipments: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [customer_shipment_id],[sales_order_id],[warehouse_id],[shipment_date],[expected_delivery_date],[actual_delivery_date],[shipping_cost],[delivery_confirmation] FROM bronze.[CustomerShipments] EXCEPT SELECT [customer_shipment_id],[sales_order_id],[warehouse_id],[shipment_date],[expected_delivery_date],[actual_delivery_date],[shipping_cost],[delivery_confirmation] FROM silver.[CustomerShipments]) d);
 INSERT #Checks SELECT N'CustomerShipments.shipping_cost: negative values', (SELECT COUNT_BIG(*) FROM silver.[CustomerShipments] WHERE [shipping_cost]<0);
 INSERT #Checks SELECT N'CustomerShipmentDetails: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[CustomerShipmentDetails])-(SELECT COUNT_BIG(*) FROM silver.[CustomerShipmentDetails])));
 INSERT #Checks SELECT N'CustomerShipmentDetails: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [customer_shipment_detail_id],[customer_shipment_id],[sales_order_detail_id],[shipped_quantity] FROM bronze.[CustomerShipmentDetails] EXCEPT SELECT [customer_shipment_detail_id],[customer_shipment_id],[sales_order_detail_id],[shipped_quantity] FROM silver.[CustomerShipmentDetails]) d);
 INSERT #Checks SELECT N'CustomerShipmentDetails.shipped_quantity: negative values', (SELECT COUNT_BIG(*) FROM silver.[CustomerShipmentDetails] WHERE [shipped_quantity]<0);
 INSERT #Checks SELECT N'FinishedGoodsInventoryTransactions: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[FinishedGoodsInventoryTransactions])-(SELECT COUNT_BIG(*) FROM silver.[FinishedGoodsInventoryTransactions])));
 INSERT #Checks SELECT N'FinishedGoodsInventoryTransactions: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [finished_inventory_transaction_id],[finished_goods_inventory_id],[production_id],[customer_shipment_detail_id],[quantity],[unit_cost],[transaction_date] FROM bronze.[FinishedGoodsInventoryTransactions] EXCEPT SELECT [finished_inventory_transaction_id],[finished_goods_inventory_id],[production_id],[customer_shipment_detail_id],[quantity],[unit_cost],[transaction_date] FROM silver.[FinishedGoodsInventoryTransactions]) d);
 INSERT #Checks SELECT N'FinishedGoodsInventoryTransactions.quantity: negative values', (SELECT COUNT_BIG(*) FROM silver.[FinishedGoodsInventoryTransactions] WHERE [quantity]<0);
 INSERT #Checks SELECT N'FinishedGoodsInventoryTransactions.unit_cost: negative values', (SELECT COUNT_BIG(*) FROM silver.[FinishedGoodsInventoryTransactions] WHERE [unit_cost]<0);
 INSERT #Checks SELECT N'Returns: Bronze/Silver row count', (SELECT ABS((SELECT COUNT_BIG(*) FROM bronze.[Returns])-(SELECT COUNT_BIG(*) FROM silver.[Returns])));
 INSERT #Checks SELECT N'Returns: numeric/date source preservation', (SELECT COUNT_BIG(*) FROM (SELECT [return_id],[customer_shipment_detail_id],[return_request_date],[return_received_date],[returned_quantity] FROM bronze.[Returns] EXCEPT SELECT [return_id],[customer_shipment_detail_id],[return_request_date],[return_received_date],[returned_quantity] FROM silver.[Returns]) d);
 INSERT #Checks SELECT N'Returns.returned_quantity: negative values', (SELECT COUNT_BIG(*) FROM silver.[Returns] WHERE [returned_quantity]<0);
 INSERT #Checks SELECT N'SupplierShipmentDetails: quantity reconciliation', (SELECT COUNT_BIG(*) FROM silver.SupplierShipmentDetails WHERE received_quantity<>accepted_quantity+rejected_quantity);
 INSERT #Checks SELECT N'GoodsReceiptDetails: quantity reconciliation', (SELECT COUNT_BIG(*) FROM silver.GoodsReceiptDetails WHERE received_quantity<>accepted_quantity+rejected_quantity);
 INSERT #Checks SELECT N'Quality inspection quantity reconciliation', (SELECT COUNT_BIG(*) FROM silver.QualityInspections WHERE inspected_quantity<>passed_quantity+defect_quantity);
 INSERT #Checks SELECT N'Production completed date', (SELECT COUNT_BIG(*) FROM silver.Production WHERE production_status='Completed' AND actual_end_date IS NULL);
 INSERT #Checks SELECT N'Production rejection exceeds output', (SELECT COUNT_BIG(*) FROM silver.Production WHERE rejected_quantity>production_quantity);
 INSERT #Checks SELECT N'Shipment aggregated overfill', (SELECT COUNT_BIG(*) FROM gold.vw_FactSalesFulfillment WHERE shipped_quantity>ordered_quantity);
 INSERT #Checks SELECT N'Returns aggregated over shipped', (SELECT COUNT_BIG(*) FROM (SELECT customer_shipment_detail_id,SUM(returned_quantity) AS qty
FROM silver.Returns GROUP BY customer_shipment_detail_id) r JOIN silver.CustomerShipmentDetails d
ON d.customer_shipment_detail_id=r.customer_shipment_detail_id WHERE r.qty>d.shipped_quantity);
 INSERT #Checks SELECT N'RawMaterialInventory: reserved exceeds on hand', (SELECT COUNT_BIG(*) FROM silver.RawMaterialInventory WHERE quantity_reserved>quantity_on_hand);
 INSERT #Checks SELECT N'FinishedGoodsInventory: reserved exceeds on hand', (SELECT COUNT_BIG(*) FROM silver.FinishedGoodsInventory WHERE quantity_reserved>quantity_on_hand);
 INSERT #Checks SELECT N'Production: event date order', (SELECT COUNT_BIG(*) FROM silver.Production WHERE actual_end_date<start_date);
 INSERT #Checks SELECT N'SupplierShipments: event date order', (SELECT COUNT_BIG(*) FROM silver.SupplierShipments WHERE actual_arrival_date<ship_date);
 INSERT #Checks SELECT N'CustomerShipments: event date order', (SELECT COUNT_BIG(*) FROM silver.CustomerShipments WHERE actual_delivery_date<shipment_date);
 INSERT #Checks SELECT N'Returns: event date order', (SELECT COUNT_BIG(*) FROM silver.Returns WHERE return_received_date<return_request_date);
 INSERT #Checks SELECT N'Production material cost rounding', (SELECT COUNT_BIG(*) FROM silver.ProductionDetails WHERE ABS(total_material_cost-ROUND(actual_consumed_quantity*unit_cost,2))>0.01);
 INSERT #Checks SELECT N'vw_FactPurchaseRequisition: unique grain', (SELECT COUNT_BIG(*) FROM (SELECT [pr_id] FROM gold.[vw_FactPurchaseRequisition] GROUP BY [pr_id] HAVING COUNT_BIG(*)>1) d);
 INSERT #Checks SELECT N'vw_FactPurchaseOrderDetail: unique grain', (SELECT COUNT_BIG(*) FROM (SELECT [po_detail_id] FROM gold.[vw_FactPurchaseOrderDetail] GROUP BY [po_detail_id] HAVING COUNT_BIG(*)>1) d);
 INSERT #Checks SELECT N'vw_FactSupplierShipment: unique grain', (SELECT COUNT_BIG(*) FROM (SELECT [shipment_id] FROM gold.[vw_FactSupplierShipment] GROUP BY [shipment_id] HAVING COUNT_BIG(*)>1) d);
 INSERT #Checks SELECT N'vw_FactSupplierShipmentDetail: unique grain', (SELECT COUNT_BIG(*) FROM (SELECT [shipment_detail_id] FROM gold.[vw_FactSupplierShipmentDetail] GROUP BY [shipment_detail_id] HAVING COUNT_BIG(*)>1) d);
 INSERT #Checks SELECT N'vw_FactGoodsReceiptDetail: unique grain', (SELECT COUNT_BIG(*) FROM (SELECT [gr_detail_id] FROM gold.[vw_FactGoodsReceiptDetail] GROUP BY [gr_detail_id] HAVING COUNT_BIG(*)>1) d);
 INSERT #Checks SELECT N'vw_FactQualityInspection: unique grain', (SELECT COUNT_BIG(*) FROM (SELECT [inspection_id] FROM gold.[vw_FactQualityInspection] GROUP BY [inspection_id] HAVING COUNT_BIG(*)>1) d);
 INSERT #Checks SELECT N'vw_FactRawMaterialInventory: unique grain', (SELECT COUNT_BIG(*) FROM (SELECT [raw_inventory_id] FROM gold.[vw_FactRawMaterialInventory] GROUP BY [raw_inventory_id] HAVING COUNT_BIG(*)>1) d);
 INSERT #Checks SELECT N'vw_FactRawInventoryTransaction: unique grain', (SELECT COUNT_BIG(*) FROM (SELECT [raw_transaction_id] FROM gold.[vw_FactRawInventoryTransaction] GROUP BY [raw_transaction_id] HAVING COUNT_BIG(*)>1) d);
 INSERT #Checks SELECT N'vw_FactProductionOrder: unique grain', (SELECT COUNT_BIG(*) FROM (SELECT [production_id] FROM gold.[vw_FactProductionOrder] GROUP BY [production_id] HAVING COUNT_BIG(*)>1) d);
 INSERT #Checks SELECT N'vw_FactProductionMaterial: unique grain', (SELECT COUNT_BIG(*) FROM (SELECT [production_detail_id] FROM gold.[vw_FactProductionMaterial] GROUP BY [production_detail_id] HAVING COUNT_BIG(*)>1) d);
 INSERT #Checks SELECT N'vw_FactFinishedGoodsInventory: unique grain', (SELECT COUNT_BIG(*) FROM (SELECT [finished_goods_inventory_id] FROM gold.[vw_FactFinishedGoodsInventory] GROUP BY [finished_goods_inventory_id] HAVING COUNT_BIG(*)>1) d);
 INSERT #Checks SELECT N'vw_FactFinishedGoodsTransaction: unique grain', (SELECT COUNT_BIG(*) FROM (SELECT [finished_inventory_transaction_id] FROM gold.[vw_FactFinishedGoodsTransaction] GROUP BY [finished_inventory_transaction_id] HAVING COUNT_BIG(*)>1) d);
 INSERT #Checks SELECT N'vw_FactSalesOrderDetail: unique grain', (SELECT COUNT_BIG(*) FROM (SELECT [sales_order_detail_id] FROM gold.[vw_FactSalesOrderDetail] GROUP BY [sales_order_detail_id] HAVING COUNT_BIG(*)>1) d);
 INSERT #Checks SELECT N'vw_FactCustomerShipment: unique grain', (SELECT COUNT_BIG(*) FROM (SELECT [customer_shipment_id] FROM gold.[vw_FactCustomerShipment] GROUP BY [customer_shipment_id] HAVING COUNT_BIG(*)>1) d);
 INSERT #Checks SELECT N'vw_FactCustomerShipmentDetail: unique grain', (SELECT COUNT_BIG(*) FROM (SELECT [customer_shipment_detail_id] FROM gold.[vw_FactCustomerShipmentDetail] GROUP BY [customer_shipment_detail_id] HAVING COUNT_BIG(*)>1) d);
 INSERT #Checks SELECT N'vw_FactReturn: unique grain', (SELECT COUNT_BIG(*) FROM (SELECT [return_id] FROM gold.[vw_FactReturn] GROUP BY [return_id] HAVING COUNT_BIG(*)>1) d);
 INSERT #Checks SELECT N'vw_FactSalesFulfillment: unique grain', (SELECT COUNT_BIG(*) FROM (SELECT [sales_order_detail_id] FROM gold.[vw_FactSalesFulfillment] GROUP BY [sales_order_detail_id] HAVING COUNT_BIG(*)>1) d);
 INSERT #Checks SELECT N'vw_FactSupplierInvoice: unique grain', (SELECT COUNT_BIG(*) FROM (SELECT [invoice_id] FROM gold.[vw_FactSupplierInvoice] GROUP BY [invoice_id] HAVING COUNT_BIG(*)>1) d);
 INSERT #Checks SELECT N'vw_FactSupplierInvoiceDetail: unique grain', (SELECT COUNT_BIG(*) FROM (SELECT [invoice_detail_id] FROM gold.[vw_FactSupplierInvoiceDetail] GROUP BY [invoice_detail_id] HAVING COUNT_BIG(*)>1) d);
 INSERT #Checks SELECT N'vw_FactSupplierPayment: unique grain', (SELECT COUNT_BIG(*) FROM (SELECT [payment_id] FROM gold.[vw_FactSupplierPayment] GROUP BY [payment_id] HAVING COUNT_BIG(*)>1) d);
 IF @CheckSampleBaseline=1
 BEGIN
 INSERT #Checks SELECT 'Departments: sample row count',ABS(COUNT_BIG(*)-6) FROM silver.[Departments];
 INSERT #Checks SELECT 'Materials: sample row count',ABS(COUNT_BIG(*)-80) FROM silver.[Materials];
 INSERT #Checks SELECT 'Suppliers: sample row count',ABS(COUNT_BIG(*)-25) FROM silver.[Suppliers];
 INSERT #Checks SELECT 'SupplierMaterials: sample row count',ABS(COUNT_BIG(*)-200) FROM silver.[SupplierMaterials];
 INSERT #Checks SELECT 'PurchaseRequisitions: sample row count',ABS(COUNT_BIG(*)-2500) FROM silver.[PurchaseRequisitions];
 INSERT #Checks SELECT 'PurchaseRequisitionDetails: sample row count',ABS(COUNT_BIG(*)-7500) FROM silver.[PurchaseRequisitionDetails];
 INSERT #Checks SELECT 'PurchaseOrders: sample row count',ABS(COUNT_BIG(*)-2300) FROM silver.[PurchaseOrders];
 INSERT #Checks SELECT 'PurchaseOrderDetails: sample row count',ABS(COUNT_BIG(*)-6900) FROM silver.[PurchaseOrderDetails];
 INSERT #Checks SELECT 'SupplierShipments: sample row count',ABS(COUNT_BIG(*)-2300) FROM silver.[SupplierShipments];
 INSERT #Checks SELECT 'SupplierShipmentDetails: sample row count',ABS(COUNT_BIG(*)-6900) FROM silver.[SupplierShipmentDetails];
 INSERT #Checks SELECT 'GoodsReceipts: sample row count',ABS(COUNT_BIG(*)-2300) FROM silver.[GoodsReceipts];
 INSERT #Checks SELECT 'GoodsReceiptDetails: sample row count',ABS(COUNT_BIG(*)-6900) FROM silver.[GoodsReceiptDetails];
 INSERT #Checks SELECT 'QualityInspections: sample row count',ABS(COUNT_BIG(*)-6900) FROM silver.[QualityInspections];
 INSERT #Checks SELECT 'SupplierInvoices: sample row count',ABS(COUNT_BIG(*)-2300) FROM silver.[SupplierInvoices];
 INSERT #Checks SELECT 'SupplierInvoiceDetails: sample row count',ABS(COUNT_BIG(*)-6900) FROM silver.[SupplierInvoiceDetails];
 INSERT #Checks SELECT 'SupplierPayments: sample row count',ABS(COUNT_BIG(*)-2500) FROM silver.[SupplierPayments];
 INSERT #Checks SELECT 'Warehouses: sample row count',ABS(COUNT_BIG(*)-4) FROM silver.[Warehouses];
 INSERT #Checks SELECT 'RawMaterialInventory: sample row count',ABS(COUNT_BIG(*)-160) FROM silver.[RawMaterialInventory];
 INSERT #Checks SELECT 'Products: sample row count',ABS(COUNT_BIG(*)-16) FROM silver.[Products];
 INSERT #Checks SELECT 'ProductBOM: sample row count',ABS(COUNT_BIG(*)-160) FROM silver.[ProductBOM];
 INSERT #Checks SELECT 'Production: sample row count',ABS(COUNT_BIG(*)-2600) FROM silver.[Production];
 INSERT #Checks SELECT 'ProductionDetails: sample row count',ABS(COUNT_BIG(*)-26000) FROM silver.[ProductionDetails];
 INSERT #Checks SELECT 'RawMaterialInventoryTransactions: sample row count',ABS(COUNT_BIG(*)-33520) FROM silver.[RawMaterialInventoryTransactions];
 INSERT #Checks SELECT 'FinishedGoodsInventory: sample row count',ABS(COUNT_BIG(*)-32) FROM silver.[FinishedGoodsInventory];
 INSERT #Checks SELECT 'Customers: sample row count',ABS(COUNT_BIG(*)-350) FROM silver.[Customers];
 INSERT #Checks SELECT 'SalesOrders: sample row count',ABS(COUNT_BIG(*)-9850) FROM silver.[SalesOrders];
 INSERT #Checks SELECT 'SalesOrderDetails: sample row count',ABS(COUNT_BIG(*)-19700) FROM silver.[SalesOrderDetails];
 INSERT #Checks SELECT 'CustomerShipments: sample row count',ABS(COUNT_BIG(*)-9850) FROM silver.[CustomerShipments];
 INSERT #Checks SELECT 'CustomerShipmentDetails: sample row count',ABS(COUNT_BIG(*)-18878) FROM silver.[CustomerShipmentDetails];
 INSERT #Checks SELECT 'FinishedGoodsInventoryTransactions: sample row count',ABS(COUNT_BIG(*)-21708) FROM silver.[FinishedGoodsInventoryTransactions];
 INSERT #Checks SELECT 'Returns: sample row count',ABS(COUNT_BIG(*)-661) FROM silver.[Returns];
 INSERT #Checks SELECT 'Sample fulfillment quantity',CASE WHEN SUM(shipped_quantity)=1047057 AND SUM(ordered_quantity)=1103908 THEN 0 ELSE 1 END FROM gold.vw_FactSalesFulfillment;
 INSERT #Checks SELECT 'Sample unshipped sales lines',ABS(COUNT_BIG(*)-822) FROM gold.vw_FactSalesFulfillment WHERE shipment_line_count=0;
 INSERT #Checks SELECT 'Sample open production',ABS(COUNT_BIG(*)-104) FROM silver.Production WHERE production_status='In Progress';
 END;
 SELECT check_name,failures,CASE WHEN failures=0 THEN 'PASS' ELSE 'FAIL' END AS result FROM #Checks ORDER BY failures DESC,check_name;
 IF EXISTS (SELECT 1 FROM #Checks WHERE failures<>0) THROW 51005, 'Validation failed; inspect the FAIL rows. Refresh is rolled back.', 1;
END;
GO

