﻿$ErrorActionPreference = 'Stop'
$expressionFile = Join-Path $PSScriptRoot 'SupplyChain_Updated.SemanticModel\definition\expressions.tmdl'
$dataFolder = (Join-Path $PSScriptRoot 'data_gold').Replace('"','""')
$content = [System.IO.File]::ReadAllText($expressionFile)
$replacement = 'expression DataFolder = "' + $dataFolder + '"'
$content = [regex]::Replace($content, '(?m)^expression DataFolder = "[^"]*"', [System.Text.RegularExpressions.MatchEvaluator]{ param($match) $replacement })
[System.IO.File]::WriteAllText($expressionFile, $content, (New-Object System.Text.UTF8Encoding($false)))
Start-Process (Join-Path $PSScriptRoot 'SupplyChain_Updated.pbip')
